// Cliente de la API de Xtream Codes que expone el panel XUI (player_api.php).
// Misma lógica que ApiTask.brs (Roku), Xtream.java (Android) y xtream.js (Windows).
'use strict';

/** Palabras que delatan una categoría para adultos (en el nombre, en minúsculas). */
var ADULTOS = /adult|xxx|porn|erotic|\+\s?18|18\s?\+|\bsex|playboy|hentai/;

function Xtream(servidor, usuario, clave) {
    this.base = Xtream.normalizar(servidor);
    this.usuario = usuario;
    this.clave = clave;
    /** El servidor permite HLS (.m3u8) para esta cuenta; en vivo se prefiere (va mejor con AVPlay). */
    this.m3u8 = true;
    this.estado = '';
    this.vence = '';
    this.conexiones = '';
    this.cache = {};
}

Xtream.normalizar = function (servidor) {
    var s = Comun.texto(servidor);
    if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
    return s.replace(/\/+$/, '');
};

/** Error de la cuenta (contraseña, vencida, suspendida): la app regresa al inicio de sesión. */
function ErrorDeCuenta(mensaje) {
    this.message = mensaje;
    this.cuenta = true;
}

Xtream.prototype.url = function (accion, extra) {
    var u = this.base + '/player_api.php?username=' + encodeURIComponent(this.usuario) + '&password=' + encodeURIComponent(this.clave);
    return accion ? u + '&action=' + accion + (extra || '') : u;
};

Xtream.prototype.pedir = function (url, espera) {
    return new Promise(function (listo, falla) {
        var x = new XMLHttpRequest();
        x.open('GET', url, true);
        x.timeout = espera || 40000;
        x.onload = function () {
            if (x.status < 200 || x.status >= 300) return falla(new Error('El servidor respondió con el error ' + x.status));
            try {
                listo(JSON.parse(x.responseText));
            } catch (e) {
                falla(new Error('El servidor respondió algo que no se entiende'));
            }
        };
        x.onerror = function () { falla(new Error('No se pudo conectar con el servidor. Revisa la conexión a internet.')); };
        x.ontimeout = function () { falla(new Error('El servidor tardó demasiado en responder')); };
        x.send();
    });
};

/** Algunos paneles devuelven un objeto vacío en lugar de una lista vacía. */
Xtream.prototype.lista = function (url) {
    return this.pedir(url).then(function (d) { return Object.prototype.toString.call(d) === '[object Array]' ? d : []; });
};

/** Valida la cuenta y guarda estado, vencimiento, conexiones y formatos permitidos. */
Xtream.prototype.entrar = function () {
    var yo = this;
    return this.pedir(this.url(null), 30000).then(function (d) {
        var info = d && d.user_info;
        if (!info || Number(info.auth) !== 1) throw new ErrorDeCuenta('Usuario o contraseña incorrectos');
        yo.estado = Comun.texto(info.status);
        if (/^expired$/i.test(yo.estado)) throw new ErrorDeCuenta('Tu cuenta está vencida');
        if (yo.estado && !/^active$/i.test(yo.estado)) throw new ErrorDeCuenta('Tu cuenta está suspendida');
        var exp = Number(info.exp_date);
        yo.vence = exp > 0 ? Comun.fechaYHora(exp) : 'Sin vencimiento';
        yo.conexiones = Comun.texto(info.active_cons) + ' de ' + Comun.texto(info.max_connections);
        var formatos = info.allowed_output_formats;
        if (formatos && formatos.length) {
            yo.m3u8 = false;
            for (var i = 0; i < formatos.length; i++) if (/^m3u8$/i.test(formatos[i])) yo.m3u8 = true;
        }
        return yo;
    });
};

Xtream.prototype.categorias = function (tipo) {
    var yo = this, clave = 'cat/' + tipo;
    if (this.cache[clave]) return Promise.resolve(this.cache[clave]);
    return this.lista(this.url('get_' + tipo + '_categories')).then(function (datos) {
        var salida = [];
        for (var i = 0; i < datos.length; i++) {
            var nombre = Comun.texto(datos[i].category_name);
            // adulto: va en la sección Adultos (protegida con PIN) y no en las demás.
            salida.push({ id: Comun.texto(datos[i].category_id), nombre: nombre, tipo: tipo, adulto: ADULTOS.test(nombre.toLowerCase()) });
        }
        yo.cache[clave] = salida;
        return salida;
    });
};

/** Categorías de varios tipos, solo las de adultos o solo las otras. */
Xtream.prototype.listaDeCategorias = function (tipos, adultos) {
    var yo = this;
    return Promise.all(tipos.map(function (t) { return yo.categorias(t); })).then(function (listas) {
        var salida = [];
        listas.forEach(function (l) { l.forEach(function (c) { if (c.adulto === adultos) salida.push(c); }); });
        return salida;
    });
};

/** Canales, películas o series de una categoría ('' = todo). La categoría se le pide al servidor
 *  (&category_id=), como en Android y Roku. Se guardan mientras dure la sesión. */
Xtream.prototype.elementos = function (tipo, categoria) {
    var yo = this, clave = 'el/' + tipo + '/' + (categoria || '');
    if (this.cache[clave]) return Promise.resolve(this.cache[clave]);
    var serie = tipo === 'series';
    var extra = categoria ? '&category_id=' + encodeURIComponent(categoria) : '';
    return this.categorias(tipo).then(function (cats) {
        var deAdultos = {};
        cats.forEach(function (c) { if (c.adulto) deAdultos[c.id] = true; });
        return yo.lista(yo.url(serie ? 'get_series' : 'get_' + tipo + '_streams', extra)).then(function (datos) {
            var salida = [];
            for (var i = 0; i < datos.length; i++) {
                var o = datos[i] || {};
                var id = Comun.texto(serie ? o.series_id : o.stream_id);
                if (!id) continue;
                var nota = Comun.numero(o.rating_5based);
                if (!(nota > 0)) nota = Math.max(0, Comun.numero(o.rating)) / 2;
                var cat = Comun.texto(o.category_id), cats = [cat];
                if (o.category_ids && o.category_ids.length) for (var k = 0; k < o.category_ids.length; k++) cats.push(Comun.texto(o.category_ids[k]));
                salida.push({
                    tipo: tipo, id: id, nombre: Comun.texto(o.name), icono: Comun.texto(serie ? o.cover : o.stream_icon),
                    ext: Comun.texto(o.container_extension), agregado: Comun.numero(serie ? o.last_modified : o.added), nota: nota, cats: cats,
                    // Lo marca el servidor (is_adult) o pertenece a una categoría de adultos.
                    adulto: Comun.texto(o.is_adult) === '1' || deAdultos[cat] === true || deAdultos[categoria] === true
                });
            }
            yo.cache[clave] = salida;
            return salida;
        });
    });
};

/** Lo de una categoría, solo de adultos o solo lo demás. Si el servidor no filtra por categoría,
 *  se busca en la lista completa. */
Xtream.prototype.filtrar = function (tipo, categoria, adultos) {
    var yo = this;
    return this.elementos(tipo, categoria).then(function (lista) {
        var salida = lista.filter(function (e) { return e.adulto === adultos; });
        if (salida.length || !categoria) return salida;
        return yo.elementos(tipo, '').then(function (todo) {
            return todo.filter(function (e) { return e.adulto === adultos && e.cats.indexOf(categoria) >= 0; });
        });
    });
};

/** Inicio: «Estrenos destacados» (agregadas más recientemente) y «Tendencias» (mejor calificadas). */
Xtream.prototype.inicio = function () {
    return this.filtrar('vod', '', false).then(function (pelis) {
        var recientes = pelis.slice().sort(function (a, b) { return b.agregado - a.agregado; }).slice(0, 20);
        var mejores = pelis.slice().sort(function (a, b) { return b.nota - a.nota; }).slice(0, 20);
        return [{ titulo: 'Estrenos destacados', lista: recientes }, { titulo: 'Tendencias', lista: mejores }];
    });
};

Xtream.prototype.todo = function () {
    var yo = this;
    return Promise.all(['live', 'vod', 'series'].map(function (t) { return yo.elementos(t, ''); })).then(function (l) {
        return l[0].concat(l[1], l[2]).filter(function (e) { return !e.adulto; });
    });
};

Xtream.prototype.favoritos = function (ids) {
    if (!ids || !ids.length) return Promise.resolve([]);
    return this.todo().then(function (todo) {
        return todo.filter(function (e) { return ids.indexOf(e.tipo + ':' + e.id) >= 0; });
    });
};

Xtream.prototype.buscar = function (texto) {
    var buscado = Comun.plano(texto);
    if (!buscado) return Promise.resolve([]);
    return this.todo().then(function (todo) {
        return todo.filter(function (e) { return Comun.plano(e.nombre).indexOf(buscado) >= 0; }).slice(0, 300);
    });
};

/** Datos de una serie y sus temporadas (ordenadas por número) con los episodios. */
Xtream.prototype.serie = function (id) {
    return this.pedir(this.url('get_series_info', '&series_id=' + encodeURIComponent(id))).then(function (d) {
        d = d || {};
        var info = d.info || {};
        var salida = { titulo: Comun.texto(info.name), sinopsis: Comun.texto(info.plot), portada: Comun.texto(info.cover), temporadas: [] };
        var porTemporada = d.episodes || {}, temporadas = [];
        if (Object.prototype.toString.call(porTemporada) === '[object Array]') {
            porTemporada.forEach(function (lista, i) { temporadas.push({ nombre: String(i + 1), orden: i + 1, lista: lista }); });
        } else {
            Object.keys(porTemporada).forEach(function (t) {
                var orden = parseInt(t, 10);
                temporadas.push({ nombre: t, orden: isFinite(orden) ? orden : 99999, lista: porTemporada[t] });
            });
        }
        temporadas.sort(function (a, b) { return a.orden - b.orden; });
        temporadas.forEach(function (t) {
            if (!t.lista || !t.lista.length) return;
            var episodios = [];
            t.lista.forEach(function (o) {
                if (!o || !Comun.texto(o.id)) return;
                var i = o.info || {};
                episodios.push({
                    tipo: 'episode', id: Comun.texto(o.id), nombre: Comun.texto(o.title) || 'Episodio ' + Comun.texto(o.episode_num),
                    icono: Comun.texto(i.movie_image), ext: Comun.texto(o.container_extension), aspecto: aspectoDe(i.video)
                });
            });
            if (episodios.length) salida.temporadas.push({ nombre: 'Temporada ' + t.nombre, episodios: episodios });
        });
        return salida;
    });
};

/** Programa actual y siguientes de un canal; lista vacía si no tiene guía. */
Xtream.prototype.guia = function (id) {
    return this.pedir(this.url('get_short_epg', '&stream_id=' + encodeURIComponent(id) + '&limit=3'), 15000).then(function (d) {
        return ((d && d.epg_listings) || []).map(function (p) {
            var titulo = decodificar(Comun.texto(p.title));
            var desde = Comun.numero(p.start_timestamp), hasta = Comun.numero(p.stop_timestamp);
            if (desde > 0 && hasta > 0) return Comun.hora(new Date(desde * 1000)) + ' – ' + Comun.hora(new Date(hasta * 1000)) + '   ' + titulo;
            return titulo;
        });
    }, function () { return []; });
};

/** Proporción real de una película según lo que midió el XUI (info.video), o 0. */
Xtream.prototype.aspectoDePelicula = function (id) {
    return this.pedir(this.url('get_vod_info', '&vod_id=' + encodeURIComponent(id)), 15000).then(function (d) {
        return aspectoDe(d && d.info && d.info.video);
    }, function () { return 0; });
};

Xtream.prototype.urlDeVideo = function (e) {
    var quien = '/' + encodeURIComponent(this.usuario) + '/' + encodeURIComponent(this.clave) + '/' + e.id;
    if (e.tipo === 'live') return this.base + '/live' + quien + (this.m3u8 ? '.m3u8' : '.ts');
    return this.base + (e.tipo === 'episode' ? '/series' : '/movie') + quien + '.' + (e.ext || 'mp4');
};

function aspectoDe(v) {
    if (!v) return 0;
    var a = razon(Comun.texto(v.display_aspect_ratio));
    if (a > 0.5 && a < 4) return a;
    var ancho = Comun.numero(v.width), alto = Comun.numero(v.height);
    if (ancho <= 0 || alto <= 0) return 0;
    var s = razon(Comun.texto(v.sample_aspect_ratio));
    return s > 0 ? ancho * s / alto : 0;
}

/** "16:9" → 1.777…; 0 si no es una razón válida. */
function razon(t) {
    var p = t.split(':');
    if (p.length !== 2) return 0;
    var n = parseFloat(p[0]), d = parseFloat(p[1]);
    return n > 0 && d > 0 ? n / d : 0;
}

/** Los títulos de la guía llegan en base64 (UTF-8). */
function decodificar(base64) {
    try {
        return decodeURIComponent(escape(atob(base64))).replace(/^\s+|\s+$/g, '');
    } catch (e) {
        return base64;
    }
}
