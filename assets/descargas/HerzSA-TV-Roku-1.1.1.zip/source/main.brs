' HerzSA TV para Roku: arranque. Toda la interfaz está en components/MainScene.
' Aquí también llegan los enlaces directos (al abrir la app o con roInput mientras está abierta) y los
' avisos de memoria del sistema, que se pasan a la escena.
sub Main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)
    scene = screen.CreateScene("MainScene")
    screen.Show()
    ' La escena pone «salir» cuando el usuario confirma que quiere cerrar la app.
    scene.observeField("salir", port)

    ' Enlace directo al abrir (contentId + mediaType) y enlaces con la app ya abierta (roInput).
    pasarEnlace(scene, args)
    entrada = CreateObject("roInput")
    entrada.SetMessagePort(port)

    ' Memoria: límite de la app y avisos cuando queda poca.
    memoria = CreateObject("roAppMemoryMonitor")
    if memoria <> invalid
        memoria.SetMessagePort(port)
        memoria.EnableMemoryWarningEvent(true)
        print "Memoria: límite "; FormatJson(memoria.GetChannelMemoryLimit()); ", libre "; memoria.GetChannelAvailableMemory(); " KB, usado "; memoria.GetMemoryLimitPercent(); " %"
    end if
    equipo = CreateObject("roDeviceInfo")
    equipo.SetMessagePort(port)
    equipo.EnableLowGeneralMemoryEvent(true)

    while true
        msg = wait(0, port)
        tipo = type(msg)
        if tipo = "roSGScreenEvent"
            if msg.IsScreenClosed() then return
        else if tipo = "roSGNodeEvent"
            if msg.GetField() = "salir" then return
        else if tipo = "roInputEvent"
            if msg.IsInput() then pasarEnlace(scene, msg.GetInfo())
        else if tipo = "roAppMemoryNotificationEvent"
            avisarMemoria(scene, memoria)
        else if tipo = "roDeviceInfoEvent"
            info = msg.GetInfo()
            if info <> invalid and info.generalMemoryLevel <> invalid and info.generalMemoryLevel <> "normal" then avisarMemoria(scene, memoria)
        end if
    end while
end sub

sub pasarEnlace(scene as object, datos as dynamic)
    if type(datos) <> "roAssociativeArray" then return
    if datos.contentId = invalid or datos.mediaType = invalid then return
    id = datos.contentId.ToStr().Trim()
    if id = "" then return
    scene.enlace = { id: id, tipo: LCase(datos.mediaType.ToStr().Trim()) }
end sub

sub avisarMemoria(scene as object, memoria as dynamic)
    if memoria <> invalid then print "Memoria baja: usado "; memoria.GetMemoryLimitPercent(); " %"
    scene.memoriaBaja = true
end sub
