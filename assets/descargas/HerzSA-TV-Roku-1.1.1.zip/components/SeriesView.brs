' Serie: la escena pone «datos» y «contenido» (temporadas con episodios); al elegir un episodio
' se avisa en «elegido» {temporada, episodio} y la escena abre el reproductor con esa temporada.

sub init()
    m.portada = m.top.findNode("portada")
    m.titulo = m.top.findNode("titulo")
    m.sinopsis = m.top.findNode("sinopsis")
    m.temporadas = m.top.findNode("temporadas")
    m.episodios = m.top.findNode("episodios")
    m.estado = m.top.findNode("estado")
    m.temporadas.observeField("itemFocused", "alEnfocarTemporada")
    m.episodios.observeField("itemSelected", "alElegirEpisodio")
    m.temporada = 0
end sub

sub pintarDatos()
    d = m.top.datos
    if d = invalid then return
    if d.titulo <> invalid and d.titulo <> "" then m.titulo.text = d.titulo
    if d.sinopsis <> invalid then m.sinopsis.text = d.sinopsis
    if d.portada <> invalid and d.portada <> "" then m.portada.uri = d.portada
end sub

sub pintarTemporadas()
    c = m.top.contenido
    if c = invalid or c.getChildCount() = 0
        m.estado.text = "Esta serie todavía no tiene episodios."
        return
    end if
    m.estado.text = ""
    m.temporadas.content = c
    m.temporada = 0
    m.episodios.content = c.getChild(0)
end sub

sub pintarError()
    m.estado.text = m.top.error
end sub

sub alEnfocarTemporada()
    c = m.top.contenido
    i = m.temporadas.itemFocused
    if c = invalid or i < 0 or i >= c.getChildCount() then return
    m.temporada = i
    m.episodios.content = c.getChild(i)
end sub

sub alElegirEpisodio()
    m.top.elegido = { temporada: m.temporada, episodio: m.episodios.itemSelected }
end sub

sub darFoco()
    if m.episodios.content <> invalid and m.episodios.content.getChildCount() > 0
        m.episodios.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

function onKeyEvent(tecla as string, presionada as boolean) as boolean
    if not presionada then return false
    if tecla = "back"
        m.top.cerrado = true
        return true
    else if tecla = "left" and m.temporadas.content <> invalid
        m.temporadas.setFocus(true)
        return true
    else if tecla = "right" and m.episodios.content <> invalid
        m.episodios.setFocus(true)
        return true
    end if
    return false
end function
