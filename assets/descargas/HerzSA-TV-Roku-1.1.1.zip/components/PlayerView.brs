' Reproductor. En vivo: arriba/abajo cambian de canal, OK muestra el programa actual y los
' siguientes, izquierda/derecha cambian el formato (el canal lo recuerda). Películas y series:
' cualquier tecla muestra los botones transparentes (Volver, Retroceder, Pausa/Reproducir,
' Adelantar) con el avance; ◄ ► eligen y OK acepta. Arriba se ven la fecha, la hora y la red.
' Se retoma donde se quedó y al terminar un episodio sigue el siguiente. El botón * abre el menú
' «Reproductor de Video» (Subtítulos, Audio, Video). Si se cae la señal reintenta solo.
' El formato elegido se recuerda: por canal en vivo, y uno solo para películas y series.

sub init()
    for each id in ["video", "capa", "nombre", "hora", "guia", "teclas", "avisoFormato", "estado", "relojCapa", "relojFormato", "relojReintento", "relojZapeo", "arriba", "tituloArriba", "fecha", "red", "controles", "f0", "f1", "f2", "f3", "iconoPausa", "textoPausa", "barra", "tiempo", "duracion", "ayudaControles", "relojControles"]
        m[id] = m.top.findNode(id)
    end for
    m.OPCIONES = ["Automático", "Completo", "Llenar", "Zoom"]
    m.video.notificationInterval = 1
    m.video.observeField("state", "alCambiarEstado")
    m.video.observeField("position", "alAvanzar")
    m.video.observeField("streamingSegment", "alSegmento")
    m.video.observeField("downloadedSegment", "alDescargado")
    m.relojCapa.observeField("fire", "ocultarCapa")
    m.relojFormato.observeField("fire", "ocultarFormato")
    m.relojReintento.observeField("fire", "arrancar")
    m.relojZapeo.observeField("fire", "alTerminarZapeo")
    m.relojControles.observeField("fire", "ocultarControles")
    m.boton = 2
    m.vivo = false
    m.api = invalid
    m.n = 0
    m.nodo = invalid
    m.ancho = 0
    m.alto = 0
    m.aspectoMeta = 0
    m.nVideo = -1
    m.nGuia = -1
    m.formatoReal = invalid
    m.ultimoGuardado = 0
    m.menuAbierto = false
    ' El usuario prendió los subtítulos en vivo: siguen prendidos al cambiar de canal.
    m.subsVivo = false
    armarMenu()
end sub

sub alIniciar()
    m.api = CreateObject("roSGNode", "ApiTask")
    m.api.observeField("respuesta", "alResponder")
    m.api.control = "RUN"
    m.formatos = LeerDato("formatos", {})
    m.formatoVod = LeerDato("formatoVod", "")
    leerAjustes()
    m.posiciones = LeerDato("posiciones", {})
    ponerElemento(m.top.indice)
    darFoco()
end sub

' En vivo el foco va al video; en películas a este componente, que maneja todas las teclas.
sub darFoco()
    if m.vivo then m.video.setFocus(true) else m.top.setFocus(true)
end sub

sub alDetener()
    guardarPosicion(true)
    m.relojReintento.control = "stop"
    m.relojZapeo.control = "stop"
    m.video.control = "stop"
    if m.api <> invalid then m.api.control = "stop"
end sub

sub cerrar(motivo as string)
    alDetener()
    m.top.cerrado = motivo
end sub

' ---------- Elemento actual ----------
function esVivo(nodo as object) as boolean
    return nodo <> invalid and Left(nodo.id, 5) = "live:"
end function

function reproducible(nodo as object) as boolean
    return nodo <> invalid and nodo.url <> invalid and nodo.url <> ""
end function

sub ponerElemento(i as integer)
    guardarPosicion(true)
    nodo = m.top.lista.getChild(i)
    if not reproducible(nodo)
        cerrar("regresar")
        return
    end if
    m.indice = i
    m.nodo = nodo
    m.vivo = esVivo(nodo)
    m.reintentos = 0
    m.posicion = 0
    m.ancho = 0
    m.alto = 0
    m.aspectoMeta = 0
    m.nVideo = -1
    if not m.vivo
        ' Proporción real: la del episodio viene con la serie; la de una película se pide al XUI.
        if nodo.aspecto <> invalid and nodo.aspecto > 0
            m.aspectoMeta = nodo.aspecto
        else if Left(nodo.id, 4) = "vod:"
            m.n = m.n + 1
            m.nVideo = m.n
            v = { n: m.n, accion: "video", id: Mid(nodo.id, 5) }
            v.Append(cuenta())
            m.api.solicitud = v
        end if
    end if
    if not m.vivo
        guardada = m.posiciones[nodo.id]
        if guardada <> invalid and guardada > 30 then m.posicion = guardada
    end if
    m.formato = m.formatoBase
    if m.vivo and m.formatos[nodo.id] <> invalid then m.formato = m.formatos[nodo.id]
    if not m.vivo and m.formatoVod <> "" then m.formato = m.formatoVod
    if Posicion(m.OPCIONES, m.formato) < 0 then m.formato = m.formatoBase
    if m.menuAbierto then cerrarMenu()
    m.capa.visible = false
    m.controles.visible = false
    m.arriba.visible = false
    if m.vivo then mostrarCapa() else mostrarControles()
    arrancar()
    darFoco()
    if m.posicion > 0 then avisar("Continuando donde te quedaste")
end sub

sub arrancar()
    m.relojReintento.control = "stop"
    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.nodo.url
    c.streamFormat = m.nodo.streamFormat
    c.title = m.nodo.title
    c.live = m.vivo
    if m.posicion > 0 then c.PlayStart = m.posicion
    ' Películas: sin la interfaz de Roku, van los botones propios. En vivo se deja la de Roku
    ' (sin ella el canal no arrancaba en las pruebas); su pantalla de carga trae título y hora,
    ' así que mientras carga se esconde la barra de arriba (alCambiarEstado).
    m.video.enableTrickPlay = false
    m.video.enableUI = m.vivo
    ' Subtítulos: en TV abierta apagados de inicio (se prenden en el menú); en películas y series,
    ' según el ajuste de subtítulos del Roku.
    m.video.suppressCaptions = m.vivo and not m.subsVivo
    m.video.content = c
    m.video.control = "play"
    if m.reintentos = 0 then m.estado.text = ""
    aplicarFormato()
end sub

sub alCambiarEstado()
    s = m.video.state
    if not m.vivo then actualizarPausa()
    if s = "playing"
        m.reintentos = 0
        m.estado.text = ""
        if m.controles.visible then esconderLuego()
        if m.vivo and m.capa.visible then m.arriba.visible = true
    else if s = "buffering" and m.vivo
        m.arriba.visible = false
    else if s = "buffering" and m.reintentos = 0
        m.estado.text = "Cargando…"
    else if s = "paused"
        mostrarControles()
    else if s = "error"
        falla()
    else if s = "finished"
        if m.vivo
            ' Un canal en vivo no termina: se cortó la señal.
            falla()
        else
            m.posiciones.Delete(m.nodo.id)
            m.posicion = 0
            guardarPosicion(true)
            siguiente = m.indice + 1
            if Left(m.nodo.id, 8) = "episode:" and reproducible(m.top.lista.getChild(siguiente))
                ponerElemento(siguiente)
            else
                cerrar("regresar")
            end if
        end if
    end if
end sub

sub falla()
    if m.reintentos < 3
        m.reintentos = m.reintentos + 1
        m.estado.text = "Reconectando… (" + m.reintentos.ToStr() + " de 3)"
        m.relojReintento.control = "start"
        return
    end if
    que = "este video"
    if m.vivo then que = "este canal"
    detalle = m.video.errorMsg
    texto = "No se pudo reproducir " + que + "."
    if detalle <> invalid and detalle <> "" then texto = texto + Chr(10) + "(" + detalle + ")"
    if m.vivo then texto = texto + Chr(10) + "Prueba otro canal con arriba o abajo."
    m.estado.text = texto
end sub

' ---------- Posición de películas y episodios ----------
sub alAvanzar()
    if m.vivo or m.nodo = invalid then return
    if m.video.position > 0 then m.posicion = m.video.position
    if m.controles.visible then actualizarAvance()
    guardarPosicion(false)
end sub

sub guardarPosicion(ahora as boolean)
    if m.nodo = invalid or m.vivo or m.posiciones = invalid then return
    reloj = CreateObject("roDateTime").AsSeconds()
    if not ahora and reloj - m.ultimoGuardado < 30 then return
    m.ultimoGuardado = reloj
    duracion = m.video.duration
    if m.posicion > 30 and (duracion = invalid or duracion <= 0 or m.posicion < duracion - 60)
        m.posiciones[m.nodo.id] = Int(m.posicion)
    else
        m.posiciones.Delete(m.nodo.id)
    end if
    if m.posiciones.Count() > 300 then m.posiciones = {}
    GuardarDato("posiciones", m.posiciones)
end sub

' ---------- Canal: cambiar y mostrar guía ----------
sub zapear(paso as integer)
    lista = m.top.lista
    total = lista.getChildCount()
    j = m.indice
    if m.pendiente <> invalid then j = m.pendiente
    for k = 1 to total
        j = (j + paso + total) mod total
        if esVivo(lista.getChild(j)) then exit for
    end for
    m.pendiente = j
    ' El nombre cambia en seguida; el video arranca cuando se deja de pulsar.
    m.nombre.text = lista.getChild(j).title
    m.guia.text = ""
    m.capa.visible = true
    m.relojCapa.control = "stop"
    m.relojZapeo.control = "stop"
    m.relojZapeo.control = "start"
end sub

sub alTerminarZapeo()
    j = m.pendiente
    m.pendiente = invalid
    if j <> invalid and j <> m.indice then ponerElemento(j)
end sub

sub mostrarCapa()
    actualizarArriba("TV en vivo")
    m.arriba.visible = m.video.state = "playing"
    m.nombre.text = m.nodo.title
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    m.hora.text = DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
    if m.vivo
        m.guia.text = ""
        ponerTeclas()
        m.n = m.n + 1
        m.nGuia = m.n
        s = { n: m.n, accion: "guia", id: Mid(m.nodo.id, 6) }
        s.Append(cuenta())
        m.api.solicitud = s
    end if
    m.capa.visible = true
    m.relojCapa.control = "stop"
    m.relojCapa.control = "start"
end sub

' Vuelve a abrir el canal en vivo. La sincronía de imagen y sonido la hace el Roku al decodificar
' (una app no puede adelantar ni atrasar el audio); si la señal del XUI trae los tiempos mal, el
' desfase se acumula y la única corrección desde aquí es arrancar el canal de nuevo.
sub resincronizar()
    m.reintentos = 0
    m.estado.text = ""
    arrancar()
    avisar("Sincronizando imagen y sonido…")
end sub

sub ponerTeclas()
    m.teclas.text = "Arriba y abajo: canal      Izquierda y derecha: formato (" + m.formato + ")      *: menú (subtítulos, audio y video)      Atrás: salir"
    m.ayudaControles.text = "Izquierda y derecha: elegir botón      OK: aceptar      *: menú (subtítulos, audio y video)      Atrás: salir"
end sub

sub actualizarArriba(titulo as string)
    m.tituloArriba.text = titulo
    m.fecha.text = FechaYHora()
    m.red.text = NombreRed()
end sub

' ---------- Botones de películas y episodios ----------
sub mostrarControles()
    if not m.controles.visible then m.boton = 2
    actualizarArriba(m.nodo.title)
    ponerTeclas()
    actualizarPausa()
    pintarBotones()
    actualizarAvance()
    m.arriba.visible = true
    m.controles.visible = true
    esconderLuego()
end sub

' Se esconden a los 5 s sin tocar nada, salvo en pausa.
sub esconderLuego()
    m.relojControles.control = "stop"
    if m.video.state <> "paused" then m.relojControles.control = "start"
end sub

sub ocultarControles()
    if m.video.state = "paused" then return
    m.controles.visible = false
    m.arriba.visible = false
end sub

sub pintarBotones()
    for i = 0 to 3
        f = m["f" + i.ToStr()]
        if i = m.boton
            f.blendColor = "0x6CD83CFF"
            f.opacity = 1.0
        else
            f.blendColor = "0x000000FF"
            f.opacity = 0.45
        end if
    end for
end sub

sub actualizarPausa()
    if m.video.state = "paused"
        m.iconoPausa.uri = "pkg:/images/boton_play.png"
        m.textoPausa.text = "Reproducir"
    else
        m.iconoPausa.uri = "pkg:/images/boton_pausa.png"
        m.textoPausa.text = "Pausa"
    end if
end sub

sub actualizarAvance()
    actual = m.video.position
    dur = m.video.duration
    if actual = invalid or actual < 0 then actual = 0
    if dur = invalid or dur < 0 then dur = 0
    m.tiempo.text = ATiempo(actual)
    if dur > 0
        m.duracion.text = ATiempo(dur)
        ancho = Int(1700 * actual / dur)
        if ancho > 1700 then ancho = 1700
        m.barra.width = ancho
    else
        m.duracion.text = ""
        m.barra.width = 0
    end if
    m.fecha.text = FechaYHora()
end sub

' 3725 → «1:02:05»; 125 → «2:05».
function ATiempo(segundos as float) as string
    t = Int(segundos)
    h = Int(t / 3600)
    mi = Int((t mod 3600) / 60)
    se = t mod 60
    if h > 0 then return h.ToStr() + ":" + DosCifras(mi) + ":" + DosCifras(se)
    return mi.ToStr() + ":" + DosCifras(se)
end function

sub alternarPausa()
    if m.video.state = "paused" then m.video.control = "resume" else m.video.control = "pause"
end sub

sub saltar(segundos as integer)
    p = m.video.position + segundos
    dur = m.video.duration
    if dur <> invalid and dur > 0 and p > dur - 5 then p = dur - 5
    if p < 0 then p = 0
    m.video.seek = p
    m.posicion = p
    avisar(ATiempo(p))
end sub

sub activarBoton()
    if m.boton = 0
        cerrar("regresar")
    else if m.boton = 1
        saltar(-10)
    else if m.boton = 2
        alternarPausa()
    else if m.boton = 3
        saltar(10)
    end if
end sub

function teclaDePelicula(tecla as string) as boolean
    ' Las teclas propias del control funcionan siempre.
    if tecla = "play"
        alternarPausa()
        mostrarControles()
        return true
    else if tecla = "rewind" or tecla = "fastforward" or tecla = "replay"
        if tecla = "rewind" then saltar(-30)
        if tecla = "fastforward" then saltar(30)
        if tecla = "replay" then saltar(-10)
        mostrarControles()
        return true
    end if
    ' Con los botones escondidos, la primera tecla solo los muestra.
    if not m.controles.visible
        mostrarControles()
        return true
    end if
    if tecla = "left"
        if m.boton > 0 then m.boton = m.boton - 1
    else if tecla = "right"
        if m.boton < 3 then m.boton = m.boton + 1
    else if tecla = "OK"
        activarBoton()
        if m.boton = 0 then return true
    else if tecla <> "up" and tecla <> "down"
        return false
    end if
    pintarBotones()
    esconderLuego()
    return true
end function

function cuenta() as object
    c = m.top.cuenta
    return { servidor: c.servidor, usuario: c.usuario, clave: c.clave }
end function

sub alResponder(ev as object)
    r = ev.getData()
    if r = invalid or r.datos = invalid then return
    if r.accion = "video"
        if r.n = m.nVideo and r.datos.aspecto <> invalid and r.datos.aspecto > 0
            m.aspectoMeta = r.datos.aspecto
            aplicarFormato()
        end if
        return
    end if
    if r.n <> m.nGuia then return
    lineas = r.datos.lineas
    if lineas = invalid or lineas.Count() = 0
        m.guia.text = "Sin guía de programación para este canal."
        return
    end if
    texto = ""
    for i = 0 to lineas.Count() - 1
        if i > 0 then texto = texto + Chr(10)
        if i = 0 then texto = texto + "Ahora:  " else texto = texto + "Después:  "
        texto = texto + lineas[i]
    end for
    m.guia.text = texto
end sub

sub ocultarCapa()
    m.capa.visible = false
    m.arriba.visible = false
end sub

' ---------- Formato de pantalla ----------
' Automático llena la pantalla recortando (nunca estira) si el video y la pantalla se parecen
' (hasta 34 % de diferencia, como en Android TV); si no, lo deja completo. Llenar recorta
' siempre para cubrir la pantalla y Zoom amplía un 33 % (quita las franjas que ya vienen
' dentro de la imagen). Roku no estira el video: siempre conserva la proporción.
'
' ajustes.json en el panel (lo baja MainScene al abrir la app) cambia esto sin publicar otra versión:
'   formato   el de inicio cuando el usuario no eligió otro ("Automático" o "Completo")
'   recortar  false = solo «Completo» (por si un modelo de Roku no recorta bien el video agrandado)
'   umbral    diferencia máxima de proporción para que Automático recorte (0.34)
sub leerAjustes()
    aj = LeerDato("ajustes", {})
    if type(aj) <> "roAssociativeArray" then aj = {}
    m.recortar = not (aj.recortar = false)
    m.umbral = 0.34
    if GetInterface(aj.umbral, "ifFloat") <> invalid or GetInterface(aj.umbral, "ifInt") <> invalid or GetInterface(aj.umbral, "ifDouble") <> invalid
        if aj.umbral >= 0 and aj.umbral <= 1 then m.umbral = aj.umbral
    end if
    if m.recortar
        m.OPCIONES = ["Automático", "Completo", "Llenar", "Zoom"]
    else
        m.OPCIONES = ["Completo"]
    end if
    m.formatoBase = m.OPCIONES[0]
    if aj.formato <> invalid and Posicion(m.OPCIONES, aj.formato) >= 0 then m.formatoBase = aj.formato
end sub

' Tamaño codificado del video: Roku lo da en los segmentos de HLS (en vivo); en MP4/MKV no.
sub alSegmento()
    s = m.video.streamingSegment
    if s <> invalid then tamano(s.width, s.height)
end sub

sub alDescargado()
    s = m.video.downloadedSegment
    if s <> invalid then tamano(s.Width, s.Height)
end sub

sub tamano(ancho as dynamic, alto as dynamic)
    if ancho = invalid or alto = invalid then return
    if ancho <= 0 or alto <= 0 then return
    if ancho = m.ancho and alto = m.alto then return
    m.ancho = ancho
    m.alto = alto
    aplicarFormato()
end sub

' Proporción del video, o 0 si no se sabe. Las resoluciones de TV estándar (720x480, 720x576,
' 1440x1080…) usan pixeles no cuadrados y su proporción real no se puede saber desde aquí.
function proporcion() as float
    if m.aspectoMeta > 0 then return m.aspectoMeta
    if m.ancho <= 0 or m.alto <= 0 then return 0
    if m.alto = 480 or m.alto = 576 or m.ancho = 1440 or m.ancho = 960 or (m.ancho = 1280 and m.alto = 1080) then return 0
    return m.ancho / m.alto
end function

sub aplicarFormato()
    pantalla = 1920 / 1080
    a = proporcion()
    f = m.formato
    if not m.recortar then f = "Completo"
    if f = "Automático"
        f = "Completo"
        if a > 0
            diferencia = Abs(a - pantalla) / pantalla
            if diferencia > 0.01 and diferencia <= m.umbral then f = "Llenar"
        end if
    end if
    ancho = 1920
    alto = 1080
    if f = "Llenar"
        if a <= 0 then a = 4 / 3
        if a < pantalla
            alto = Int(1920 / a)
        else
            ancho = Int(1080 * a)
        end if
    else if f = "Zoom"
        ancho = 2560
        alto = 1440
    end if
    m.formatoReal = f
    m.video.width = ancho
    m.video.height = alto
    m.video.translation = [Int((1920 - ancho) / 2), Int((1080 - alto) / 2)]
end sub

sub cambiarFormato()
    k = Posicion(m.OPCIONES, m.formato)
    m.formato = m.OPCIONES[(k + 1) mod m.OPCIONES.Count()]
    if m.vivo
        if m.formato = m.formatoBase then m.formatos.Delete(m.nodo.id) else m.formatos[m.nodo.id] = m.formato
        GuardarDato("formatos", m.formatos)
    else
        m.formatoVod = m.formato
        if m.formato = m.formatoBase then m.formatoVod = ""
        GuardarDato("formatoVod", m.formatoVod)
    end if
    aplicarFormato()
    ponerTeclas()
    if m.formato = "Automático" and m.formatoReal <> invalid
        avisar("Formato: Automático (" + LCase(m.formatoReal) + ")")
    else
        avisar("Formato: " + m.formato)
    end if
end sub

sub avisar(texto as string)
    m.avisoFormato.text = texto
    m.avisoFormato.visible = true
    m.relojFormato.control = "stop"
    m.relojFormato.control = "start"
end sub

sub ocultarFormato()
    m.avisoFormato.visible = false
end sub

function onKeyEvent(tecla as string, presionada as boolean) as boolean
    if not presionada then return false
    if m.menuAbierto then return teclaMenu(tecla)
    if tecla = "back"
        cerrar("regresar")
        return true
    else if tecla = "options"
        abrirMenu()
        return true
    end if
    if not m.vivo then return teclaDePelicula(tecla)
    if tecla = "up" or tecla = "channelup"
        zapear(1)
        return true
    else if tecla = "down" or tecla = "channeldown"
        zapear(-1)
        return true
    else if tecla = "left" or tecla = "right"
        cambiarFormato()
        return true
    else if tecla = "replay" or tecla = "play"
        resincronizar()
        return true
    else if tecla = "OK"
        if m.capa.visible then ocultarCapa() else mostrarCapa()
        return true
    end if
    return false
end function

' ---------- Menú «Reproductor de Video» (botón *) ----------
' Igual que en Android, Windows y Samsung (maqueta ../imagenes/menuiptv.png): Subtítulos, Audio (Sonido),
' Video (Calidad) y Salir del Menú. Arriba y abajo eligen, OK o derecha entran, Atrás o izquierda regresan.
' Imágenes y medidas: ops/menu_imagenes.sh (recuadro de 915 × 140 + 96 por fila, filas de 871 × 92 cada 96).

sub armarMenu()
    m.menu = m.top.findNode("menu")
    m.mf = []
    fuenteMenu(m.top.findNode("menuTitulo"), true, 52)
    filas = m.top.findNode("menuFilas")
    for i = 0 to 6
        g = filas.createChild("Group")
        f = {
            grupo: g
            fondo: g.createChild("Poster")
            icono: g.createChild("Poster")
            texto: g.createChild("Label")
            valor: g.createChild("Label")
            fin: g.createChild("Poster")
        }
        f.fondo.width = 871
        f.fondo.height = 92
        f.icono.width = 80
        f.icono.height = 56
        f.icono.translation = [26, 18]
        f.fin.width = 40
        f.fin.height = 40
        f.fin.translation = [803, 26]
        f.texto.height = 92
        f.texto.vertAlign = "center"
        f.texto.color = "0xFFFFFFFF"
        fuenteMenu(f.texto, true, 46)
        f.valor.height = 92
        f.valor.vertAlign = "center"
        f.valor.horizAlign = "right"
        fuenteMenu(f.valor, false, 38)
        m.mf.Push(f)
    end for
end sub

' Fuentes del sistema (las de cualquier Roku) a la medida de la maqueta.
sub fuenteMenu(etiqueta as object, negrita as boolean, medida as integer)
    if negrita then etiqueta.font = "font:MediumBoldSystemFont" else etiqueta.font = "font:MediumSystemFont"
    etiqueta.font.size = medida
end sub

sub abrirMenu()
    m.menuAbierto = true
    ocultarCapa()
    m.controles.visible = false
    m.relojControles.control = "stop"
    m.menu.visible = true
    m.top.setFocus(true)
    irA("principal", 0)
end sub

sub cerrarMenu()
    m.menuAbierto = false
    m.menu.visible = false
    darFoco()
end sub

sub irA(pantalla as string, elegida as integer)
    v = vistaMenu(pantalla)
    m.vm = v
    m.vm.pantalla = pantalla
    if elegida < 0 then elegida = v.elegida
    if elegida > v.filas.Count() - 1 then elegida = v.filas.Count() - 1
    if elegida < 0 then elegida = 0
    m.vm.elegida = elegida
    m.vm.primera = 0
    pintarMenu()
end sub

sub pintarMenu()
    v = m.vm
    total = v.filas.Count()
    visibles = total
    if visibles > 7 then visibles = 7
    if visibles < 2 then visibles = 2
    if v.elegida < v.primera then v.primera = v.elegida
    if v.elegida >= v.primera + 7 then v.primera = v.elegida - 6
    alto = 140 + 96 * visibles
    x0 = 502
    y0 = Int((1080 - alto) / 2)
    m.menuPanel = m.top.findNode("menuPanel")
    m.menuPanel.uri = "pkg:/images/d/m_panel_" + visibles.ToStr() + ".png"
    m.menuPanel.height = alto + 48
    m.menuPanel.translation = [x0 - 24, y0 - 24]
    ' ▶ y título centrados juntos; la ✕ a la derecha.
    titulo = m.top.findNode("menuTitulo")
    titulo.width = 0
    titulo.text = v.titulo
    ancho = titulo.boundingRect().width
    if ancho <= 0 or ancho > 640 then ancho = 640
    ' Margen para que la medida no corte la última letra.
    titulo.width = ancho + 40
    inicio = x0 + Int((915 - (72 + 22 + ancho)) / 2)
    m.top.findNode("menuPlay").translation = [inicio, y0 + 19]
    titulo.translation = [inicio + 94, y0]
    m.top.findNode("menuCerrar").translation = [x0 + 841, y0 + 37]
    y = y0 + 126
    for i = 0 to 6
        f = m.mf[i]
        k = v.primera + i
        if i >= visibles or k >= total
            f.grupo.visible = false
        else
            fila = v.filas[k]
            f.grupo.visible = true
            f.grupo.translation = [x0 + 22, y]
            elegida = k = v.elegida
            if elegida then f.fondo.uri = "pkg:/images/d/m_fila_sel.png" else f.fondo.uri = "pkg:/images/d/m_fila.png"
            if fila.icono <> invalid and fila.icono <> ""
                f.icono.uri = "pkg:/images/d/m_" + fila.icono + ".png"
                f.icono.visible = true
                f.texto.translation = [130, 0]
            else
                f.icono.visible = false
                f.texto.translation = [40, 0]
            end if
            f.texto.text = fila.texto
            finX = 871 - 28
            f.fin.visible = fila.fin = 1 or fila.fin = 2
            if fila.fin = 1 then f.fin.uri = "pkg:/images/d/m_flecha.png"
            if fila.fin = 2 then f.fin.uri = "pkg:/images/d/m_ok.png"
            if f.fin.visible then finX = 791
            valor = ""
            if fila.valor <> invalid then valor = fila.valor
            f.valor.text = valor
            f.valor.width = 420
            f.valor.translation = [finX - 420, 0]
            if elegida then f.valor.color = "0xE6F8FFFF" else f.valor.color = "0x6CD4FFFF"
            ' El texto llega hasta donde empieza el valor (unos 21 px por letra).
            reservado = 0
            if valor <> "" then reservado = Len(valor) * 21 + 20
            f.texto.width = finX - reservado - f.texto.translation[0] - 10
            y = y + 96
        end if
    end for
    barra = m.top.findNode("menuDesliza")
    if total > 7
        barra.visible = true
        zona = 7 * 96
        barra.height = Int(zona * 7 / total)
        barra.translation = [x0 + 915 - 13, y0 + 130 + Int(zona * v.primera / total)]
    else
        barra.visible = false
    end if
end sub

function teclaMenu(tecla as string) as boolean
    v = m.vm
    total = v.filas.Count()
    if tecla = "up"
        v.elegida = (v.elegida - 1 + total) mod total
        pintarMenu()
    else if tecla = "down"
        v.elegida = (v.elegida + 1) mod total
        pintarMenu()
    else if tecla = "OK" or tecla = "right"
        fila = v.filas[v.elegida]
        if tecla = "OK" or fila.fin = 1 then accionMenu(fila)
    else if tecla = "back" or tecla = "left"
        if v.atras <> "" then irA(v.atras, v.atrasFila) else cerrarMenu()
    else if tecla = "options"
        cerrarMenu()
    end if
    return true
end function

function filaMenu(icono as string, texto as string, valor as string, fin as integer, accion as string) as object
    return { icono: icono, texto: texto, valor: valor, fin: fin, accion: accion }
end function

function subtitulosActivos() as boolean
    if m.video.suppressCaptions = true then return false
    return m.video.globalCaptionMode = "On"
end function

function vistaMenu(pantalla as string) as object
    v = { titulo: "", filas: [], atras: "", atrasFila: 0, elegida: 0 }
    if pantalla = "principal"
        v.titulo = "Reproductor de Video"
        estado = "Desactivados"
        if subtitulosActivos() then estado = "Activados"
        v.filas.Push(filaMenu("cc", "Subtítulos", estado, 1, "subtitulos"))
        v.filas.Push(filaMenu("audio", "Audio (Sonido)", "", 1, "audio"))
        v.filas.Push(filaMenu("tv", "Video (Calidad)", "", 1, "video"))
        v.filas.Push(filaMenu("salir", "Salir del Menú", "", 0, "cerrar"))
    else if pantalla = "subtitulos"
        v.titulo = "Subtítulos"
        v.atras = "principal"
        activos = subtitulosActivos()
        fin = 2
        if activos then fin = 0
        v.filas.Push(filaMenu("", "Desactivados", "", fin, "subsNo"))
        pistas = m.video.availableSubtitleTracks
        if pistas = invalid then pistas = []
        actual = m.video.currentSubtitleTrack
        for i = 0 to pistas.Count() - 1
            p = pistas[i]
            fin = 0
            if activos and actual = p.TrackName then fin = 2
            if fin = 2 then v.elegida = i + 1
            f = filaMenu("", nombreSubtitulo(p, i + 1), "", fin, "subs")
            f.dato = p.TrackName
            v.filas.Push(f)
        end for
        if pistas.Count() = 0 then v.filas.Push(filaMenu("", "Esta transmisión no trae subtítulos", "", 0, ""))
        v.filas.Push(filaMenu("atras", "Regresar", "", 0, "principal:0"))
    else if pantalla = "audio"
        v.titulo = "Audio (Sonido)"
        v.atras = "principal"
        v.atrasFila = 1
        pistas = m.video.availableAudioTracks
        if pistas = invalid then pistas = []
        actual = m.video.currentAudioTrack
        if pistas.Count() > 1
            for i = 0 to pistas.Count() - 1
                p = pistas[i]
                fin = 0
                if actual = p.Track then fin = 2
                if fin = 2 then v.elegida = i
                f = filaMenu("", nombrePista(p.Name, p.Language, "Audio " + (i + 1).ToStr()), "", fin, "pistaAudio")
                f.dato = p.Track
                v.filas.Push(f)
            end for
        else
            idioma = "—"
            if pistas.Count() = 1 then idioma = nombrePista(pistas[0].Name, pistas[0].Language, "Audio 1")
            v.filas.Push(filaMenu("", "Idioma", idioma, 0, ""))
        end if
        ' Roku no deja adelantar ni atrasar el audio: se vuelve a abrir en el mismo punto.
        v.filas.Push(filaMenu("", "Sincronizar imagen y sonido", "", 0, "reabrir"))
        v.filas.Push(filaMenu("atras", "Regresar", "", 0, "principal:1"))
    else
        v.titulo = "Video (Calidad)"
        v.atras = "principal"
        v.atrasFila = 2
        calidad = ""
        if m.alto > 0 then calidad = m.alto.ToStr() + "p"
        if m.alto >= 2160 then calidad = "4K"
        v.filas.Push(filaMenu("tv", "Calidad automática", calidad, 2, "principal:2"))
        v.filas.Push(filaMenu("", "Formato de pantalla", m.formato, 1, "formato"))
        reabrir = "Volver a cargar"
        if m.vivo then reabrir = "Volver a abrir el canal"
        v.filas.Push(filaMenu("", reabrir, "", 0, "reabrir"))
        v.filas.Push(filaMenu("atras", "Regresar", "", 0, "principal:2"))
    end if
    return v
end function

sub accionMenu(fila as object)
    a = fila.accion
    if a = "" then return
    if a = "cerrar"
        cerrarMenu()
    else if a = "subtitulos" or a = "audio" or a = "video"
        irA(a, -1)
    else if Left(a, 10) = "principal:"
        irA("principal", Val(Mid(a, 11)))
    else if a = "subsNo"
        m.video.suppressCaptions = true
        if m.vivo then m.subsVivo = false
        irA("principal", 0)
    else if a = "subs"
        m.video.globalCaptionMode = "On"
        m.video.suppressCaptions = false
        m.video.subtitleTrack = fila.dato
        if m.vivo then m.subsVivo = true
        irA("principal", 0)
    else if a = "pistaAudio"
        m.video.audioTrack = fila.dato
        irA("principal", 1)
    else if a = "formato"
        cambiarFormato()
        irA("video", 1)
    else if a = "reabrir"
        cerrarMenu()
        if not m.vivo and m.video.position > 0 then m.posicion = m.video.position
        resincronizar()
    end if
end sub

function nombreSubtitulo(p as object, n as integer) as string
    nombre = p.TrackName
    if nombre = invalid then nombre = ""
    if LCase(Left(nombre, 6)) = "eia608" or LCase(Left(nombre, 6)) = "eia708" then return "CC (de la transmisión)"
    return nombrePista(p.Description, p.Language, "Subtítulo " + n.ToStr())
end function

function nombrePista(titulo as dynamic, idioma as dynamic, otro as string) as string
    nombres = { spa: "Español", es: "Español", eng: "Inglés", en: "Inglés", por: "Portugués", pt: "Portugués", fre: "Francés", fra: "Francés", fr: "Francés", ger: "Alemán", deu: "Alemán", de: "Alemán", ita: "Italiano", it: "Italiano", jpn: "Japonés", ja: "Japonés", kor: "Coreano", ko: "Coreano", chi: "Chino", zho: "Chino", zh: "Chino", rus: "Ruso", ru: "Ruso" }
    nombre = ""
    if idioma <> invalid and idioma <> "" and idioma <> "und"
        nombre = idioma
        if nombres[LCase(idioma)] <> invalid then nombre = nombres[LCase(idioma)]
    end if
    if titulo <> invalid and titulo <> ""
        if nombre = "" or Instr(1, titulo, nombre) > 0 then return titulo
        return titulo + " (" + nombre + ")"
    end if
    if nombre <> "" then return nombre
    return otro
end function
