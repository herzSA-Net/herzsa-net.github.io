' Tarea de red. Misma lógica que Xtream.java (Android) y xtream.js (Windows).
'
' Acciones (campo «accion» de la solicitud):
' Cada solicitud trae la cuenta (servidor, usuario, clave); si cambia se olvida lo guardado.
'   entrar      {}                          valida la cuenta → datos {estado, vence, conexiones, m3u8}
'   categorias  {tipos[], adultos}          → datos {lista: [{id, nombre, tipo}]}
'   elementos   {tipo, categoria, adultos}  → contenido (ContentNode con los elementos)
'   inicio      {}                          → contenido con dos filas: Estrenos y Tendencias
'   favoritos   {ids[]}                     → contenido
'   buscar      {texto}                     → contenido
'   serie       {id}                        → contenido (temporadas con episodios) y datos {titulo, sinopsis, portada}
'   guia        {id}                        → datos {lineas[]}
'   video       {id}                        → datos {aspecto} de una película (get_vod_info; 0 = no se sabe)
'   enlace      {tipo, id}                  enlace directo de Roku (live, vod, series, episode) → contenido (lista)
'                                           y datos {indice} del elemento dentro de esa lista
'   olvidar     {}                          borra las listas guardadas (aviso de memoria baja)
'   ajustes     {url}                       → datos (ajustes.json del panel: formato de pantalla)
' Todas aceptan «favoritos» (lista de ids) para marcar la estrella en lo que devuelven.
' Si algo falla, la respuesta trae ok=false, error (texto para el usuario) y cuenta=true si
' el problema es la cuenta (vencida, suspendida o contraseña incorrecta).

sub init()
    m.top.functionName = "principal"
end sub

sub principal()
    m.puerto = CreateObject("roMessagePort")
    m.top.observeField("solicitud", m.puerto)
    m.cache = {}
    m.base = ""
    m.usuario = ""
    m.clave = ""
    m.m3u8 = true
    m.ts = true
    m.escape = CreateObject("roUrlTransfer")
    m.adultos = CreateObject("roRegex", "adult|xxx|porn|erotic|\+\s?18|18\s?\+|\bsex|playboy|hentai", "i")
    ' La pantalla pudo poner la primera solicitud antes de que esta tarea empezara a escuchar.
    primera = m.top.solicitud
    if primera <> invalid and primera.accion <> invalid then atender(primera)
    while true
        msg = wait(0, m.puerto)
        if type(msg) = "roSGNodeEvent"
            s = msg.getData()
            if s <> invalid and s.accion <> invalid then atender(s)
        end if
    end while
end sub

sub atender(s as object)
    m.fallo = ""
    m.errorDeCuenta = false
    m.favoritos = {}
    if s.favoritos <> invalid
        for each id in s.favoritos
            m.favoritos[id] = true
        end for
    end if
    r = { n: s.n, accion: s.accion, ok: true, error: "", cuenta: false }
    a = s.accion
    if s.servidor <> invalid
        nueva = Normalizar(Cadena(s.servidor))
        if nueva <> m.base or Cadena(s.usuario) <> m.usuario or Cadena(s.clave) <> m.clave then m.cache = {}
        m.base = nueva
        m.usuario = Cadena(s.usuario)
        m.clave = Cadena(s.clave)
    end if
    if a = "entrar"
        r.datos = entrar()
    else if a = "categorias"
        r.datos = { lista: listaDeCategorias(s.tipos, s.adultos = true) }
    else if a = "elementos"
        r.contenido = nodoDe(filtrar(s.tipo, Cadena(s.categoria), s.adultos = true))
    else if a = "inicio"
        r.contenido = inicio()
    else if a = "favoritos"
        r.contenido = favoritos(s.ids)
    else if a = "buscar"
        r.contenido = buscar(Cadena(s.texto))
    else if a = "serie"
        r.contenido = serie(Cadena(s.id), r)
    else if a = "guia"
        r.datos = { lineas: guia(Cadena(s.id)) }
    else if a = "video"
        r.datos = { aspecto: aspectoDePelicula(Cadena(s.id)) }
        m.fallo = ""
    else if a = "olvidar"
        m.cache = {}
    else if a = "enlace"
        r.contenido = enlace(Cadena(s.tipo), Cadena(s.id), r)
    else if a = "ajustes"
        r.datos = pedir(Cadena(s.url), 6000)
        if type(r.datos) <> "roAssociativeArray" and m.fallo = "" then m.fallo = "Ajustes no válidos."
    end if
    if m.fallo <> ""
        r.ok = false
        r.error = m.fallo
        r.cuenta = m.errorDeCuenta
    end if
    m.top.respuesta = r
end sub

function Normalizar(servidor as string) as string
    s = servidor.Trim()
    if s = "" then s = "http://172.10.20.185"
    if LCase(Left(s, 7)) <> "http://" and LCase(Left(s, 8)) <> "https://" then s = "http://" + s
    while Right(s, 1) = "/"
        s = Left(s, Len(s) - 1)
    end while
    return s
end function

function esc(s as string) as string
    return m.escape.Escape(s)
end function

function urlApi(accion as string, extra = "" as string) as string
    u = m.base + "/player_api.php?username=" + esc(m.usuario) + "&password=" + esc(m.clave)
    if accion <> "" then u = u + "&action=" + accion + extra
    return u
end function

' GET con límite (40 s por omisión); devuelve el JSON ya interpretado o invalid (y deja m.fallo).
function pedir(url as string, espera = 40000 as integer) as dynamic
    if m.fallo <> "" then return invalid
    t = CreateObject("roUrlTransfer")
    p = CreateObject("roMessagePort")
    t.SetMessagePort(p)
    t.SetUrl(url)
    if LCase(Left(url, 6)) = "https:"
        t.SetCertificatesFile("common:/certs/ca-bundle.crt")
    end if
    t.EnableEncodings(true)
    t.RetainBodyOnError(true)
    if not t.AsyncGetToString()
        m.fallo = "Sin conexión con HerzSA TV. Funciona solo en la red de HerzSA.Net y en redes MultiNet."
        return invalid
    end if
    msg = wait(espera, p)
    if type(msg) <> "roUrlEvent"
        t.AsyncCancel()
        m.fallo = "Sin conexión con HerzSA TV. Funciona solo en la red de HerzSA.Net y en redes MultiNet."
        return invalid
    end if
    codigo = msg.GetResponseCode()
    if codigo < 0
        m.fallo = "Sin conexión con HerzSA TV. Funciona solo en la red de HerzSA.Net y en redes MultiNet."
        return invalid
    else if codigo <> 200
        m.fallo = "Sin conexión con HerzSA TV. Funciona solo en la red de HerzSA.Net y en redes MultiNet (error " + codigo.ToStr() + ")."
        return invalid
    end if
    cuerpo = msg.GetString()
    if cuerpo = invalid or cuerpo.Trim() = "" or cuerpo.Trim() = "null" then return {}
    datos = ParseJson(cuerpo)
    if datos = invalid then m.fallo = "Sin conexión con HerzSA TV. Funciona solo en la red de HerzSA.Net y en redes MultiNet."
    return datos
end function

' Algunos paneles devuelven un objeto vacío en lugar de una lista vacía.
function pedirLista(url as string) as object
    datos = pedir(url)
    if type(datos) = "roArray" then return datos
    return []
end function

function falloDeCuenta(mensaje as string) as dynamic
    m.fallo = mensaje
    m.errorDeCuenta = true
    return invalid
end function

' Valida la cuenta y lee estado, vencimiento y formatos permitidos.
function entrar() as dynamic
    raiz = pedir(urlApi(""))
    if raiz = invalid then return invalid
    info = invalid
    if type(raiz) = "roAssociativeArray" then info = raiz.user_info
    if type(info) <> "roAssociativeArray" or Cadena(info.auth) <> "1" then return falloDeCuenta("Usuario o contraseña incorrectos")
    estado = Cadena(info.status)
    if LCase(estado) = "expired" then return falloDeCuenta("Tu cuenta está vencida")
    if estado <> "" and LCase(estado) <> "active" then return falloDeCuenta("Tu cuenta está suspendida")
    vence = "Sin vencimiento"
    exp = Numero(info.exp_date)
    if exp > 0 then vence = FechaDe(Int(exp))
    formatos = info.allowed_output_formats
    if type(formatos) = "roArray" and formatos.Count() > 0
        m.m3u8 = false
        m.ts = false
        for each f in formatos
            if LCase(Cadena(f)) = "m3u8" then m.m3u8 = true
            if LCase(Cadena(f)) = "ts" then m.ts = true
        end for
        if not m.m3u8 and not m.ts then m.m3u8 = true
    end if
    return { estado: estado, vence: vence, conexiones: Cadena(info.active_cons) + " de " + Cadena(info.max_connections), m3u8: m.m3u8 }
end function

function categorias(tipo as string) as object
    clave = "cat/" + tipo
    if m.cache[clave] = invalid
        salida = []
        for each c in pedirLista(urlApi("get_" + tipo + "_categories"))
            if type(c) = "roAssociativeArray"
                nombre = Cadena(c.category_name)
                ' adulto: va en la sección Adultos (protegida con PIN) y no en las demás.
                salida.Push({ id: Cadena(c.category_id), nombre: nombre, tipo: tipo, adulto: m.adultos.IsMatch(nombre) })
            end if
        end for
        if m.fallo <> "" then return salida
        m.cache[clave] = salida
    end if
    return m.cache[clave]
end function

function listaDeCategorias(tipos as object, adultos as boolean) as object
    salida = []
    for each tipo in tipos
        for each c in categorias(tipo)
            if c.adulto = adultos then salida.Push({ id: c.id, nombre: c.nombre, tipo: c.tipo })
        end for
    end for
    return salida
end function

' Canales, películas o series de una categoría ("" = todos). Como Android, la categoría se le pide
' al servidor (&category_id=): el XUI sabe en qué categorías está cada cosa (puede estar en varias y
' category_id solo trae la primera). Se guardan mientras dure la sesión.
function elementos(tipo as string, categoria = "" as string) as object
    clave = "el/" + tipo + "/" + categoria
    if m.cache[clave] <> invalid then return m.cache[clave]
    deAdultos = {}
    for each c in categorias(tipo)
        if c.adulto then deAdultos[c.id] = true
    end for
    esSerie = tipo = "series"
    extra = ""
    if categoria <> "" then extra = "&category_id=" + esc(categoria)
    if esSerie
        datos = pedirLista(urlApi("get_series", extra))
    else
        datos = pedirLista(urlApi("get_" + tipo + "_streams", extra))
    end if
    if m.fallo <> "" then return []
    salida = []
    for each o in datos
        if type(o) = "roAssociativeArray"
            if esSerie
                id = Cadena(o.series_id)
                icono = Cadena(o.cover)
                agregado = Numero(o.last_modified)
            else
                id = Cadena(o.stream_id)
                icono = Cadena(o.stream_icon)
                agregado = Numero(o.added)
            end if
            if id <> ""
                nota = Numero(o.rating_5based)
                if nota <= 0 then nota = Numero(o.rating) / 2
                if nota < 0 then nota = 0
                cat = Cadena(o.category_id)
                cats = [cat]
                if type(o.category_ids) = "roArray"
                    for each x in o.category_ids
                        cats.Push(Cadena(x))
                    end for
                end if
                salida.Push({
                    tipo: tipo, id: id, nombre: Cadena(o.name), icono: icono, ext: Cadena(o.container_extension),
                    agregado: agregado, nota: nota, cat: cat, cats: cats,
                    ' Lo marca el servidor (is_adult) o pertenece a una categoría de adultos.
                    adulto: Cadena(o.is_adult) = "1" or deAdultos[cat] = true or deAdultos[categoria] = true
                })
            end if
        end if
    end for
    m.cache[clave] = salida
    return salida
end function

function filtrar(tipo as string, categoria as string, adultos as boolean) as object
    salida = []
    for each e in elementos(tipo, categoria)
        if e.adulto = adultos then salida.Push(e)
    end for
    ' Por si el servidor no filtra por categoría: buscarla en la lista completa.
    if salida.Count() = 0 and categoria <> "" and m.fallo = ""
        for each e in elementos(tipo)
            if e.adulto = adultos and Posicion(e.cats, categoria) >= 0 then salida.Push(e)
        end for
    end if
    return salida
end function

' ---------- Nodos para las cuadrículas ----------
' id = «tipo:número» (live, vod, series, episode). url y streamFormat ya listos para el Video.
' ShortDescriptionLine2 = "fav" pinta la estrella de favorito.
function urlDeVideo(e as object) as string
    quien = "/" + esc(m.usuario) + "/" + esc(m.clave) + "/" + e.id
    if e.tipo = "live"
        if m.m3u8 then return m.base + "/live" + quien + ".m3u8"
        return m.base + "/live" + quien + ".ts"
    end if
    ext = e.ext
    if ext = "" then ext = "mp4"
    if e.tipo = "episode" then return m.base + "/series" + quien + "." + ext
    return m.base + "/movie" + quien + "." + ext
end function

function formatoDe(e as object) as string
    if e.tipo = "live"
        if m.m3u8 then return "hls"
        return "ts"
    end if
    ext = LCase(e.ext)
    if ext = "mkv" then return "mkv"
    if ext = "m3u8" then return "hls"
    if ext = "ts" then return "ts"
    return "mp4"
end function

function nodoDeElemento(padre as object, e as object) as object
    c = padre.createChild("ContentNode")
    c.id = e.tipo + ":" + e.id
    c.title = e.nombre
    c.HDPosterUrl = e.icono
    c.FHDPosterUrl = e.icono
    if e.tipo <> "series"
        c.url = urlDeVideo(e)
        c.streamFormat = formatoDe(e)
        c.live = e.tipo = "live"
    end if
    if m.favoritos[c.id] = true then c.ShortDescriptionLine2 = "fav"
    if e.aspecto <> invalid and e.aspecto > 0 then c.addFields({ aspecto: e.aspecto })
    return c
end function

function nodoDe(lista as object) as object
    raiz = CreateObject("roSGNode", "ContentNode")
    for each e in lista
        nodoDeElemento(raiz, e)
    end for
    return raiz
end function

' Inicio: «Estrenos destacados» (agregadas más recientemente) y «Tendencias» (mejor calificadas).
function inicio() as object
    raiz = CreateObject("roSGNode", "ContentNode")
    pelis = filtrar("vod", "", false)
    if m.fallo <> "" then return raiz
    recientes = []
    recientes.Append(pelis)
    recientes.SortBy("agregado", "r")
    mejores = []
    mejores.Append(pelis)
    mejores.SortBy("nota", "r")
    filas = [["Estrenos destacados", recientes], ["Tendencias", mejores]]
    for each f in filas
        fila = raiz.createChild("ContentNode")
        fila.title = f[0]
        for i = 0 to f[1].Count() - 1
            if i >= 20 then exit for
            nodoDeElemento(fila, f[1][i])
        end for
    end for
    return raiz
end function

function favoritos(ids as dynamic) as object
    raiz = CreateObject("roSGNode", "ContentNode")
    if type(ids) <> "roArray" or ids.Count() = 0 then return raiz
    buscados = {}
    for each id in ids
        buscados[id] = true
    end for
    for each tipo in ["live", "vod", "series"]
        for each e in elementos(tipo)
            if not e.adulto and buscados[e.tipo + ":" + e.id] = true then nodoDeElemento(raiz, e)
        end for
    end for
    return raiz
end function

function buscar(texto as string) as object
    raiz = CreateObject("roSGNode", "ContentNode")
    buscado = Plano(texto)
    if buscado = "" then return raiz
    total = 0
    for each tipo in ["live", "vod", "series"]
        for each e in elementos(tipo)
            if not e.adulto and Instr(1, Plano(e.nombre), buscado) > 0
                nodoDeElemento(raiz, e)
                total = total + 1
                if total >= 300 then return raiz
            end if
        end for
    end for
    return raiz
end function

' Episodios de una serie: un nodo por temporada (ordenadas por número) con sus episodios.
function serie(id as string, r as object) as object
    raiz = CreateObject("roSGNode", "ContentNode")
    datos = pedir(urlApi("get_series_info", "&series_id=" + esc(id)))
    if type(datos) <> "roAssociativeArray" then return raiz
    info = datos.info
    r.datos = { titulo: "", sinopsis: "", portada: "" }
    if type(info) = "roAssociativeArray"
        r.datos = { titulo: Cadena(info.name), sinopsis: Cadena(info.plot), portada: Cadena(info.cover) }
    end if
    porTemporada = datos.episodes
    temporadas = []
    if type(porTemporada) = "roArray"
        for i = 0 to porTemporada.Count() - 1
            temporadas.Push({ nombre: (i + 1).ToStr(), orden: i + 1, lista: porTemporada[i] })
        end for
    else if type(porTemporada) = "roAssociativeArray"
        for each t in porTemporada
            orden = Val(t)
            if orden = 0 and t <> "0" then orden = 99999
            temporadas.Push({ nombre: t, orden: orden, lista: porTemporada[t] })
        end for
    end if
    temporadas.SortBy("orden")
    for each t in temporadas
        if type(t.lista) = "roArray"
            nodo = CreateObject("roSGNode", "ContentNode")
            nodo.title = "Temporada " + t.nombre
            for each o in t.lista
                if type(o) = "roAssociativeArray" and Cadena(o.id) <> ""
                    titulo = Cadena(o.title)
                    if titulo = "" then titulo = "Episodio " + Cadena(o.episode_num)
                    icono = ""
                    if type(o.info) = "roAssociativeArray" then icono = Cadena(o.info.movie_image)
                    aspecto = 0
                    if type(o.info) = "roAssociativeArray" then aspecto = aspectoDe(o.info.video)
                    nodoDeElemento(nodo, { tipo: "episode", id: Cadena(o.id), nombre: titulo, icono: icono, ext: Cadena(o.container_extension), aspecto: aspecto })
                end if
            end for
            if nodo.getChildCount() > 0 then raiz.appendChild(nodo)
        end if
    end for
    return raiz
end function

' Programa actual y siguientes de un canal; lista vacía si no tiene guía.
function guia(id as string) as object
    salida = []
    datos = pedir(urlApi("get_short_epg", "&stream_id=" + esc(id) + "&limit=3"))
    m.fallo = ""
    if type(datos) <> "roAssociativeArray" or type(datos.epg_listings) <> "roArray" then return salida
    for each p in datos.epg_listings
        if type(p) = "roAssociativeArray"
            titulo = decodificar(Cadena(p.title))
            desde = Int(Numero(p.start_timestamp))
            hasta = Int(Numero(p.stop_timestamp))
            linea = titulo
            if desde > 0 and hasta > 0 then linea = HoraDe(desde) + " – " + HoraDe(hasta) + "   " + titulo
            salida.Push(linea)
        end if
    end for
    return salida
end function

' Los títulos de la guía llegan en base64 (UTF-8).
function decodificar(base64 as string) as string
    bytes = CreateObject("roByteArray")
    bytes.FromBase64String(base64)
    if bytes.Count() = 0 then return base64
    return bytes.ToAsciiString().Trim()
end function

' ---------- Proporción real del video (para el formato Automático) ----------
' El XUI guarda lo que midió ffprobe de cada película y episodio (info.video). Roku solo dice el tamaño
' codificado, que en video de TV (720x480, 720x576…) no es la proporción en pantalla.
function aspectoDePelicula(id as string) as float
    datos = pedir(urlApi("get_vod_info", "&vod_id=" + esc(id)), 15000)
    if type(datos) <> "roAssociativeArray" or type(datos.info) <> "roAssociativeArray" then return 0
    return aspectoDe(datos.info.video)
end function

function aspectoDe(v as dynamic) as float
    if type(v) <> "roAssociativeArray" then return 0
    a = razon(Cadena(v.display_aspect_ratio))
    if a > 0.5 and a < 4 then return a
    ancho = Numero(v.width)
    alto = Numero(v.height)
    if ancho <= 0 or alto <= 0 then return 0
    s = razon(Cadena(v.sample_aspect_ratio))
    if s > 0 then return ancho * s / alto
    return 0
end function

' "16:9" → 1.777…; 0 si no es una razón válida.
function razon(t as string) as float
    partes = t.Split(":")
    if partes.Count() <> 2 then return 0
    n = Val(partes[0])
    d = Val(partes[1])
    if n <= 0 or d <= 0 then return 0
    return n / d
end function

' Enlace directo (búsqueda de Roku o roInput). Los ids son los del XUI de la cuenta conectada: un mismo id
' puede ser otro contenido en otro servidor, por eso siempre se buscan en el catálogo de esta cuenta (que
' ya trae solo lo que su paquete permite) y nunca se arma una URL a ciegas. Adultos no se abre así.
'   live, vod, series → id del canal, película o serie
'   episode           → «SERIE_EPISODIO» (id de la serie y del episodio, p. ej. 5001_50011)
function enlace(tipo as string, id as string, r as object) as object
    raiz = CreateObject("roSGNode", "ContentNode")
    r.datos = { indice: 0 }
    if tipo = "episode"
        partes = id.Split("_")
        if partes.Count() <> 2 or partes[0] = "" or partes[1] = ""
            m.fallo = "El enlace del episodio no es válido."
            return raiz
        end if
        if not existe("series", partes[0])
            if m.fallo = "" then m.fallo = "Ese contenido no está disponible en tu cuenta."
            return raiz
        end if
        temporadas = serie(partes[0], {})
        for t = 0 to temporadas.getChildCount() - 1
            lista = temporadas.getChild(t)
            for i = 0 to lista.getChildCount() - 1
                if lista.getChild(i).id = "episode:" + partes[1]
                    r.datos = { indice: i }
                    return lista
                end if
            end for
        end for
        if m.fallo = "" then m.fallo = "Ese episodio no está disponible en tu cuenta."
        return raiz
    end if
    if tipo <> "live" and tipo <> "vod" and tipo <> "series"
        m.fallo = "Ese tipo de enlace no está disponible."
        return raiz
    end if
    for each e in filtrar(tipo, "", false)
        if e.id = id
            nodoDeElemento(raiz, e)
            return raiz
        end if
    end for
    if m.fallo = "" then m.fallo = "Ese contenido no está disponible en tu cuenta."
    return raiz
end function

function existe(tipo as string, id as string) as boolean
    for each e in filtrar(tipo, "", false)
        if e.id = id then return true
    end for
    return false
end function
