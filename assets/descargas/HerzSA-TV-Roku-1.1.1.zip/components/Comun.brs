' Funciones que usan varias pantallas y la tarea de red.

' Cualquier valor del JSON del XUI como texto (llegan números o cadenas según el panel).
function Cadena(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v.Trim()
    if t = "roInt" or t = "roInteger" or t = "Integer" or t = "LongInteger" or t = "roLongInteger" then return v.ToStr()
    if t = "roFloat" or t = "Float" or t = "Double" or t = "roDouble"
        if v = Int(v) then return Int(v).ToStr()
        return Str(v).Trim()
    end if
    if t = "roBoolean" or t = "Boolean"
        if v then return "1"
        return "0"
    end if
    return ""
end function

function Numero(v as dynamic) as float
    s = Cadena(v)
    if s = "" then return 0
    return Val(s)
end function

' Minúsculas y sin acentos, para comparar y buscar («accion» encuentra «Acción»).
function Plano(s as string) as string
    s = LCase(s)
    pares = [["á", "a"], ["à", "a"], ["ä", "a"], ["â", "a"], ["Á", "a"], ["À", "a"], ["é", "e"], ["è", "e"], ["ë", "e"], ["ê", "e"], ["É", "e"], ["í", "i"], ["ì", "i"], ["ï", "i"], ["Í", "i"], ["ó", "o"], ["ò", "o"], ["ö", "o"], ["ô", "o"], ["Ó", "o"], ["ú", "u"], ["ù", "u"], ["ü", "u"], ["Ú", "u"], ["Ü", "u"], ["ñ", "n"], ["Ñ", "n"], ["ç", "c"]]
    for each p in pares
        s = s.Replace(p[0], p[1])
    end for
    return s.Trim()
end function

function DosCifras(n as integer) as string
    if n < 10 then return "0" + n.ToStr()
    return n.ToStr()
end function

' Hora local «hh:mm» de una marca de tiempo Unix.
function HoraDe(segundos as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(segundos)
    d.ToLocalTime()
    return DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
end function

' Fecha local «dd/mm/aaaa hh:mm».
function FechaDe(segundos as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(segundos)
    d.ToLocalTime()
    return DosCifras(d.GetDayOfMonth()) + "/" + DosCifras(d.GetMonth()) + "/" + d.GetYear().ToStr() + " " + DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
end function

' ---------- Datos guardados en el equipo (registro de Roku) ----------
' Se guardan envueltos en {"v": …} porque ParseJson solo acepta objetos o listas.
function LeerDato(clave as string, defecto as dynamic) as dynamic
    r = CreateObject("roRegistrySection", "herzsa")
    if not r.Exists(clave) then return defecto
    datos = ParseJson(r.Read(clave))
    if datos = invalid or datos.v = invalid then return defecto
    return datos.v
end function

sub GuardarDato(clave as string, valor as dynamic)
    r = CreateObject("roRegistrySection", "herzsa")
    r.Write(clave, FormatJson({ v: valor }))
    r.Flush()
end sub

sub BorrarDato(clave as string)
    r = CreateObject("roRegistrySection", "herzsa")
    r.Delete(clave)
    r.Flush()
end sub

' Sesión guardada: la contraseña va cifrada (AES-256-CBC) con una clave derivada del id que Roku da a esta
' app en este equipo (GetChannelClientId), con un IV nuevo cada vez. No es una caja fuerte (la clave sale del
' propio equipo), pero la contraseña ya no queda en texto plano en el registro.
function LeerSesion() as dynamic
    s = LeerDato("sesion", invalid)
    if type(s) <> "roAssociativeArray" then return invalid
    if s.cifrada <> invalid
        clave = cifrado(false, s.cifrada, Cadena(s.iv))
        if clave = invalid then return invalid
        return { servidor: Cadena(s.servidor), usuario: Cadena(s.usuario), clave: clave }
    end if
    ' Formato de la 1.0.10 y anteriores (texto plano): se vuelve a guardar cifrado.
    if s.clave = invalid then return invalid
    sesion = { servidor: Cadena(s.servidor), usuario: Cadena(s.usuario), clave: Cadena(s.clave) }
    GuardarSesion(sesion)
    return sesion
end function

sub GuardarSesion(sesion as object)
    iv = CreateObject("roByteArray")
    uuid = CreateObject("roDeviceInfo").GetRandomUUID().Replace("-", "")
    iv.FromHexString(Left(uuid, 32))
    cifrada = cifrado(true, sesion.clave, iv.ToHexString())
    if cifrada = invalid then return
    GuardarDato("sesion", { servidor: sesion.servidor, usuario: sesion.usuario, cifrada: cifrada, iv: iv.ToHexString() })
end sub

' Cifra (texto → base64) o descifra (base64 → texto); invalid si falla.
function cifrado(cifrar as boolean, texto as string, iv as string) as dynamic
    semilla = CreateObject("roByteArray")
    semilla.FromAsciiString("herzsa-tv-sesion:" + CreateObject("roDeviceInfo").GetChannelClientId())
    digest = CreateObject("roEVPDigest")
    digest.Setup("sha256")
    clave = digest.Process(semilla)
    c = CreateObject("roEVPCipher")
    if c.Setup(cifrar, "aes-256-cbc", clave, iv, 1) <> 0 then return invalid
    entrada = CreateObject("roByteArray")
    if cifrar then entrada.FromAsciiString(texto) else entrada.FromBase64String(texto)
    salida = c.Process(entrada)
    if salida = invalid then return invalid
    if cifrar then return salida.ToBase64String()
    return salida.ToAsciiString()
end function

' Huella del PIN de Adultos (igual que en Android y Windows: SHA-256 de «herzsa-tv:PIN»).
function Huella(pin as string) as string
    bytes = CreateObject("roByteArray")
    bytes.FromAsciiString("herzsa-tv:" + pin)
    digest = CreateObject("roEVPDigest")
    digest.Setup("sha256")
    return digest.Process(bytes)
end function

function Posicion(lista as object, valor as dynamic) as integer
    for i = 0 to lista.Count() - 1
        if lista[i] = valor then return i
    end for
    return -1
end function

' «sábado 21 de noviembre de 2026» con la hora local.
function FechaCompleta(d as object) as string
    dias = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"]
    meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    return dias[d.GetDayOfWeek()] + " " + d.GetDayOfMonth().ToStr() + " de " + meses[d.GetMonth() - 1] + " de " + d.GetYear().ToStr()
end function

' Fecha completa y hora: «sábado 21 de noviembre de 2026   01:30».
function FechaYHora() as string
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    return FechaCompleta(d) + "   " + DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
end function

' Red a la que está conectado el Roku: «Wi-Fi: MiCasa», «Red por cable» o «Sin conexión».
function NombreRed() as string
    di = CreateObject("roDeviceInfo")
    if not di.GetLinkStatus() then return "Sin conexión a la red"
    info = di.GetConnectionInfo()
    if type(info) <> "roAssociativeArray" then return ""
    tipo = Cadena(info.type)
    if tipo = "WiFiConnection"
        ssid = Cadena(info.ssid)
        if ssid <> "" then return "Wi-Fi: " + ssid
        return "Wi-Fi"
    else if tipo = "WiredConnection"
        return "Red por cable (Ethernet)"
    end if
    return ""
end function
