' Lógica común de Cartel, Canal, Chip y Seccion (elementos de las cuadrículas, de la barra de
' categorías y del panel de secciones). El nodo de contenido trae en ShortDescriptionLine2 "fav"
' (favorito, estrella) o "activa" (categoría o sección elegida); la pantalla lo cambia y la tarjeta
' se vuelve a pintar sola. Diseño: ../capturas/inc.png (verde la elegida, marco blanco o verde).

sub init()
    m.marco = m.top.findNode("marco")
    m.fondo = m.top.findNode("fondo")
    m.titulo = m.top.findNode("titulo")
    m.imagen = m.top.findNode("imagen")
    m.icono = m.top.findNode("icono")
    m.estrella = m.top.findNode("estrella")
    m.sinImagen = m.top.findNode("sinImagen")
    m.tipo = m.top.subtype()
    m.contenido = invalid
    if m.imagen <> invalid then m.imagen.observeField("loadStatus", "alCargarImagen")
end sub

sub mostrar()
    if m.contenido <> invalid then m.contenido.unobserveField("ShortDescriptionLine2")
    m.contenido = m.top.itemContent
    if m.contenido = invalid then return
    m.contenido.observeField("ShortDescriptionLine2", "pintar")
    m.titulo.text = m.contenido.title
    if m.sinImagen <> invalid
        m.sinImagen.text = m.contenido.title
        m.sinImagen.visible = true
    end if
    if m.imagen <> invalid
        ' Los logos de canal (en búsqueda y favoritos) se ven completos; las carátulas llenan el marco.
        if Left(m.contenido.id, 5) = "live:" and m.tipo = "Cartel"
            m.imagen.loadDisplayMode = "scaleToFit"
        else if m.tipo = "Cartel"
            m.imagen.loadDisplayMode = "scaleToZoom"
        end if
        m.imagen.uri = m.contenido.HDPosterUrl
    end if
    if m.tipo = "Seccion"
        m.icono.uri = m.contenido.HDPosterUrl
    else if m.tipo = "Chip"
        ' Icono según el nombre de la categoría; sin icono el nombre va centrado.
        icono = IconoDeCategoria(m.contenido.title)
        m.icono.visible = icono <> ""
        m.icono.uri = icono
        if icono <> ""
            m.titulo.translation = [62, 0]
            m.titulo.width = 138
            m.titulo.horizAlign = "left"
        else
            m.titulo.translation = [12, 0]
            m.titulo.width = 186
            m.titulo.horizAlign = "center"
        end if
    end if
    pintar()
end sub

function IconoDeCategoria(nombre as string) as string
    n = Plano(nombre)
    for each par in [["estreno", "c_estrenos"], ["nuev", "c_estrenos"], ["2026", "c_estrenos"], ["kid", "c_kids"], ["infan", "c_kids"], ["nino", "c_kids"], ["anima", "c_kids"], ["famil", "c_kids"], ["marvel", "c_marvel"], ["heroe", "c_marvel"], ["pelicul", "c_peliculas"], ["cine", "c_peliculas"]]
        if Instr(1, n, par[0]) > 0 then return "pkg:/images/d/" + par[1] + ".png"
    end for
    return ""
end function

sub alCargarImagen()
    if m.sinImagen <> invalid then m.sinImagen.visible = m.imagen.loadStatus <> "ready"
end sub

function listaEnfocada() as boolean
    if m.tipo = "Seccion" then return m.top.listHasFocus
    return m.top.gridHasFocus or m.top.rowListHasFocus
end function

sub enfocar()
    pintar()
end sub

sub pintar()
    marca = ""
    if m.contenido <> invalid then marca = m.contenido.ShortDescriptionLine2
    conFoco = listaEnfocada()
    foco = m.top.focusPercent > 0.5 and conFoco
    if m.estrella <> invalid then m.estrella.visible = marca = "fav"
    if m.tipo = "Chip" or m.tipo = "Seccion"
        ' Verde: la que tiene el foco, o la elegida cuando el foco está en otra parte. Si el foco
        ' recorre la lista, la elegida queda con el nombre en verde.
        verde = foco or (marca = "activa" and not conFoco)
        if m.tipo = "Chip"
            if verde then m.fondo.uri = "pkg:/images/d/chip_sel.png" else m.fondo.uri = "pkg:/images/d/chip.png"
        else
            m.fondo.visible = verde
        end if
        if not verde and marca = "activa" then m.titulo.color = "0x7EE05AFF" else m.titulo.color = "0xFFFFFFFF"
        return
    end if
    if m.tipo = "Cartel"
        if foco then m.marco.uri = "pkg:/images/d/tarjeta_foco.png" else m.marco.uri = "pkg:/images/d/tarjeta.png"
    else if m.tipo = "Canal"
        if foco then m.fondo.uri = "pkg:/images/d/canal_foco.png" else m.fondo.uri = "pkg:/images/d/canal.png"
    end if
end sub
