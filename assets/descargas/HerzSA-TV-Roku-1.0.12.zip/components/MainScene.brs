' HerzSA TV para Roku: inicio de sesión, secciones, categorías, Mi cuenta y Adultos con PIN.
' Equivale a MainActivity (Android) y app.js (Windows); ver README.md.

sub init()
    m.top.backgroundColor = "0x061230FF"
    m.top.backgroundUri = ""
    for each id in ["fondo", "velo", "login", "botonesLogin", "errorLogin", "versionLogin", "principal", "reloj", "red", "iconoRed", "linea", "secciones", "categorias", "canales", "carteles", "filas", "cuenta", "datosCuenta", "botonesCuenta", "estado", "ayuda", "aviso", "avisoTexto", "relojAviso", "relojHora", "esperaCategoria"]
        m[id] = m.top.findNode(id)
    end for

    m.appInfo = CreateObject("roAppInfo")
    m.version = m.appInfo.GetVersion()
    m.servidorFijo = m.appInfo.GetValue("servidor")
    m.versionLogin.text = "Versión " + m.version

    ' Red: una sola tarea atiende las solicitudes en orden.
    m.api = CreateObject("roSGNode", "ApiTask")
    m.api.observeField("respuesta", "alResponder")
    m.api.control = "RUN"
    m.n = 0
    m.pendientes = {}
    m.carga = -1

    ' Ajustes de pantalla que se cambian desde el panel sin actualizar la app (ver README).
    urlAjustes = m.appInfo.GetValue("ajustes")
    if urlAjustes <> "" then pedirApi("ajustes", { url: urlAjustes }, alAjustes)

    ' Sin Buscar ni Adultos desde 1.0.8 (versión para la tienda de Roku). El código de esas secciones sigue
    ' abajo: para volver a mostrarlas basta con agregarlas aquí (y el botón del PIN en Mi cuenta).
    m.NOMBRES = ["Inicio", "TV en vivo", "Películas", "Series", "Favoritos", "Mi cuenta"]
    iconos = ["i_inicio", "i_vivo", "i_peliculas", "i_capas", "i_favoritos", "i_cuenta"]
    raiz = CreateObject("roSGNode", "ContentNode")
    for i = 0 to m.NOMBRES.Count() - 1
        c = raiz.createChild("ContentNode")
        c.title = m.NOMBRES[i]
        c.HDPosterUrl = "pkg:/images/d/" + iconos[i] + ".png"
    end for
    m.secciones.content = raiz
    ' La línea que brilla bajo la barra de arriba va fuera de la zona segura (de borde a borde).
    m.principal.observeField("visible", "alVerPrincipal")

    m.botonesLogin.observeField("buttonSelected", "alBotonLogin")
    m.secciones.observeField("itemSelected", "alElegirSeccion")
    m.categorias.observeField("rowItemFocused", "alEnfocarCategoria")
    m.categorias.observeField("rowItemSelected", "alElegirCategoria")
    m.esperaCategoria.observeField("fire", "alEsperarCategoria")
    m.canales.observeField("itemSelected", "alElegirCanal")
    m.carteles.observeField("itemSelected", "alElegirCartel")
    m.filas.observeField("rowItemSelected", "alElegirEnFila")
    m.botonesCuenta.observeField("buttonSelected", "alBotonCuenta")
    m.relojAviso.observeField("fire", "alTerminarAviso")
    m.relojHora.observeField("fire", "ponerHora")
    m.relojHora.control = "start"
    ponerHora()

    m.vista = "login"
    m.zona = "secciones"
    m.seccion = -1
    m.tipo = "vod"
    m.adultos = false
    m.cats = []
    m.catElegida = -1
    m.cuentaInfo = {}
    m.dialogo = invalid
    ' Desde 1.0.12 el inicio de sesión es solo con la cuenta Xtream Codes (usuario, contraseña y servidor);
    ' se quitó la petición del correo de la cuenta Roku.
    m.reproductor = invalid
    m.serie = invalid

    ' Balizas de certificación de Roku: AppLaunchComplete cuando se ve la pantalla principal; si antes
    ' aparece el inicio de sesión, va entre AppDialogInitiate y AppDialogComplete.
    m.lanzada = false
    m.dialogoInicial = false
    m.enlacePendiente = invalid
    m.nEnlace = -1
    m.ultimoEnlace = ""
    m.relojEnlace = CreateObject("roTimespan")

    m.sesion = LeerSesion()
    if m.sesion <> invalid
        m.usuarioTexto = m.sesion.usuario
        m.claveTexto = m.sesion.clave
        m.servidorTexto = m.sesion.servidor
        mostrarLogin("")
        m.errorLogin.text = "Conectando…"
        entrar()
    else
        m.usuarioTexto = ""
        m.claveTexto = ""
        m.servidorTexto = m.servidorFijo
        mostrarLogin("")
    end if
end sub

' ---------- Red ----------
function pedirApi(accion as string, params as object, alListo as dynamic) as integer
    m.n = m.n + 1
    params.n = m.n
    params.accion = accion
    params.favoritos = LeerDato("favoritos", [])
    if params.servidor = invalid and m.sesion <> invalid
        params.servidor = m.sesion.servidor
        params.usuario = m.sesion.usuario
        params.clave = m.sesion.clave
    end if
    m.pendientes[m.n.ToStr()] = alListo
    m.api.solicitud = params
    return m.n
end function

sub alResponder(ev as object)
    r = ev.getData()
    if r = invalid or r.n = invalid then return
    k = r.n.ToStr()
    f = m.pendientes[k]
    if f = invalid then return
    m.pendientes.Delete(k)
    f(r)
end sub

sub alAjustes(r as object)
    if r.ok and type(r.datos) = "roAssociativeArray" then GuardarDato("ajustes", r.datos)
end sub

' ---------- Utilidades ----------
sub aviso(mensaje as string)
    m.avisoTexto.text = mensaje
    m.aviso.visible = true
    m.relojAviso.control = "stop"
    m.relojAviso.control = "start"
end sub

sub alTerminarAviso()
    m.aviso.visible = false
end sub

sub alVerPrincipal()
    m.linea.visible = m.principal.visible
end sub

' Arriba a la derecha: «Vie 20 Nov   19:24» y la red (icono de Wi-Fi y su nombre).
sub ponerHora()
    dias = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]
    meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    m.reloj.text = dias[d.GetDayOfWeek()] + " " + d.GetDayOfMonth().ToStr() + " " + meses[d.GetMonth() - 1] + "  " + DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
    red = NombreRed()
    wifi = Left(red, 7) = "Wi-Fi: "
    if wifi then red = Mid(red, 8)
    if Left(red, 13) = "Red por cable" then red = "Red por cable"
    m.iconoRed.visible = wifi
    if wifi
        m.red.translation = [66, 0]
        m.red.width = 262
    else
        m.red.translation = [20, 0]
        m.red.width = 308
    end if
    m.red.text = red
end sub

' Pinta de verde la sección elegida en el panel (Tarjeta.brs, marca "activa").
sub marcarSeccion()
    raiz = m.secciones.content
    for i = 0 to raiz.getChildCount() - 1
        if i = m.seccion then raiz.getChild(i).ShortDescriptionLine2 = "activa" else raiz.getChild(i).ShortDescriptionLine2 = ""
    end for
end sub

' Diálogos estándar de Roku. alElegir(boton, texto) recibe el número de botón y lo escrito
' (texto del teclado o PIN). Atrás en el diálogo lo cierra sin llamar a alElegir.
sub abrirDialogo(d as object, alElegir as dynamic)
    m.alDialogo = alElegir
    m.dialogo = d
    d.observeField("buttonSelected", "alBotonDialogo")
    d.observeField("wasClosed", "alCerrarDialogo")
    m.top.dialog = d
end sub

sub alBotonDialogo()
    d = m.dialogo
    if d = invalid then return
    boton = d.buttonSelected
    texto = ""
    if d.hasField("pin")
        texto = d.pin
    else if d.hasField("text")
        texto = d.text
    end if
    f = m.alDialogo
    m.alDialogo = invalid
    m.dialogo = invalid
    d.close = true
    if f <> invalid then f(boton, texto)
    ' Si la respuesta abrió otro diálogo, el foco queda en él.
    if m.dialogo = invalid then restaurarFoco()
end sub

sub alCerrarDialogo()
    ' Solo cuenta si se cerró el diálogo vigente (con Atrás); al elegir un botón m.dialogo ya es otro o invalid.
    if m.dialogo <> invalid and m.dialogo.wasClosed
        m.dialogo = invalid
        m.alDialogo = invalid
        restaurarFoco()
    end if
end sub

sub preguntar(titulo as string, texto as string, botones as object, alElegir as dynamic)
    d = CreateObject("roSGNode", "StandardMessageDialog")
    d.title = titulo
    d.message = [texto]
    d.buttons = botones
    abrirDialogo(d, alElegir)
end sub

sub pedirTexto(titulo as string, texto as string, inicial as string, secreto as boolean, alElegir as dynamic)
    d = CreateObject("roSGNode", "StandardKeyboardDialog")
    d.title = titulo
    if texto <> "" then d.message = [texto]
    d.text = inicial
    d.buttons = ["Aceptar", "Cancelar"]
    if secreto
        d.keyboardDomain = "password"
        if d.textEditBox <> invalid then d.textEditBox.secureMode = true
    end if
    abrirDialogo(d, alElegir)
end sub

sub pedirPin(titulo as string, texto as string, alElegir as dynamic)
    d = CreateObject("roSGNode", "StandardPinPadDialog")
    d.title = titulo
    d.message = [texto]
    d.buttons = ["Aceptar", "Cancelar"]
    if d.textEditBox <> invalid then d.textEditBox.maxTextLength = 8
    abrirDialogo(d, alElegir)
end sub

sub restaurarFoco()
    if m.dialogo <> invalid then return
    if m.vista = "login"
        m.botonesLogin.setFocus(true)
    else if m.vista = "serie" and m.serie <> invalid
        m.serie.foco = true
    else if m.vista = "reproductor" and m.reproductor <> invalid
        m.reproductor.foco = true
    else if m.vista = "principal"
        enfocar(m.zona)
    end if
end sub

' ---------- Inicio de sesión ----------
sub mostrarLogin(error as string)
    if not m.lanzada and not m.dialogoInicial and m.sesion = invalid
        m.dialogoInicial = true
        m.top.signalBeacon("AppDialogInitiate")
    end if
    m.vista = "login"
    m.principal.visible = false
    m.login.visible = true
    m.errorLogin.text = error
    pintarBotonesLogin()
    m.botonesLogin.setFocus(true)
end sub

sub pintarBotonesLogin()
    usuario = m.usuarioTexto
    if usuario = "" then usuario = "(escribe tu usuario)"
    clave = "(escribe tu contraseña)"
    if m.claveTexto <> "" then clave = String(Len(m.claveTexto), "•")
    botones = ["Usuario:  " + usuario, "Contraseña:  " + clave, "Entrar"]
    ' Servidor siempre a la vista: cada cliente puede conectar su propio XUI (viene el del manifest).
    botones.Push("Servidor:  " + m.servidorTexto)
    m.botonesLogin.buttons = botones
end sub

sub alBotonLogin()
    b = m.botonesLogin.buttonSelected
    if b = 0
        pedirTexto("Usuario", "El usuario de tu cuenta de televisión.", m.usuarioTexto, false, alEscribirUsuario)
    else if b = 1
        pedirTexto("Contraseña", "La contraseña de tu cuenta de televisión.", m.claveTexto, true, alEscribirClave)
    else if b = 2
        if m.usuarioTexto = "" or m.claveTexto = ""
            m.errorLogin.text = "Escribe tu usuario y tu contraseña"
            return
        end if
        m.errorLogin.text = "Entrando…"
        entrar()
    else if b = 3
        pedirServidor()
    end if
end sub

sub alEscribirUsuario(boton as integer, texto as string)
    if boton <> 0 then return
    m.usuarioTexto = texto.Trim()
    pintarBotonesLogin()
    m.botonesLogin.focusButton = 1
end sub

sub alEscribirClave(boton as integer, texto as string)
    if boton <> 0 then return
    m.claveTexto = texto.Trim()
    pintarBotonesLogin()
    m.botonesLogin.focusButton = 2
end sub

' Campo oculto (botón * en el inicio de sesión), como mantener pulsado el título en Android.
sub pedirServidor()
    pedirTexto("Servidor", "Dirección del panel. Déjalo vacío para usar el de HerzSA.", m.servidorTexto, false, alEscribirServidor)
end sub

sub alEscribirServidor(boton as integer, texto as string)
    if boton <> 0 then return
    m.servidorTexto = texto.Trim()
    if m.servidorTexto = "" then m.servidorTexto = m.servidorFijo
    pintarBotonesLogin()
end sub

sub entrar()
    pedirApi("entrar", { servidor: m.servidorTexto, usuario: m.usuarioTexto, clave: m.claveTexto }, alEntrar)
end sub

sub alEntrar(r as object)
    if not r.ok
        if not m.lanzada and not m.dialogoInicial
            m.dialogoInicial = true
            m.top.signalBeacon("AppDialogInitiate")
        end if
        if not r.cuenta and m.sesion <> invalid and m.vista = "login"
            m.errorLogin.text = r.error + " Elige «Entrar» para intentar otra vez."
        else
            m.errorLogin.text = r.error
        end if
        if m.vista <> "login" then cerrarSesion(r.error)
        return
    end if
    m.sesion = { servidor: m.servidorTexto, usuario: m.usuarioTexto, clave: m.claveTexto }
    GuardarSesion(m.sesion)
    m.cuentaInfo = r.datos
    m.errorLogin.text = ""
    m.login.visible = false
    m.principal.visible = true
    m.vista = "principal"
    m.secciones.jumpToItem = 0
    elegirSeccion(0)
    enfocar("secciones")
    if not m.lanzada
        m.lanzada = true
        if m.dialogoInicial then m.top.signalBeacon("AppDialogComplete")
        m.top.signalBeacon("AppLaunchComplete")
    end if
    if m.enlacePendiente <> invalid then abrirEnlace()
end sub

sub cerrarSesion(error as string)
    cerrarReproductor()
    cerrarSerie()
    BorrarDato("sesion")
    m.sesion = invalid
    m.claveTexto = ""
    mostrarLogin(error)
end sub

' ---------- Foco y teclas ----------
sub enfocar(zona as string)
    m.zona = zona
    if zona = "categorias" and m.categorias.visible
        m.categorias.setFocus(true)
    else if zona = "contenido"
        if m.canales.visible
            m.canales.setFocus(true)
        else if m.carteles.visible
            m.carteles.setFocus(true)
        else if m.filas.visible
            m.filas.setFocus(true)
        else if m.cuenta.visible
            m.botonesCuenta.setFocus(true)
        else
            m.zona = "secciones"
            m.secciones.setFocus(true)
        end if
    else
        m.zona = "secciones"
        m.secciones.setFocus(true)
    end if
end sub

function hayContenido() as boolean
    return m.canales.visible or m.carteles.visible or m.filas.visible or m.cuenta.visible
end function

function onKeyEvent(tecla as string, presionada as boolean) as boolean
    if not presionada then return false
    if m.vista = "login"
        if tecla = "options"
            pedirServidor()
            return true
        else if tecla = "back"
            preguntarSalida()
            return true
        end if
        return false
    end if
    if m.vista <> "principal" then return tecla = "back"

    if tecla = "back"
        if m.zona = "secciones"
            preguntarSalida()
        else
            enfocar("secciones")
        end if
        return true
    end if
    if m.zona = "secciones"
        if tecla = "right"
            if m.secciones.itemFocused <> m.seccion
                alElegirSeccion()
            else if hayContenido()
                enfocar("contenido")
            else if m.categorias.visible
                enfocar("categorias")
            end if
            return true
        end if
    else if m.zona = "categorias"
        if tecla = "down" and hayContenido()
            enfocar("contenido")
            return true
        else if tecla = "left"
            enfocar("secciones")
            return true
        end if
    else if m.zona = "contenido"
        if tecla = "left"
            enfocar("secciones")
            return true
        else if tecla = "up" and m.categorias.visible
            enfocar("categorias")
            return true
        else if tecla = "options"
            menuDeOpciones()
            return true
        end if
    end if
    return false
end function

sub preguntarSalida()
    preguntar("HerzSA TV", "¿Quieres salir de la app?", ["Salir", "Cancelar"], alPreguntarSalida)
end sub

sub alPreguntarSalida(boton as integer, texto as string)
    if boton = 0 then m.top.salir = true
end sub

' ---------- Secciones ----------
sub alElegirSeccion()
    i = m.secciones.itemFocused
    nombre = m.NOMBRES[i]
    if nombre = "Buscar"
        pedirTexto("Buscar", "Canales, películas o series.", "", false, alEscribirBusqueda)
    else if nombre = "Adultos"
        abrirAdultos()
    else
        elegirSeccion(i)
        if nombre = "Mi cuenta" then enfocar("contenido")
    end if
end sub

sub ocultarContenido(estado as string)
    m.carga = -1
    m.canales.visible = false
    m.carteles.visible = false
    m.filas.visible = false
    m.cuenta.visible = false
    m.estado.text = estado
    m.ayuda.visible = true
end sub

sub elegirSeccion(i as integer)
    m.seccion = i
    marcarSeccion()
    m.adultos = false
    nombre = m.NOMBRES[i]
    m.categorias.visible = false
    m.cats = []
    if nombre = "Inicio"
        ocultarContenido("Cargando…")
        m.carga = pedirApi("inicio", {}, alCargarInicio)
    else if nombre = "TV en vivo"
        cargarCategorias("live")
    else if nombre = "Películas"
        cargarCategorias("vod")
    else if nombre = "Series"
        cargarCategorias("series")
    else if nombre = "Favoritos"
        ocultarContenido("Cargando…")
        m.carga = pedirApi("favoritos", { ids: LeerDato("favoritos", []) }, alCargarLista)
    else if nombre = "Mi cuenta"
        mostrarCuenta()
    end if
end sub

sub alCargarInicio(r as object)
    if r.n <> m.carga then return
    if not fallo(r)
        m.filas.content = r.contenido
        m.filas.visible = r.contenido.getChildCount() > 0
        m.estado.text = ""
        if not m.filas.visible then m.estado.text = "Todavía no hay películas en el servidor."
    end if
end sub

' Muestra el error de una respuesta; si la cuenta venció o se suspendió, regresa al inicio de sesión.
function fallo(r as object) as boolean
    if r.ok then return false
    if r.cuenta
        cerrarSesion(r.error)
    else
        m.estado.text = r.error
    end if
    return true
end function

sub alEscribirBusqueda(boton as integer, texto as string)
    if boton <> 0 or texto.Trim() = "" then return
    m.seccion = Posicion(m.NOMBRES, "Buscar")
    marcarSeccion()
    m.adultos = false
    m.categorias.visible = false
    ocultarContenido("Buscando «" + texto.Trim() + "»…")
    m.textoBuscado = texto.Trim()
    m.carga = pedirApi("buscar", { texto: texto }, alCargarLista)
end sub

' ---------- Categorías ----------
sub cargarCategorias(tipo as string)
    m.tipo = tipo
    ocultarContenido("Cargando…")
    tipos = [tipo]
    if m.adultos then tipos = ["live", "vod", "series"]
    m.carga = pedirApi("categorias", { tipos: tipos, adultos: m.adultos }, alCargarCategorias)
end sub

sub alCargarCategorias(r as object)
    if r.n <> m.carga or fallo(r) then return
    m.cats = []
    if m.adultos
        ' Las categorías de adultos de los tres tipos van juntas, con «Todo» de cada tipo primero.
        m.cats.Push({ id: "", nombre: "Canales: todo", tipo: "live" })
        m.cats.Push({ id: "", nombre: "Películas: todo", tipo: "vod" })
        m.cats.Push({ id: "", nombre: "Series: todo", tipo: "series" })
    else
        m.cats.Push({ id: "", nombre: "Todo", tipo: m.tipo })
    end if
    m.cats.Append(r.datos.lista)
    raiz = CreateObject("roSGNode", "ContentNode")
    fila = raiz.createChild("ContentNode")
    for each c in m.cats
        fila.createChild("ContentNode").title = c.nombre
    end for
    m.categorias.content = raiz
    m.categorias.visible = true
    m.catElegida = -1
    cargarCategoria(0)
end sub

sub alEnfocarCategoria()
    if m.zona <> "categorias" then return
    m.esperaCategoria.control = "stop"
    m.esperaCategoria.control = "start"
end sub

' Al recorrer la tira se carga la categoría en la que se detiene el foco.
sub alEsperarCategoria()
    k = m.categorias.rowItemFocused[1]
    if k <> m.catElegida then cargarCategoria(k)
end sub

sub alElegirCategoria()
    k = m.categorias.rowItemSelected[1]
    if k <> m.catElegida then cargarCategoria(k)
    m.irAlContenido = true
    if hayContenido() then enfocar("contenido")
end sub

sub cargarCategoria(k as integer)
    if k < 0 or k >= m.cats.Count() then return
    fila = m.categorias.content.getChild(0)
    if m.catElegida >= 0 and m.catElegida < fila.getChildCount() then fila.getChild(m.catElegida).ShortDescriptionLine2 = ""
    fila.getChild(k).ShortDescriptionLine2 = "activa"
    m.catElegida = k
    c = m.cats[k]
    m.tipoCargado = c.tipo
    zona = m.zona
    ocultarContenido("Cargando…")
    m.zona = zona
    m.carga = pedirApi("elementos", { tipo: c.tipo, categoria: c.id, adultos: m.adultos }, alCargarLista)
end sub

sub alCargarLista(r as object)
    if r.n <> m.carga or fallo(r) then return
    contenido = r.contenido
    if contenido.getChildCount() = 0
        nombre = m.NOMBRES[m.seccion]
        if nombre = "Favoritos"
            m.estado.text = "Aún no tienes favoritos. En cualquier canal, película o serie pulsa el botón * del control para agregarlo."
        else if nombre = "Buscar"
            m.estado.text = "No se encontró «" + m.textoBuscado + "»."
        else
            m.estado.text = "No hay nada en esta categoría."
        end if
        m.irAlContenido = false
        return
    end if
    m.estado.text = ""
    ' Los canales van en lista con logo; lo demás (y lo mezclado de favoritos o búsqueda) en carátulas.
    soloCanales = true
    for i = 0 to contenido.getChildCount() - 1
        if Left(contenido.getChild(i).id, 5) <> "live:"
            soloCanales = false
            exit for
        end if
    end for
    if soloCanales
        m.canales.content = contenido
        m.canales.jumpToItem = 0
        m.canales.visible = true
    else
        m.carteles.content = contenido
        m.carteles.jumpToItem = 0
        m.carteles.visible = true
    end if
    if m.irAlContenido = true or m.zona = "contenido" then enfocar("contenido")
    m.irAlContenido = false
end sub

' ---------- Abrir y favoritos ----------
sub alElegirCanal()
    abrir(m.canales.content, m.canales.itemSelected)
end sub

sub alElegirCartel()
    abrir(m.carteles.content, m.carteles.itemSelected)
end sub

sub alElegirEnFila()
    rc = m.filas.rowItemSelected
    abrir(m.filas.content.getChild(rc[0]), rc[1])
end sub

sub abrir(lista as object, i as integer)
    nodo = lista.getChild(i)
    if nodo = invalid then return
    if Left(nodo.id, 7) = "series:"
        abrirSerie(nodo)
    else
        reproducir(lista, i)
    end if
end sub

function nodoEnfocado() as dynamic
    if m.canales.visible and m.canales.hasFocus() then return m.canales.content.getChild(m.canales.itemFocused)
    if m.carteles.visible and m.carteles.hasFocus() then return m.carteles.content.getChild(m.carteles.itemFocused)
    if m.filas.visible and m.filas.hasFocus()
        rc = m.filas.rowItemFocused
        fila = m.filas.content.getChild(rc[0])
        if fila <> invalid then return fila.getChild(rc[1])
    end if
    return invalid
end function

' Botón * sobre un canal, película o serie: menú con agregar o quitar de favoritos.
sub menuDeOpciones()
    nodo = nodoEnfocado()
    if nodo = invalid then return
    m.nodoMenu = nodo
    if Posicion(LeerDato("favoritos", []), nodo.id) >= 0 then fav = "Quitar de favoritos" else fav = "Agregar a favoritos"
    preguntar(nodo.title, "Menú de opciones", [fav, "Cancelar"], alElegirOpcion)
end sub

sub alElegirOpcion(boton as integer, texto as string)
    if boton = 0 and m.nodoMenu <> invalid then alternarFavorito(m.nodoMenu)
    m.nodoMenu = invalid
end sub

sub alternarFavorito(nodo as object)
    if nodo = invalid then return
    ' Lo de adultos no se mezcla con los favoritos, que no piden PIN.
    if m.adultos
        aviso("Lo de Adultos no se puede agregar a favoritos")
        return
    end if
    favs = LeerDato("favoritos", [])
    k = Posicion(favs, nodo.id)
    if k >= 0
        favs.Delete(k)
        nodo.ShortDescriptionLine2 = ""
        aviso("Quitado de favoritos")
    else
        favs.Push(nodo.id)
        nodo.ShortDescriptionLine2 = "fav"
        aviso("Agregado a favoritos")
    end if
    GuardarDato("favoritos", favs)
    ' En Inicio la misma película puede estar en las dos filas.
    if m.filas.visible
        for f = 0 to m.filas.content.getChildCount() - 1
            fila = m.filas.content.getChild(f)
            for c = 0 to fila.getChildCount() - 1
                if fila.getChild(c).id = nodo.id then fila.getChild(c).ShortDescriptionLine2 = nodo.ShortDescriptionLine2
            end for
        end for
    end if
end sub

' ---------- Mi cuenta ----------
sub mostrarCuenta()
    ocultarContenido("")
    m.ayuda.visible = false
    estado = m.cuentaInfo.estado
    if estado = invalid or estado = "" or LCase(estado) = "active" then estado = "Activa"
    lineas = [
        "Usuario:   " + m.sesion.usuario,
        "Estado:   " + estado,
        "Vence:   " + Cadena(m.cuentaInfo.vence),
        "Conexiones en uso:   " + Cadena(m.cuentaInfo.conexiones),
        "Versión de la app:   " + m.version
    ]
    if m.sesion.servidor <> m.servidorFijo then lineas.Push("Servidor:   " + m.sesion.servidor)
    texto = ""
    for each l in lineas
        texto = texto + l + Chr(10)
    end for
    m.datosCuenta.text = texto
    m.botonesCuenta.buttons = ["Actualizar datos", "Cerrar sesión"]
    m.cuenta.visible = true
end sub

sub alBotonCuenta()
    b = m.botonesCuenta.buttonSelected
    if b = 0
        m.datosCuenta.text = "Consultando…"
        pedirApi("entrar", { servidor: m.sesion.servidor, usuario: m.sesion.usuario, clave: m.sesion.clave }, alActualizarCuenta)
    else if b = 1
        preguntar("Cerrar sesión", "Se borrarán tu usuario y contraseña de este equipo.", ["Cerrar sesión", "Cancelar"], alConfirmarCierre)
    end if
end sub

sub alActualizarCuenta(r as object)
    if not r.ok
        if r.cuenta then cerrarSesion(r.error) else m.datosCuenta.text = r.error
        return
    end if
    m.cuentaInfo = r.datos
    if m.cuenta.visible then mostrarCuenta()
end sub

sub alConfirmarCierre(boton as integer, texto as string)
    if boton = 0 then cerrarSesion("")
end sub

' ---------- Adultos: se entra con un PIN que crea el propio usuario ----------
sub abrirAdultos()
    if LeerDato("pin", invalid) = invalid
        crearPin()
        return
    end if
    d = CreateObject("roSGNode", "StandardPinPadDialog")
    d.title = "Contenido para adultos"
    d.message = ["Escribe tu PIN para entrar."]
    d.buttons = ["Entrar", "Cambiar PIN", "Cancelar"]
    if d.textEditBox <> invalid then d.textEditBox.maxTextLength = 8
    abrirDialogo(d, alEscribirPinAdultos)
end sub

sub alEscribirPinAdultos(boton as integer, pin as string)
    if boton = 1
        cambiarPin()
    else if boton = 0
        if Huella(pin) = LeerDato("pin", "")
            entrarAAdultos()
        else
            aviso("PIN incorrecto")
        end if
    end if
end sub

sub entrarAAdultos()
    m.seccion = Posicion(m.NOMBRES, "Adultos")
    marcarSeccion()
    m.adultos = true
    cargarCategorias("live")
    m.adultos = true
end sub

sub crearPin()
    pedirPin("Crea tu PIN", "La sección Adultos se abre con un PIN que solo tú conoces. Elige de 4 a 8 números.", alCrearPin)
end sub

sub alCrearPin(boton as integer, pin as string)
    if boton <> 0 then return
    if Len(pin) < 4 or Len(pin) > 8
        aviso("El PIN debe tener de 4 a 8 números")
        return
    end if
    m.pinNuevo = pin
    pedirPin("Repite el PIN", "Escribe otra vez el mismo PIN.", alRepetirPin)
end sub

sub alRepetirPin(boton as integer, pin as string)
    if boton <> 0 then return
    if pin <> m.pinNuevo
        aviso("Los dos PIN no coinciden")
        return
    end if
    GuardarDato("pin", Huella(pin))
    aviso("PIN guardado")
    entrarAAdultos()
end sub

' Cambiar u olvidar el PIN: se comprueba con la contraseña de la cuenta de televisión.
sub cambiarPin()
    pedirTexto("Cambiar PIN", "Escribe la contraseña de tu cuenta de televisión (usuario " + m.sesion.usuario + ").", "", true, alComprobarClave)
end sub

sub alComprobarClave(boton as integer, clave as string)
    if boton <> 0 then return
    if clave <> m.sesion.clave
        aviso("Contraseña incorrecta")
        return
    end if
    BorrarDato("pin")
    crearPin()
end sub

' ---------- Serie ----------
sub abrirSerie(nodo as object)
    cerrarSerie()
    m.serie = CreateObject("roSGNode", "SeriesView")
    m.serie.datos = { titulo: nodo.title, sinopsis: "", portada: nodo.HDPosterUrl }
    m.serie.observeField("elegido", "alElegirEpisodio")
    m.serie.observeField("cerrado", "alCerrarSerie")
    m.top.appendChild(m.serie)
    m.principal.visible = false
    m.vista = "serie"
    m.serie.foco = true
    pedirApi("serie", { id: Mid(nodo.id, 8) }, alCargarSerie)
end sub

sub alCargarSerie(r as object)
    if m.serie = invalid then return
    if not r.ok
        if r.cuenta
            cerrarSesion(r.error)
            return
        end if
        m.serie.error = r.error
        return
    end if
    if r.datos <> invalid then m.serie.datos = r.datos
    m.serie.contenido = r.contenido
    if m.vista = "serie" then m.serie.foco = true
end sub

sub alElegirEpisodio()
    e = m.serie.elegido
    temporada = m.serie.contenido.getChild(e.temporada)
    if temporada <> invalid then reproducir(temporada, e.episodio)
end sub

sub alCerrarSerie()
    cerrarSerie()
    m.principal.visible = true
    m.vista = "principal"
    restaurarFoco()
end sub

sub cerrarSerie()
    if m.serie = invalid then return
    m.top.removeChild(m.serie)
    m.serie = invalid
    m.principal.visible = m.vista = "principal"
end sub

' ---------- Reproductor ----------
sub reproducir(lista as object, i as integer)
    cerrarReproductor()
    m.vistaAntes = m.vista
    m.reproductor = CreateObject("roSGNode", "PlayerView")
    m.reproductor.cuenta = m.sesion
    m.reproductor.lista = lista
    m.reproductor.indice = i
    m.reproductor.observeField("cerrado", "alCerrarReproductor")
    m.top.appendChild(m.reproductor)
    ' El video se dibuja debajo de todo lo demás: se oculta la interfaz mientras se ve.
    m.fondo.visible = false
    m.velo.visible = false
    m.principal.visible = false
    if m.serie <> invalid then m.serie.visible = false
    m.vista = "reproductor"
    m.reproductor.iniciar = true
end sub

sub alCerrarReproductor()
    motivo = m.reproductor.cerrado
    cerrarReproductor()
    m.fondo.visible = true
    m.velo.visible = true
    m.vista = m.vistaAntes
    if m.vista = "serie" and m.serie <> invalid
        m.serie.visible = true
    else
        m.vista = "principal"
        m.principal.visible = true
    end if
    if motivo <> invalid and motivo <> "" and motivo <> "regresar" then cerrarSesion(motivo) else restaurarFoco()
end sub

sub cerrarReproductor()
    if m.reproductor = invalid then return
    m.reproductor.unobserveField("cerrado")
    m.reproductor.detener = true
    m.top.removeChild(m.reproductor)
    m.reproductor = invalid
end sub

' ---------- Enlaces directos (búsqueda de Roku y roInput) ----------
' mediaType oficial de Roku → tipo del XUI. Sin sesión, el enlace se guarda y se abre al entrar.
' El mismo enlace repetido en menos de 3 s (arranque + roInput) se atiende una sola vez.
sub alRecibirEnlace()
    e = m.top.enlace
    if e = invalid or e.id = invalid then return
    t = e.tipo
    if t = "live"
        tipo = "live"
    else if t = "movie" or t = "shortformvideo" or t = "tvspecial" or t = "special"
        tipo = "vod"
    else if t = "series" or t = "season"
        tipo = "series"
    else if t = "episode"
        tipo = "episode"
    else
        print "[HerzSA] enlace ignorado: mediaType no admitido "; t
        avisoEnlace("Ese tipo de contenido no se puede abrir desde un enlace.")
        return
    end if
    clave = tipo + ":" + e.id
    if clave = m.ultimoEnlace and m.relojEnlace.TotalMilliseconds() < 3000
        print "[HerzSA] enlace repetido ignorado: "; clave
        return
    end if
    m.ultimoEnlace = clave
    m.relojEnlace.Mark()
    print "[HerzSA] enlace recibido: "; clave
    m.enlacePendiente = { tipo: tipo, id: e.id }
    if m.sesion <> invalid and m.vista <> "login"
        abrirEnlace()
    else
        print "[HerzSA] enlace pendiente hasta iniciar sesión"
    end if
end sub

sub abrirEnlace()
    e = m.enlacePendiente
    m.enlacePendiente = invalid
    m.nEnlace = pedirApi("enlace", e, alCargarEnlace)
end sub

sub alCargarEnlace(r as object)
    ' Solo cuenta la respuesta del último enlace (si llegó otro, este se descarta).
    if r.n <> m.nEnlace then return
    m.nEnlace = -1
    if not r.ok
        print "[HerzSA] enlace sin abrir: "; r.error
        if r.cuenta
            cerrarSesion(r.error)
        else
            avisoEnlace(r.error)
        end if
        return
    end if
    lista = r.contenido
    indice = 0
    if r.datos <> invalid and r.datos.indice <> invalid then indice = r.datos.indice
    nodo = lista.getChild(indice)
    if nodo = invalid then return
    print "[HerzSA] enlace abierto: "; nodo.id
    cerrarDialogo()
    if m.reproductor <> invalid
        cerrarReproductor()
        m.fondo.visible = true
        m.velo.visible = true
    end if
    cerrarSerie()
    m.vista = "principal"
    m.principal.visible = true
    if Left(nodo.id, 7) = "series:" then abrirSerie(nodo) else reproducir(lista, indice)
end sub

' Error de un enlace: en un diálogo (se ve encima del reproductor o de una serie); OK vuelve a donde estaba.
sub avisoEnlace(texto as string)
    if m.vista = "login"
        m.errorLogin.text = texto
        return
    end if
    cerrarDialogo()
    preguntar("Contenido no disponible", texto, ["Aceptar"], alAceptarAviso)
end sub

sub alAceptarAviso(boton as integer, texto as string)
end sub

sub cerrarDialogo()
    if m.dialogo = invalid then return
    m.dialogo.unobserveField("wasClosed")
    m.dialogo.close = true
    m.dialogo = invalid
    m.alDialogo = invalid
end sub

' Poca memoria: se borran las listas que guarda la tarea de red (se vuelven a pedir al abrirlas).
sub alFaltarMemoria()
    pedirApi("olvidar", {}, alOlvidar)
end sub

sub alOlvidar(r as object)
end sub
