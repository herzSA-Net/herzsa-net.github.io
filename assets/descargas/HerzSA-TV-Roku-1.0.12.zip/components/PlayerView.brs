' Reproductor. En vivo: arriba/abajo cambian de canal, OK muestra el programa actual y los
' siguientes, izquierda/derecha cambian el formato (el canal lo recuerda). Películas y series:
' cualquier tecla muestra los botones transparentes (Volver, Retroceder, Pausa/Reproducir,
' Adelantar) con el avance; ◄ ► eligen y OK acepta. Arriba se ven la fecha, la hora y la red.
' Se retoma donde se quedó y al terminar un episodio sigue el siguiente. El botón * cambia el formato en todo. Si se cae la señal reintenta solo.
' El formato elegido se recuerda: por canal en vivo, y uno solo para películas y series.

sub init()
    for each id in ["video", "capa", "nombre", "hora", "guia", "teclas", "avisoFormato", "estado", "relojCapa", "relojFormato", "relojReintento", "relojZapeo", "arriba", "tituloArriba", "fecha", "red", "controles", "f0", "f1", "f2", "f3", "iconoPausa", "textoPausa", "barra", "tiempo", "duracion", "ayudaControles", "relojControles"]
        m[id] = m.top.findNode(id)
    end for
    m.OPCIONES = ["Automático", "Completo", "Llenar", "Zoom"]
    m.video.notificationInterval = 1
    m.video.observeField("state", "alCambiarEstado")
    m.video.observeField("position", "alAvanzar")
    m.video.observeField("streamingSegment", "alSegmento")
    m.video.observeField("downloadedSegment", "alDescargado")
    m.relojCapa.observeField("fire", "ocultarCapa")
    m.relojFormato.observeField("fire", "ocultarFormato")
    m.relojReintento.observeField("fire", "arrancar")
    m.relojZapeo.observeField("fire", "alTerminarZapeo")
    m.relojControles.observeField("fire", "ocultarControles")
    m.boton = 2
    m.vivo = false
    m.api = invalid
    m.n = 0
    m.nodo = invalid
    m.ancho = 0
    m.alto = 0
    m.aspectoMeta = 0
    m.nVideo = -1
    m.nGuia = -1
    m.formatoReal = invalid
    m.ultimoGuardado = 0
end sub

sub alIniciar()
    m.api = CreateObject("roSGNode", "ApiTask")
    m.api.observeField("respuesta", "alResponder")
    m.api.control = "RUN"
    m.formatos = LeerDato("formatos", {})
    m.formatoVod = LeerDato("formatoVod", "")
    leerAjustes()
    m.posiciones = LeerDato("posiciones", {})
    ponerElemento(m.top.indice)
    darFoco()
end sub

' En vivo el foco va al video; en películas a este componente, que maneja todas las teclas.
sub darFoco()
    if m.vivo then m.video.setFocus(true) else m.top.setFocus(true)
end sub

sub alDetener()
    guardarPosicion(true)
    m.relojReintento.control = "stop"
    m.relojZapeo.control = "stop"
    m.video.control = "stop"
    if m.api <> invalid then m.api.control = "stop"
end sub

sub cerrar(motivo as string)
    alDetener()
    m.top.cerrado = motivo
end sub

' ---------- Elemento actual ----------
function esVivo(nodo as object) as boolean
    return nodo <> invalid and Left(nodo.id, 5) = "live:"
end function

function reproducible(nodo as object) as boolean
    return nodo <> invalid and nodo.url <> invalid and nodo.url <> ""
end function

sub ponerElemento(i as integer)
    guardarPosicion(true)
    nodo = m.top.lista.getChild(i)
    if not reproducible(nodo)
        cerrar("regresar")
        return
    end if
    m.indice = i
    m.nodo = nodo
    m.vivo = esVivo(nodo)
    m.reintentos = 0
    m.posicion = 0
    m.ancho = 0
    m.alto = 0
    m.aspectoMeta = 0
    m.nVideo = -1
    if not m.vivo
        ' Proporción real: la del episodio viene con la serie; la de una película se pide al XUI.
        if nodo.aspecto <> invalid and nodo.aspecto > 0
            m.aspectoMeta = nodo.aspecto
        else if Left(nodo.id, 4) = "vod:"
            m.n = m.n + 1
            m.nVideo = m.n
            v = { n: m.n, accion: "video", id: Mid(nodo.id, 5) }
            v.Append(cuenta())
            m.api.solicitud = v
        end if
    end if
    if not m.vivo
        guardada = m.posiciones[nodo.id]
        if guardada <> invalid and guardada > 30 then m.posicion = guardada
    end if
    m.formato = m.formatoBase
    if m.vivo and m.formatos[nodo.id] <> invalid then m.formato = m.formatos[nodo.id]
    if not m.vivo and m.formatoVod <> "" then m.formato = m.formatoVod
    if Posicion(m.OPCIONES, m.formato) < 0 then m.formato = m.formatoBase
    m.capa.visible = false
    m.controles.visible = false
    m.arriba.visible = false
    if m.vivo then mostrarCapa() else mostrarControles()
    arrancar()
    darFoco()
    if m.posicion > 0 then avisar("Continuando donde te quedaste")
end sub

sub arrancar()
    m.relojReintento.control = "stop"
    c = CreateObject("roSGNode", "ContentNode")
    c.url = m.nodo.url
    c.streamFormat = m.nodo.streamFormat
    c.title = m.nodo.title
    c.live = m.vivo
    if m.posicion > 0 then c.PlayStart = m.posicion
    ' Películas: sin la interfaz de Roku, van los botones propios. En vivo se deja la de Roku
    ' (sin ella el canal no arrancaba en las pruebas); su pantalla de carga trae título y hora,
    ' así que mientras carga se esconde la barra de arriba (alCambiarEstado).
    m.video.enableTrickPlay = false
    m.video.enableUI = m.vivo
    m.video.content = c
    m.video.control = "play"
    if m.reintentos = 0 then m.estado.text = ""
    aplicarFormato()
end sub

sub alCambiarEstado()
    s = m.video.state
    if not m.vivo then actualizarPausa()
    if s = "playing"
        m.reintentos = 0
        m.estado.text = ""
        if m.controles.visible then esconderLuego()
        if m.vivo and m.capa.visible then m.arriba.visible = true
    else if s = "buffering" and m.vivo
        m.arriba.visible = false
    else if s = "buffering" and m.reintentos = 0
        m.estado.text = "Cargando…"
    else if s = "paused"
        mostrarControles()
    else if s = "error"
        falla()
    else if s = "finished"
        if m.vivo
            ' Un canal en vivo no termina: se cortó la señal.
            falla()
        else
            m.posiciones.Delete(m.nodo.id)
            m.posicion = 0
            guardarPosicion(true)
            siguiente = m.indice + 1
            if Left(m.nodo.id, 8) = "episode:" and reproducible(m.top.lista.getChild(siguiente))
                ponerElemento(siguiente)
            else
                cerrar("regresar")
            end if
        end if
    end if
end sub

sub falla()
    if m.reintentos < 3
        m.reintentos = m.reintentos + 1
        m.estado.text = "Reconectando… (" + m.reintentos.ToStr() + " de 3)"
        m.relojReintento.control = "start"
        return
    end if
    que = "este video"
    if m.vivo then que = "este canal"
    detalle = m.video.errorMsg
    texto = "No se pudo reproducir " + que + "."
    if detalle <> invalid and detalle <> "" then texto = texto + Chr(10) + "(" + detalle + ")"
    if m.vivo then texto = texto + Chr(10) + "Prueba otro canal con arriba o abajo."
    m.estado.text = texto
end sub

' ---------- Posición de películas y episodios ----------
sub alAvanzar()
    if m.vivo or m.nodo = invalid then return
    if m.video.position > 0 then m.posicion = m.video.position
    if m.controles.visible then actualizarAvance()
    guardarPosicion(false)
end sub

sub guardarPosicion(ahora as boolean)
    if m.nodo = invalid or m.vivo or m.posiciones = invalid then return
    reloj = CreateObject("roDateTime").AsSeconds()
    if not ahora and reloj - m.ultimoGuardado < 30 then return
    m.ultimoGuardado = reloj
    duracion = m.video.duration
    if m.posicion > 30 and (duracion = invalid or duracion <= 0 or m.posicion < duracion - 60)
        m.posiciones[m.nodo.id] = Int(m.posicion)
    else
        m.posiciones.Delete(m.nodo.id)
    end if
    if m.posiciones.Count() > 300 then m.posiciones = {}
    GuardarDato("posiciones", m.posiciones)
end sub

' ---------- Canal: cambiar y mostrar guía ----------
sub zapear(paso as integer)
    lista = m.top.lista
    total = lista.getChildCount()
    j = m.indice
    if m.pendiente <> invalid then j = m.pendiente
    for k = 1 to total
        j = (j + paso + total) mod total
        if esVivo(lista.getChild(j)) then exit for
    end for
    m.pendiente = j
    ' El nombre cambia en seguida; el video arranca cuando se deja de pulsar.
    m.nombre.text = lista.getChild(j).title
    m.guia.text = ""
    m.capa.visible = true
    m.relojCapa.control = "stop"
    m.relojZapeo.control = "stop"
    m.relojZapeo.control = "start"
end sub

sub alTerminarZapeo()
    j = m.pendiente
    m.pendiente = invalid
    if j <> invalid and j <> m.indice then ponerElemento(j)
end sub

sub mostrarCapa()
    actualizarArriba("TV en vivo")
    m.arriba.visible = m.video.state = "playing"
    m.nombre.text = m.nodo.title
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    m.hora.text = DosCifras(d.GetHours()) + ":" + DosCifras(d.GetMinutes())
    if m.vivo
        m.guia.text = ""
        ponerTeclas()
        m.n = m.n + 1
        m.nGuia = m.n
        s = { n: m.n, accion: "guia", id: Mid(m.nodo.id, 6) }
        s.Append(cuenta())
        m.api.solicitud = s
    end if
    m.capa.visible = true
    m.relojCapa.control = "stop"
    m.relojCapa.control = "start"
end sub

' Vuelve a abrir el canal en vivo. La sincronía de imagen y sonido la hace el Roku al decodificar
' (una app no puede adelantar ni atrasar el audio); si la señal del XUI trae los tiempos mal, el
' desfase se acumula y la única corrección desde aquí es arrancar el canal de nuevo.
sub resincronizar()
    m.reintentos = 0
    m.estado.text = ""
    arrancar()
    avisar("Sincronizando imagen y sonido…")
end sub

sub ponerTeclas()
    m.teclas.text = "Arriba y abajo: canal      Izquierda y derecha, o *: formato (" + m.formato + ")      Repetir o Play: sincronizar sonido      Atrás: salir"
    m.ayudaControles.text = "Izquierda y derecha: elegir botón      OK: aceptar      *: formato (" + m.formato + ")      Atrás: salir"
end sub

sub actualizarArriba(titulo as string)
    m.tituloArriba.text = titulo
    m.fecha.text = FechaYHora()
    m.red.text = NombreRed()
end sub

' ---------- Botones de películas y episodios ----------
sub mostrarControles()
    if not m.controles.visible then m.boton = 2
    actualizarArriba(m.nodo.title)
    ponerTeclas()
    actualizarPausa()
    pintarBotones()
    actualizarAvance()
    m.arriba.visible = true
    m.controles.visible = true
    esconderLuego()
end sub

' Se esconden a los 5 s sin tocar nada, salvo en pausa.
sub esconderLuego()
    m.relojControles.control = "stop"
    if m.video.state <> "paused" then m.relojControles.control = "start"
end sub

sub ocultarControles()
    if m.video.state = "paused" then return
    m.controles.visible = false
    m.arriba.visible = false
end sub

sub pintarBotones()
    for i = 0 to 3
        f = m["f" + i.ToStr()]
        if i = m.boton
            f.blendColor = "0x6CD83CFF"
            f.opacity = 1.0
        else
            f.blendColor = "0x000000FF"
            f.opacity = 0.45
        end if
    end for
end sub

sub actualizarPausa()
    if m.video.state = "paused"
        m.iconoPausa.uri = "pkg:/images/boton_play.png"
        m.textoPausa.text = "Reproducir"
    else
        m.iconoPausa.uri = "pkg:/images/boton_pausa.png"
        m.textoPausa.text = "Pausa"
    end if
end sub

sub actualizarAvance()
    actual = m.video.position
    dur = m.video.duration
    if actual = invalid or actual < 0 then actual = 0
    if dur = invalid or dur < 0 then dur = 0
    m.tiempo.text = ATiempo(actual)
    if dur > 0
        m.duracion.text = ATiempo(dur)
        ancho = Int(1700 * actual / dur)
        if ancho > 1700 then ancho = 1700
        m.barra.width = ancho
    else
        m.duracion.text = ""
        m.barra.width = 0
    end if
    m.fecha.text = FechaYHora()
end sub

' 3725 → «1:02:05»; 125 → «2:05».
function ATiempo(segundos as float) as string
    t = Int(segundos)
    h = Int(t / 3600)
    mi = Int((t mod 3600) / 60)
    se = t mod 60
    if h > 0 then return h.ToStr() + ":" + DosCifras(mi) + ":" + DosCifras(se)
    return mi.ToStr() + ":" + DosCifras(se)
end function

sub alternarPausa()
    if m.video.state = "paused" then m.video.control = "resume" else m.video.control = "pause"
end sub

sub saltar(segundos as integer)
    p = m.video.position + segundos
    dur = m.video.duration
    if dur <> invalid and dur > 0 and p > dur - 5 then p = dur - 5
    if p < 0 then p = 0
    m.video.seek = p
    m.posicion = p
    avisar(ATiempo(p))
end sub

sub activarBoton()
    if m.boton = 0
        cerrar("regresar")
    else if m.boton = 1
        saltar(-10)
    else if m.boton = 2
        alternarPausa()
    else if m.boton = 3
        saltar(10)
    end if
end sub

function teclaDePelicula(tecla as string) as boolean
    ' Las teclas propias del control funcionan siempre.
    if tecla = "play"
        alternarPausa()
        mostrarControles()
        return true
    else if tecla = "rewind" or tecla = "fastforward" or tecla = "replay"
        if tecla = "rewind" then saltar(-30)
        if tecla = "fastforward" then saltar(30)
        if tecla = "replay" then saltar(-10)
        mostrarControles()
        return true
    end if
    ' Con los botones escondidos, la primera tecla solo los muestra.
    if not m.controles.visible
        mostrarControles()
        return true
    end if
    if tecla = "left"
        if m.boton > 0 then m.boton = m.boton - 1
    else if tecla = "right"
        if m.boton < 3 then m.boton = m.boton + 1
    else if tecla = "OK"
        activarBoton()
        if m.boton = 0 then return true
    else if tecla <> "up" and tecla <> "down"
        return false
    end if
    pintarBotones()
    esconderLuego()
    return true
end function

function cuenta() as object
    c = m.top.cuenta
    return { servidor: c.servidor, usuario: c.usuario, clave: c.clave }
end function

sub alResponder(ev as object)
    r = ev.getData()
    if r = invalid or r.datos = invalid then return
    if r.accion = "video"
        if r.n = m.nVideo and r.datos.aspecto <> invalid and r.datos.aspecto > 0
            m.aspectoMeta = r.datos.aspecto
            aplicarFormato()
        end if
        return
    end if
    if r.n <> m.nGuia then return
    lineas = r.datos.lineas
    if lineas = invalid or lineas.Count() = 0
        m.guia.text = "Sin guía de programación para este canal."
        return
    end if
    texto = ""
    for i = 0 to lineas.Count() - 1
        if i > 0 then texto = texto + Chr(10)
        if i = 0 then texto = texto + "Ahora:  " else texto = texto + "Después:  "
        texto = texto + lineas[i]
    end for
    m.guia.text = texto
end sub

sub ocultarCapa()
    m.capa.visible = false
    m.arriba.visible = false
end sub

' ---------- Formato de pantalla ----------
' Automático llena la pantalla recortando (nunca estira) si el video y la pantalla se parecen
' (hasta 34 % de diferencia, como en Android TV); si no, lo deja completo. Llenar recorta
' siempre para cubrir la pantalla y Zoom amplía un 33 % (quita las franjas que ya vienen
' dentro de la imagen). Roku no estira el video: siempre conserva la proporción.
'
' ajustes.json en el panel (lo baja MainScene al abrir la app) cambia esto sin publicar otra versión:
'   formato   el de inicio cuando el usuario no eligió otro ("Automático" o "Completo")
'   recortar  false = solo «Completo» (por si un modelo de Roku no recorta bien el video agrandado)
'   umbral    diferencia máxima de proporción para que Automático recorte (0.34)
sub leerAjustes()
    aj = LeerDato("ajustes", {})
    if type(aj) <> "roAssociativeArray" then aj = {}
    m.recortar = not (aj.recortar = false)
    m.umbral = 0.34
    if GetInterface(aj.umbral, "ifFloat") <> invalid or GetInterface(aj.umbral, "ifInt") <> invalid or GetInterface(aj.umbral, "ifDouble") <> invalid
        if aj.umbral >= 0 and aj.umbral <= 1 then m.umbral = aj.umbral
    end if
    if m.recortar
        m.OPCIONES = ["Automático", "Completo", "Llenar", "Zoom"]
    else
        m.OPCIONES = ["Completo"]
    end if
    m.formatoBase = m.OPCIONES[0]
    if aj.formato <> invalid and Posicion(m.OPCIONES, aj.formato) >= 0 then m.formatoBase = aj.formato
end sub

' Tamaño codificado del video: Roku lo da en los segmentos de HLS (en vivo); en MP4/MKV no.
sub alSegmento()
    s = m.video.streamingSegment
    if s <> invalid then tamano(s.width, s.height)
end sub

sub alDescargado()
    s = m.video.downloadedSegment
    if s <> invalid then tamano(s.Width, s.Height)
end sub

sub tamano(ancho as dynamic, alto as dynamic)
    if ancho = invalid or alto = invalid then return
    if ancho <= 0 or alto <= 0 then return
    if ancho = m.ancho and alto = m.alto then return
    m.ancho = ancho
    m.alto = alto
    aplicarFormato()
end sub

' Proporción del video, o 0 si no se sabe. Las resoluciones de TV estándar (720x480, 720x576,
' 1440x1080…) usan pixeles no cuadrados y su proporción real no se puede saber desde aquí.
function proporcion() as float
    if m.aspectoMeta > 0 then return m.aspectoMeta
    if m.ancho <= 0 or m.alto <= 0 then return 0
    if m.alto = 480 or m.alto = 576 or m.ancho = 1440 or m.ancho = 960 or (m.ancho = 1280 and m.alto = 1080) then return 0
    return m.ancho / m.alto
end function

sub aplicarFormato()
    pantalla = 1920 / 1080
    a = proporcion()
    f = m.formato
    if not m.recortar then f = "Completo"
    if f = "Automático"
        f = "Completo"
        if a > 0
            diferencia = Abs(a - pantalla) / pantalla
            if diferencia > 0.01 and diferencia <= m.umbral then f = "Llenar"
        end if
    end if
    ancho = 1920
    alto = 1080
    if f = "Llenar"
        if a <= 0 then a = 4 / 3
        if a < pantalla
            alto = Int(1920 / a)
        else
            ancho = Int(1080 * a)
        end if
    else if f = "Zoom"
        ancho = 2560
        alto = 1440
    end if
    m.formatoReal = f
    m.video.width = ancho
    m.video.height = alto
    m.video.translation = [Int((1920 - ancho) / 2), Int((1080 - alto) / 2)]
end sub

sub cambiarFormato()
    k = Posicion(m.OPCIONES, m.formato)
    m.formato = m.OPCIONES[(k + 1) mod m.OPCIONES.Count()]
    if m.vivo
        if m.formato = m.formatoBase then m.formatos.Delete(m.nodo.id) else m.formatos[m.nodo.id] = m.formato
        GuardarDato("formatos", m.formatos)
    else
        m.formatoVod = m.formato
        if m.formato = m.formatoBase then m.formatoVod = ""
        GuardarDato("formatoVod", m.formatoVod)
    end if
    aplicarFormato()
    ponerTeclas()
    if m.formato = "Automático" and m.formatoReal <> invalid
        avisar("Formato: Automático (" + LCase(m.formatoReal) + ")")
    else
        avisar("Formato: " + m.formato)
    end if
end sub

sub avisar(texto as string)
    m.avisoFormato.text = texto
    m.avisoFormato.visible = true
    m.relojFormato.control = "stop"
    m.relojFormato.control = "start"
end sub

sub ocultarFormato()
    m.avisoFormato.visible = false
end sub

function onKeyEvent(tecla as string, presionada as boolean) as boolean
    if not presionada then return false
    if tecla = "back"
        cerrar("regresar")
        return true
    else if tecla = "options"
        cambiarFormato()
        return true
    end if
    if not m.vivo then return teclaDePelicula(tecla)
    if tecla = "up" or tecla = "channelup"
        zapear(1)
        return true
    else if tecla = "down" or tecla = "channeldown"
        zapear(-1)
        return true
    else if tecla = "left" or tecla = "right"
        cambiarFormato()
        return true
    else if tecla = "replay" or tecla = "play"
        resincronizar()
        return true
    else if tecla = "OK"
        if m.capa.visible then ocultarCapa() else mostrarCapa()
        return true
    end if
    return false
end function
