// Lanzador de HerzSA TV (Samsung/Tizen). Solo ES5: lo corren televisores de 2016 en adelante.
//
// Al abrirse:
//   1. Pide <servidor>/version.json ({"version": "1.1.3"}). Prueba HTTPS y luego HTTP (los televisores viejos
//      pueden no aceptar el certificado actual).
//   2. Si el servidor dice otra versión que la que hay aquí, baja <servidor>/<versión>/paquete.json, lo guarda
//      en localStorage y lo ejecuta. Con el servidor las imágenes salen de <servidor>/<versión>/img/.
//   3. Sin servidor ejecuta la última versión guardada o, si no hay, la incluida (paquete-incluido.js), con las
//      imágenes de este paquete (img/).
// Si una versión bajada falla al arrancar, se marca como mala, se borra y se vuelve a abrir con la incluida.
// paquete.json lo arma ../ops/paquete.js con el index.html, el CSS y los JS de la app.
(function () {
    var LANZADOR = '2.0.0';
    // construir.sh cambia esta línea en la compilación de pruebas.
    var SERVIDORES = ['https://control-isp.herdzsa.net/static/downloads/samsung/app/', 'http://control-isp.herdzsa.net/static/downloads/samsung/app/'];
    var CLAVE = 'lanzador.paquete', CLAVE_MALA = 'lanzador.mala';
    var ESPERA_VERSION = 5000, ESPERA_PAQUETE = 30000;
    var incluido = window.PAQUETE_INCLUIDO;

    function leer(clave) { try { return window.localStorage.getItem(clave); } catch (e) { return null; } }
    function guardar(clave, valor) { try { window.localStorage.setItem(clave, valor); return true; } catch (e) { return false; } }
    function borrar(clave) { try { window.localStorage.removeItem(clave); } catch (e) { /* nada */ } }
    function texto(t) { document.getElementById('lanzador-texto').textContent = t; }

    /** -1, 0 o 1 según a sea menor, igual o mayor que b («1.10.0» > «1.9.3»). */
    function comparar(a, b) {
        var x = String(a).split('.'), y = String(b).split('.');
        for (var i = 0; i < Math.max(x.length, y.length); i++) {
            var m = parseInt(x[i] || '0', 10), n = parseInt(y[i] || '0', 10);
            if (m !== n) return m < n ? -1 : 1;
        }
        return 0;
    }

    function esVersion(v) { return typeof v === 'string' && /^\d+(\.\d+){1,3}$/.test(v); }

    function valido(p) {
        if (!p || p.formato !== 1 || !esVersion(p.version) || typeof p.cuerpo !== 'string' || typeof p.css !== 'string') return false;
        if (!p.js || !p.js.length) return false;
        for (var i = 0; i < p.js.length; i++) if (typeof p.js[i].nombre !== 'string' || typeof p.js[i].codigo !== 'string') return false;
        return true;
    }

    /** GET de un JSON con tiempo límite; listo(error, datos). */
    function pedir(url, ms, listo) {
        var x = new XMLHttpRequest(), hecho = false, reloj;
        function fin(error, datos) {
            if (hecho) return;
            hecho = true;
            clearTimeout(reloj);
            listo(error, datos);
        }
        reloj = setTimeout(function () { fin('tiempo agotado'); try { x.abort(); } catch (e) { /* nada */ } }, ms);
        x.onreadystatechange = function () {
            if (x.readyState !== 4) return;
            if (x.status !== 200) return fin('HTTP ' + x.status);
            var d;
            try { d = JSON.parse(x.responseText); } catch (e) { return fin('no es JSON'); }
            fin(null, d);
        };
        try {
            x.open('GET', url, true);
            x.send();
        } catch (e) { fin(String(e)); }
    }

    var guardado = null;
    try { guardado = JSON.parse(leer(CLAVE)); } catch (e) { guardado = null; }
    // Una guardada más vieja que la incluida (se instaló un lanzador nuevo) ya no sirve.
    if (!valido(guardado) || guardado.version === leer(CLAVE_MALA) ||
        (valido(incluido) && comparar(guardado.version, incluido.version) < 0)) guardado = null;

    /** Lo que hay en el televisor: la guardada si existe (puede ser más vieja: el servidor regresó a otra). */
    function local() { return guardado || incluido; }

    function buscar(i) {
        if (i >= SERVIDORES.length) return arrancar(local(), null);
        pedir(SERVIDORES[i] + 'version.json?t=' + new Date().getTime(), ESPERA_VERSION, function (error, info) {
            if (error || !info || !esVersion(info.version)) return buscar(i + 1);
            var base = SERVIDORES[i], actual = local(), v = info.version;
            // La versión del servidor manda (así también se puede regresar a una anterior), salvo que sea más
            // vieja que la incluida, que haya fallado aquí antes o que pida un lanzador más nuevo.
            var usable = v !== leer(CLAVE_MALA) && comparar(v, incluido.version) >= 0 &&
                (!info.lanzador || comparar(LANZADOR, info.lanzador) >= 0);
            if (!usable || v === actual.version) {
                return arrancar(actual, actual === incluido ? null : base + actual.version + '/');
            }
            if (v === incluido.version) return arrancar(incluido, null);
            texto('Actualizando HerzSA TV a la versión ' + v + '…');
            pedir(base + v + '/paquete.json', ESPERA_PAQUETE, function (e2, p) {
                if (e2 || !valido(p) || p.version !== v) return arrancar(actual, actual === incluido ? null : base + actual.version + '/');
                guardar(CLAVE, JSON.stringify(p));   // si no cabe, igual se usa esta vez
                arrancar(p, base + v + '/');
            });
        });
    }

    /** Pone el paquete en la página: imágenes (base), CSS, cuerpo y los JS en orden. */
    function arrancar(p, imagenes) {
        var fallo = null, anterior = window.onerror;
        window.onerror = function (mensaje, archivo, linea) { if (!fallo) fallo = mensaje + ' (' + archivo + ':' + linea + ')'; };
        try {
            var cabeza = document.getElementsByTagName('head')[0];
            if (imagenes) {
                var base = document.createElement('base');
                base.href = imagenes;
                cabeza.appendChild(base);
            }
            var estilo = document.createElement('style');
            estilo.appendChild(document.createTextNode(p.css));
            cabeza.appendChild(estilo);
            var caja = document.createElement('div');
            caja.innerHTML = p.cuerpo;
            while (caja.firstChild) document.body.appendChild(caja.firstChild);
            for (var i = 0; i < p.js.length && !fallo; i++) {
                var s = document.createElement('script');
                s.text = p.js[i].codigo + '\n//# sourceURL=' + p.js[i].nombre;
                document.body.appendChild(s);   // se ejecuta aquí mismo; un error llega a window.onerror
            }
            if (!fallo && !window.HerzsaTV) fallo = 'la app no arrancó';
        } catch (e) {
            fallo = fallo || String(e);
        }
        window.onerror = anterior || null;
        if (fallo) {
            if (window.console) console.log('lanzador: falló la versión ' + p.version + ': ' + fallo);
            if (p !== incluido) {
                guardar(CLAVE_MALA, p.version);
                borrar(CLAVE);
                window.location.reload();
            } else {
                texto('No se pudo abrir HerzSA TV (' + fallo + ').');
            }
            return;
        }
        window.LANZADOR = { version: LANZADOR, app: p.version, imagenes: imagenes || 'incluidas' };
        if (window.console) console.log('lanzador ' + LANZADOR + ': app ' + p.version + ', imágenes ' + window.LANZADOR.imagenes);
        var splash = document.getElementById('lanzador');
        splash.parentNode.removeChild(splash);
    }

    if (!valido(incluido)) return texto('Falta el paquete incluido.');
    buscar(0);
})();
