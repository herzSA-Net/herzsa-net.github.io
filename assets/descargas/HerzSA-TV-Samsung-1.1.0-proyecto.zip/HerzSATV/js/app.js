// HerzSA TV para Samsung: inicio de sesión, secciones, categorías, Mi cuenta, Adultos con PIN y series.
// Equivale a MainScene.brs (Roku). La navegación es por zonas, como en un televisor: las flechas
// mueven el foco al elemento más cercano en esa dirección (Foco, abajo) y OK lo abre.
'use strict';

var HerzsaTV = (function () {
    var VERSION = '1.1.0';
    var $ = function (id) { return document.getElementById(id); };
    var SECCIONES = [
        { nombre: 'Inicio', icono: 'i_inicio' }, { nombre: 'TV en vivo', icono: 'i_vivo' },
        { nombre: 'Películas', icono: 'i_peliculas' }, { nombre: 'Series', icono: 'i_capas' },
        { nombre: 'Favoritos', icono: 'i_favoritos' }, { nombre: 'Buscar', icono: 'i_buscar' },
        { nombre: 'Adultos', icono: 'i_adultos' }, { nombre: 'Mi cuenta', icono: 'i_cuenta' }
    ];
    // Desde 1.0.2 (igual que Roku): Buscar y Adultos no se muestran. El código sigue; para volver a
    // mostrarlas basta con quitarlas de OCULTAS (y mostrar el botón «Cambiar PIN de Adultos» en Mi cuenta).
    var OCULTAS = ['Buscar', 'Adultos'];
    var TANDA = 120;

    var S = {
        vista: 'login', api: null, sesion: null, usuario: '', clave: '', servidor: CONFIG.servidor,
        seccion: -1, adultos: false, cats: [], catElegida: -1, carga: 0, lista: [], dibujados: 0, columnas: 1,
        serie: null, vistaAntes: 'principal'
    };
    var relojSeccion, relojCategoria, relojAviso, relojOk, ceros = 0;

    // =====================================================================================
    // Escala: el escenario mide 1920x1080 y se ajusta a la pantalla real.
    // =====================================================================================
    function escalar() {
        var e = Math.min(window.innerWidth / 1920, window.innerHeight / 1080) || 1;
        var t = 'scale(' + e + ')';
        $('escenario').style.transform = t;
        $('escenario').style.webkitTransform = t;
    }

    // =====================================================================================
    // Foco
    // =====================================================================================
    var Foco = (function () {
        var actual = null, memoria = {};

        function capa() {
            if (!$('dialogo').hidden) return $('dialogo');
            if (S.vista === 'serie') return $('serie');
            if (S.vista === 'principal') return $('principal');
            return $('login');
        }

        function visible(el) {
            return el.offsetParent !== null && !el.hidden;
        }

        function grupo(el) {
            while (el && el !== document.body) {
                if (el.getAttribute && el.getAttribute('data-grupo')) return el;
                el = el.parentNode;
            }
            return null;
        }

        function poner(el) {
            if (!el) return;
            var gAntes = actual ? grupo(actual) : null, g = grupo(el);
            if (actual) actual.classList.remove('foco');
            if (gAntes && gAntes !== g) gAntes.classList.remove('con-foco');
            actual = el;
            el.classList.add('foco');
            if (g) {
                g.classList.add('con-foco');
                memoria[g.getAttribute('data-grupo')] = el;
            }
            asegurarVisible(el);
            if (el.alEnfocar) el.alEnfocar();
        }

        /** Mueve el foco al elemento más cercano en esa dirección dentro de la capa visible
         *  (o dentro de «dentro», si se da). */
        function mover(dir, dentro) {
            if (!actual || !visible(actual)) return primero();
            var a = actual.getBoundingClientRect();
            var ax = a.left + a.width / 2, ay = a.top + a.height / 2;
            var todos = (dentro || capa()).querySelectorAll('.f'), mejor = null, puntaje = Infinity;
            for (var i = 0; i < todos.length; i++) {
                var el = todos[i];
                if (el === actual || !visible(el)) continue;
                var b = el.getBoundingClientRect();
                var bx = b.left + b.width / 2, by = b.top + b.height / 2;
                var dx = bx - ax, dy = by - ay, principal, lateral;
                if (dir === 'derecha') { if (b.left < a.right - 4 && dx <= 4) continue; principal = dx; lateral = Math.abs(dy); }
                else if (dir === 'izquierda') { if (b.right > a.left + 4 && dx >= -4) continue; principal = -dx; lateral = Math.abs(dy); }
                else if (dir === 'abajo') { if (b.top < a.bottom - 4 && dy <= 4) continue; principal = dy; lateral = Math.abs(dx); }
                else { if (b.bottom > a.top + 4 && dy >= -4) continue; principal = -dy; lateral = Math.abs(dx); }
                if (principal <= 0) continue;
                var p = principal + lateral * 3;
                if (p < puntaje) { puntaje = p; mejor = el; }
            }
            if (!mejor) return false;
            // Al entrar a otra zona se vuelve a lo último que tuvo el foco en ella.
            var g = grupo(mejor);
            if (g && g !== grupo(actual)) {
                var antes = memoria[g.getAttribute('data-grupo')];
                if (antes && visible(antes) && g.contains(antes)) mejor = antes;
            }
            poner(mejor);
            return true;
        }

        function primero(dentro) {
            var todos = (dentro || capa()).querySelectorAll('.f');
            for (var i = 0; i < todos.length; i++) if (visible(todos[i])) { poner(todos[i]); return true; }
            return false;
        }

        /** Enfoca la zona (lo último que tuvo el foco en ella, o lo primero). */
        function zona(nombre) {
            var antes = memoria[nombre];
            if (antes && visible(antes)) return poner(antes);
            var g = document.querySelector('[data-grupo="' + nombre + '"]');
            if (g) primero(g);
        }

        function olvidar(nombre) { delete memoria[nombre]; }

        return { poner: poner, mover: mover, primero: primero, zona: zona, olvidar: olvidar, grupo: grupo,
            actual: function () { return actual; } };
    })();

    /** Desplaza listas y tiras para que el elemento con el foco se vea completo. */
    function asegurarVisible(el) {
        var p = el.parentNode;
        if (p.id === 'tira') {
            var izq = -parseInt(p.style.left || '0', 10), ancho = 876;
            if (el.offsetLeft < izq) izq = el.offsetLeft;
            else if (el.offsetLeft + el.offsetWidth > izq + ancho) izq = el.offsetLeft + el.offsetWidth - ancho;
            p.style.left = -izq + 'px';
        } else if (p.className === 'carril') {
            var x = -parseInt(p.style.left || '0', 10);
            if (el.offsetLeft < x) x = el.offsetLeft;
            else if (el.offsetLeft + el.offsetWidth > x + 1476) x = el.offsetLeft + el.offsetWidth - 1476;
            p.style.left = -x + 'px';
        } else if (p.id === 'rejilla' || p.id === 'temporadas' || p.id === 'episodios') {
            var caja = p.id === 'rejilla' ? $('contenido') : p;
            var alto = caja.clientHeight - (p.id === 'rejilla' ? 30 : 0);
            var arriba = p.id === 'rejilla' ? -parseInt(p.style.top || '16', 10) + 16 : caja.scrollTop;
            var y = el.offsetTop, h = el.offsetHeight;
            if (y < arriba) arriba = y;
            else if (y + h > arriba + alto) arriba = y + h - alto;
            if (p.id === 'rejilla') p.style.top = (16 - arriba) + 'px'; else caja.scrollTop = arriba;
            if (p.id === 'rejilla') dibujarMas(el);
        }
    }

    // =====================================================================================
    // Teclas del control remoto
    // =====================================================================================
    var CODIGOS = {
        37: 'izquierda', 38: 'arriba', 39: 'derecha', 40: 'abajo', 13: 'ok', 10009: 'atras', 27: 'atras',
        415: 'play', 19: 'pausa', 10252: 'playpausa', 417: 'adelantar', 412: 'retroceder', 413: 'stop',
        427: 'ch+', 428: 'ch-', 403: 'rojo', 404: 'verde', 405: 'amarillo', 406: 'azul', 457: 'info', 10135: 'herramientas',
        65376: 'listo', 65385: 'cancelar'
    };

    // Las teclas que no son flechas, OK y Atrás hay que pedirlas al televisor. Una por una: si un
    // modelo no tiene alguna (Tools, colores), las demás sí quedan registradas.
    function registrarTeclas() {
        if (!window.tizen || !tizen.tvinputdevice) return;
        ['MediaPlay', 'MediaPause', 'MediaPlayPause', 'MediaFastForward', 'MediaRewind', 'MediaStop', 'ChannelUp', 'ChannelDown',
            'ColorF0Red', 'ColorF1Green', 'ColorF2Yellow', 'ColorF3Blue', 'Info', 'Tools', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            .forEach(function (k) { try { tizen.tvinputdevice.registerKey(k); } catch (e) { /* este modelo no la tiene */ } });
    }

    function alPresionar(ev) {
        var entrada = $('dialogo-entrada');
        var editando = document.activeElement === entrada;
        var k = ev.keyCode;
        if (editando) {
            // Mientras se escribe, el teclado del televisor maneja las teclas; Listo o Enter terminan.
            if (k === 13 || k === 65376 || k === 65385 || k === 10009) {
                ev.preventDefault();
                terminarDeEscribir(k !== 65385 && k !== 10009);
            }
            return;
        }
        if (k >= 48 && k <= 57) { ev.preventDefault(); return tecla(String(k - 48)); }
        if (k >= 96 && k <= 105) { ev.preventDefault(); return tecla(String(k - 96)); }
        if (k === 8) { ev.preventDefault(); return tecla('atras'); }
        var t = CODIGOS[k];
        if (!t) return;
        ev.preventDefault();
        if (t === 'ok') {
            // OK sostenido = menú de opciones (agregar o quitar de favoritos; en el video, el menú
            // «Reproductor de Video»).
            if (ev.repeat || relojOk === 'largo') return;
            if (relojOk) return;
            relojOk = setTimeout(function () { relojOk = 'largo'; tecla('ok-largo'); }, 700);
            return;
        }
        tecla(t);
    }

    function alSoltar(ev) {
        if (ev.keyCode !== 13) return;
        if (relojOk && relojOk !== 'largo') { clearTimeout(relojOk); relojOk = null; tecla('ok'); }
        else relojOk = null;
    }

    /** Una tecla ya traducida ('ok', 'atras', 'arriba'…). El simulador de pruebas llama aquí. */
    function tecla(t) {
        if (Reproductor.abierto()) return Reproductor.tecla(t);
        if (!$('dialogo').hidden) return teclaDialogo(t);
        if (t === 'izquierda' || t === 'derecha' || t === 'arriba' || t === 'abajo') return moverFoco(t);
        var el = Foco.actual();
        if (t === 'ok') { if (el && el.alOk) el.alOk(); return; }
        if (t === 'ok-largo' || t === 'rojo' || t === 'herramientas' || t === 'info') {
            if (el && el.elemento) return menuDeOpciones(el);
            if (t === 'ok-largo' && el && el.alOk) el.alOk();
            return;
        }
        if (t === 'atras') return atras();
        if (S.vista === 'login' && (t === '0' || t === 'azul')) {
            // Cinco veces 0 (o el botón azul) en el inicio de sesión: cambiar de servidor.
            ceros = t === 'azul' ? 5 : ceros + 1;
            if (ceros >= 5) { ceros = 0; pedirServidor(); }
        }
    }

    function moverFoco(dir) {
        var el = Foco.actual(), g = el && Foco.grupo(el), nombre = g && g.getAttribute('data-grupo');
        // A la derecha de una sección que no es la elegida: se elige (Buscar y Adultos abren su diálogo).
        if (dir === 'derecha' && nombre === 'secciones' && Number(el.getAttribute('data-i')) !== S.seccion) {
            clearTimeout(relojSeccion);
            return alElegirSeccion(Number(el.getAttribute('data-i')), true);
        }
        if (nombre === 'secciones' && dir === 'derecha') {
            if (hayContenido()) return Foco.zona('contenido');
            if (!$('categorias').hidden) return Foco.zona('categorias');
            return;
        }
        if (nombre === 'categorias' && dir === 'abajo') return hayContenido() ? Foco.zona('contenido') : null;
        if (nombre === 'categorias' && dir === 'izquierda' && el === el.parentNode.firstChild) return Foco.zona('secciones');
        if (nombre === 'contenido' && dir === 'izquierda' && !Foco.mover('izquierda')) return Foco.zona('secciones');
        if (nombre === 'contenido' && dir === 'izquierda') return;
        if (nombre === 'contenido' && dir === 'arriba' && !Foco.mover('arriba', g)) {
            if (!$('categorias').hidden) Foco.zona('categorias');
            return;
        }
        if (nombre === 'contenido' && dir === 'arriba') return;
        // Arriba y abajo no sacan el foco de su zona (secciones, contenido, temporadas, episodios).
        Foco.mover(dir, g && (dir === 'arriba' || dir === 'abajo') ? g : null);
    }

    function atras() {
        if (S.vista === 'serie') return cerrarSerie();
        if (S.vista === 'login') return preguntarSalida();
        var g = Foco.actual() && Foco.grupo(Foco.actual());
        if (!g || g.getAttribute('data-grupo') === 'secciones') return preguntarSalida();
        Foco.zona('secciones');
    }

    function preguntarSalida() {
        preguntar('HerzSA TV', '¿Quieres salir de la app?', ['Salir', 'Cancelar'], function (b) {
            if (b !== 0) return;
            try { tizen.application.getCurrentApplication().exit(); } catch (e) { window.close(); }
        });
    }

    // =====================================================================================
    // Diálogos: preguntas, texto (con el teclado del televisor) y PIN (con los números del control)
    // =====================================================================================
    var D = null;

    /** op: { titulo, texto, botones, campo: { valor, secreto, pin }, alElegir(boton, texto) } */
    function dialogo(op) {
        D = op;
        D.focoAntes = Foco.actual();
        $('dialogo-titulo').textContent = op.titulo;
        $('dialogo-texto').textContent = op.texto || '';
        $('dialogo-texto').hidden = !op.texto;
        var campo = $('dialogo-campo'), entrada = $('dialogo-entrada');
        campo.hidden = !op.campo;
        $('dialogo-pista').hidden = !op.campo;
        if (op.campo) {
            entrada.type = op.campo.secreto || op.campo.pin ? 'password' : 'text';
            entrada.value = op.campo.valor || '';
            entrada.maxLength = op.campo.pin ? 8 : 200;
            $('dialogo-pista').textContent = op.campo.pin
                ? 'Escribe el PIN con los números del control. Izquierda borra el último número.'
                : 'Pulsa OK para escribir con el teclado del televisor.';
            campo.alOk = function () {
                if (op.campo.pin) return elegir(0);
                entrada.focus();
            };
        }
        var botones = $('dialogo-botones');
        botones.innerHTML = '';
        op.botones.forEach(function (texto, i) {
            var b = document.createElement('div');
            b.className = 'boton f';
            b.textContent = texto;
            b.alOk = function () { elegir(i); };
            botones.appendChild(b);
        });
        $('dialogo').hidden = false;
        Foco.poner(op.campo ? campo : botones.firstChild);
    }

    function teclaDialogo(t) {
        var entrada = $('dialogo-entrada');
        var enCampo = D.campo && Foco.actual() === $('dialogo-campo');
        if (enCampo && D.campo.pin && /^[0-9]$/.test(t)) {
            if (entrada.value.length < 8) entrada.value += t;
            return;
        }
        if (enCampo && D.campo.pin && t === 'izquierda') {
            entrada.value = entrada.value.slice(0, -1);
            return;
        }
        if (t === 'atras') return cerrarDialogo();
        if (t === 'ok' || t === 'ok-largo') { var el = Foco.actual(); if (el && el.alOk) el.alOk(); return; }
        if (t === 'arriba' || t === 'abajo' || t === 'izquierda' || t === 'derecha') Foco.mover(t);
    }

    function terminarDeEscribir(aceptar) {
        var entrada = $('dialogo-entrada');
        entrada.blur();
        if (D) Foco.poner(aceptar ? $('dialogo-botones').firstChild : $('dialogo-campo'));
    }

    function elegir(i) {
        var op = D, valor = $('dialogo-entrada').value;
        cerrarDialogo();
        if (op.alElegir) op.alElegir(i, valor);
    }

    function cerrarDialogo() {
        var op = D;
        $('dialogo-entrada').blur();
        $('dialogo').hidden = true;
        D = null;
        if (op && op.focoAntes && op.focoAntes.offsetParent !== null) Foco.poner(op.focoAntes);
        else restaurarFoco();
    }

    function preguntar(titulo, texto, botones, alElegir) {
        dialogo({ titulo: titulo, texto: texto, botones: botones, alElegir: alElegir });
    }

    function pedirTexto(titulo, texto, inicial, secreto, alElegir) {
        dialogo({ titulo: titulo, texto: texto, botones: ['Aceptar', 'Cancelar'], campo: { valor: inicial, secreto: secreto }, alElegir: alElegir });
    }

    function pedirPin(titulo, texto, botones, alElegir) {
        dialogo({ titulo: titulo, texto: texto, botones: botones, campo: { pin: true }, alElegir: alElegir });
    }

    function aviso(texto) {
        $('aviso').textContent = texto;
        $('aviso').hidden = false;
        clearTimeout(relojAviso);
        relojAviso = setTimeout(function () { $('aviso').hidden = true; }, 2400);
    }

    function restaurarFoco() {
        if (!$('dialogo').hidden || Reproductor.abierto()) return;
        if (S.vista === 'login') return Foco.zona('login') || Foco.primero();
        if (S.vista === 'serie') return Foco.zona('episodios');
        Foco.zona('secciones');
    }

    // =====================================================================================
    // Inicio de sesión
    // =====================================================================================
    function mostrarLogin(error) {
        S.vista = 'login';
        $('principal').hidden = true;
        $('serie').hidden = true;
        $('linea').hidden = true;
        $('login').hidden = false;
        $('error-login').textContent = error || '';
        pintarLogin();
        Foco.primero($('botones-login'));
    }

    function pintarLogin() {
        $('ver-usuario').textContent = S.usuario || '(escribe tu usuario)';
        $('ver-clave').textContent = S.clave ? new Array(S.clave.length + 1).join('•') : '(escribe tu contraseña)';
        $('boton-servidor').hidden = S.servidor === CONFIG.servidor;
        $('ver-servidor').textContent = S.servidor;
    }

    function prepararLogin() {
        var b = $('botones-login').children;
        b[0].alOk = function () {
            pedirTexto('Usuario', 'El usuario de tu cuenta de televisión.', S.usuario, false, function (boton, texto) {
                if (boton !== 0) return;
                S.usuario = Comun.texto(texto);
                pintarLogin();
                Foco.poner(b[1]);
            });
        };
        b[1].alOk = function () {
            pedirTexto('Contraseña', 'La contraseña de tu cuenta de televisión.', S.clave, true, function (boton, texto) {
                if (boton !== 0) return;
                S.clave = texto;
                pintarLogin();
                Foco.poner(b[2]);
            });
        };
        b[2].alOk = function () {
            if (!S.usuario || !S.clave) { $('error-login').textContent = 'Escribe tu usuario y tu contraseña'; return; }
            $('error-login').textContent = 'Entrando…';
            entrar();
        };
        b[3].alOk = pedirServidor;
    }

    function pedirServidor() {
        pedirTexto('Servidor', 'Dirección del servidor (solo si te la dio HerzSA.Net).', S.servidor, false, function (boton, texto) {
            if (boton !== 0) return;
            S.servidor = Comun.texto(texto) || CONFIG.servidor;
            pintarLogin();
        });
    }

    function entrar() {
        var api = new Xtream(S.servidor, S.usuario, S.clave);
        api.entrar().then(function () {
            S.api = api;
            S.sesion = { usuario: S.usuario, clave: S.clave, servidor: S.servidor };
            Comun.guardar('sesion', S.sesion);
            mostrarPrincipal();
        }, function (e) {
            if (S.vista === 'login') mostrarLogin(e.message);
            else cerrarSesion(e.message);
        });
    }

    function cerrarSesion(error) {
        if (Reproductor.abierto()) Reproductor.cerrar();
        if (S.serie) cerrarSerie(true);
        Comun.borrar('sesion');
        S.sesion = null;
        S.api = null;
        S.clave = '';
        S.seccion = -1;
        mostrarLogin(error);
    }

    // =====================================================================================
    // Principal
    // =====================================================================================
    function prepararSecciones() {
        var caja = $('secciones');
        SECCIONES.forEach(function (s, i) {
            var d = document.createElement('div');
            d.className = 'seccion f';
            d.setAttribute('data-i', i);
            d.innerHTML = '<img src="img/' + s.icono + '.png" alt="">' + s.nombre;
            if (OCULTAS.indexOf(s.nombre) >= 0) d.hidden = true;
            d.alOk = function () {
                clearTimeout(relojSeccion);
                if (i === S.seccion && hayContenido()) Foco.zona('contenido'); else alElegirSeccion(i, true);
            };
            // Al recorrer el panel se abre la sección en la que se detiene el foco (menos Buscar y Adultos).
            d.alEnfocar = function () {
                clearTimeout(relojSeccion);
                if (i !== S.seccion && s.nombre !== 'Buscar' && s.nombre !== 'Adultos') relojSeccion = setTimeout(function () { alElegirSeccion(i); }, 600);
            };
            caja.appendChild(d);
        });
        var b = $('botones-cuenta').children;
        b[0].alOk = function () {
            $('datos-cuenta').textContent = 'Consultando…';
            S.api.entrar().then(mostrarCuenta, function (e) { if (e.cuenta) cerrarSesion(e.message); else $('datos-cuenta').textContent = e.message; });
        };
        b[1].alOk = cambiarPin;
        if (OCULTAS.indexOf('Adultos') >= 0) b[1].hidden = true;
        b[2].alOk = function () {
            preguntar('Cerrar sesión', 'Se borrarán tu usuario y contraseña de este televisor.', ['Cerrar sesión', 'Cancelar'], function (k) {
                if (k === 0) cerrarSesion('');
            });
        };
    }

    function mostrarPrincipal() {
        S.vista = 'principal';
        $('login').hidden = true;
        $('principal').hidden = false;
        $('linea').hidden = false;
        ponerHora();
        Foco.olvidar('secciones');
        Foco.poner($('secciones').children[0]);
        elegirSeccion(0);
    }

    function ponerHora() {
        $('reloj').textContent = Comun.fechaCorta(new Date());
        var r = Comun.red();
        $('icono-red').hidden = !r.wifi;
        $('red').className = r.wifi ? 'wifi' : '';
        $('texto-red').textContent = r.texto;
    }

    function marcarSeccion() {
        var hijos = $('secciones').children;
        for (var i = 0; i < hijos.length; i++) hijos[i].classList.toggle('activa', i === S.seccion);
    }

    function alElegirSeccion(i, conOk) {
        var nombre = SECCIONES[i].nombre;
        if (nombre === 'Buscar') return pedirTexto('Buscar', 'Canales, películas o series.', '', false, alEscribirBusqueda);
        if (nombre === 'Adultos') return abrirAdultos();
        if (i !== S.seccion || conOk) elegirSeccion(i);
        if (conOk && nombre === 'Mi cuenta') Foco.zona('contenido');
        else if (conOk) S.irAlContenido = true;
    }

    function ocultarContenido(estado) {
        S.carga++;
        $('rejilla').innerHTML = '';
        $('rejilla').style.top = '16px';
        $('filas').hidden = true;
        $('filas').innerHTML = '';
        $('cuenta').hidden = true;
        $('estado').textContent = estado;
        $('ayuda').hidden = false;
        S.lista = [];
        S.dibujados = 0;
        Foco.olvidar('contenido');
    }

    function elegirSeccion(i) {
        S.seccion = i;
        marcarSeccion();
        S.adultos = false;
        $('categorias').hidden = true;
        S.cats = [];
        var nombre = SECCIONES[i].nombre;
        if (nombre === 'Inicio') {
            ocultarContenido('Cargando…');
            var n = S.carga;
            S.api.inicio().then(function (filas) { if (n === S.carga) mostrarFilas(filas); }, falloDe(n));
        } else if (nombre === 'TV en vivo') cargarCategorias('live');
        else if (nombre === 'Películas') cargarCategorias('vod');
        else if (nombre === 'Series') cargarCategorias('series');
        else if (nombre === 'Favoritos') {
            ocultarContenido('Cargando…');
            var m = S.carga;
            S.api.favoritos(Comun.leer('favoritos', [])).then(function (l) { if (m === S.carga) mostrarLista(l); }, falloDe(m));
        } else if (nombre === 'Mi cuenta') mostrarCuenta();
    }

    function hayContenido() {
        return $('rejilla').children.length > 0 || !$('filas').hidden || !$('cuenta').hidden;
    }

    /** Muestra el error de una carga; si la cuenta venció o se suspendió, regresa al inicio de sesión. */
    function falloDe(n) {
        return function (e) {
            if (n !== S.carga) return;
            if (e && e.cuenta) return cerrarSesion(e.message);
            $('estado').textContent = (e && e.message) || 'No se pudo cargar';
        };
    }

    function alEscribirBusqueda(boton, texto) {
        texto = Comun.texto(texto);
        if (boton !== 0 || !texto) return;
        S.seccion = 5;
        marcarSeccion();
        S.adultos = false;
        $('categorias').hidden = true;
        ocultarContenido('Buscando «' + texto + '»…');
        S.buscado = texto;
        S.irAlContenido = true;
        var n = S.carga;
        S.api.buscar(texto).then(function (l) { if (n === S.carga) mostrarLista(l); }, falloDe(n));
    }

    // ---------- Categorías ----------
    var ICONOS = [['estreno', 'c_estrenos'], ['nuev', 'c_estrenos'], ['2026', 'c_estrenos'], ['kid', 'c_kids'], ['infan', 'c_kids'],
        ['nino', 'c_kids'], ['anima', 'c_kids'], ['famil', 'c_kids'], ['marvel', 'c_marvel'], ['heroe', 'c_marvel'],
        ['pelicul', 'c_peliculas'], ['cine', 'c_peliculas']];

    function iconoDeCategoria(nombre) {
        var n = Comun.plano(nombre);
        for (var i = 0; i < ICONOS.length; i++) if (n.indexOf(ICONOS[i][0]) >= 0) return 'img/' + ICONOS[i][1] + '.png';
        return '';
    }

    function cargarCategorias(tipo) {
        S.tipo = tipo;
        ocultarContenido('Cargando…');
        var n = S.carga;
        var tipos = S.adultos ? ['live', 'vod', 'series'] : [tipo];
        S.api.listaDeCategorias(tipos, S.adultos).then(function (lista) {
            if (n !== S.carga) return;
            S.cats = S.adultos
                ? [{ id: '', nombre: 'Canales: todo', tipo: 'live' }, { id: '', nombre: 'Películas: todo', tipo: 'vod' }, { id: '', nombre: 'Series: todo', tipo: 'series' }]
                : [{ id: '', nombre: 'Todo', tipo: tipo }];
            S.cats = S.cats.concat(lista);
            var tira = $('tira');
            tira.innerHTML = '';
            tira.style.left = '0';
            S.cats.forEach(function (c, k) {
                var d = document.createElement('div'), icono = iconoDeCategoria(c.nombre);
                d.className = 'chip f' + (icono ? ' con-icono' : '');
                d.innerHTML = icono ? '<img src="' + icono + '" alt="">' : '';
                d.appendChild(document.createTextNode(c.nombre));
                // Al recorrer la tira se carga la categoría en la que se detiene el foco.
                d.alEnfocar = function () {
                    clearTimeout(relojCategoria);
                    if (k !== S.catElegida) relojCategoria = setTimeout(function () { cargarCategoria(k); }, 500);
                };
                d.alOk = function () {
                    clearTimeout(relojCategoria);
                    S.irAlContenido = true;
                    if (k !== S.catElegida) cargarCategoria(k);
                    else if (hayContenido()) Foco.zona('contenido');
                };
                tira.appendChild(d);
            });
            $('categorias').hidden = false;
            Foco.olvidar('categorias');
            S.catElegida = -1;
            cargarCategoria(0);
        }, falloDe(n));
    }

    function cargarCategoria(k) {
        if (k < 0 || k >= S.cats.length) return;
        var chips = $('tira').children;
        for (var i = 0; i < chips.length; i++) chips[i].classList.toggle('activa', i === k);
        S.catElegida = k;
        var c = S.cats[k];
        ocultarContenido('Cargando…');
        var n = S.carga;
        S.api.filtrar(c.tipo, c.id, S.adultos).then(function (l) { if (n === S.carga) mostrarLista(l); }, falloDe(n));
    }

    // ---------- Listas ----------
    function mostrarLista(lista) {
        var nombre = SECCIONES[S.seccion] ? SECCIONES[S.seccion].nombre : '';
        if (!lista.length) {
            if (nombre === 'Favoritos') $('estado').textContent = 'Aún no tienes favoritos. En cualquier canal, película o serie mantén pulsado OK para agregarlo.';
            else if (nombre === 'Buscar') $('estado').textContent = 'No se encontró «' + S.buscado + '».';
            else $('estado').textContent = 'No hay nada en esta categoría.';
            S.irAlContenido = false;
            return;
        }
        $('estado').textContent = '';
        S.lista = lista;
        // Los canales van en lista con logo; lo demás (y lo mezclado de favoritos o búsqueda) en carátulas.
        S.soloCanales = lista.every(function (e) { return e.tipo === 'live'; });
        S.columnas = S.soloCanales ? 3 : 6;
        S.dibujados = 0;
        dibujarTanda();
        var foco = Foco.actual(), g = foco && Foco.grupo(foco);
        if (S.irAlContenido || (g && g.getAttribute('data-grupo') === 'contenido')) Foco.primero($('rejilla'));
        S.irAlContenido = false;
    }

    /** Las listas largas se dibujan por tandas conforme el foco baja. */
    function dibujarTanda() {
        var rejilla = $('rejilla'), hasta = Math.min(S.lista.length, S.dibujados + TANDA);
        var favs = Comun.leer('favoritos', []);
        for (var i = S.dibujados; i < hasta; i++) rejilla.appendChild(tarjeta(S.lista, i, favs, S.soloCanales));
        S.dibujados = hasta;
    }

    function dibujarMas(el) {
        var i = Number(el.getAttribute('data-i'));
        if (i >= S.dibujados - S.columnas * 3 && S.dibujados < S.lista.length) dibujarTanda();
    }

    function tarjeta(lista, i, favs, comoCanal) {
        var e = lista[i], d = document.createElement('div'), fav = favs.indexOf(e.tipo + ':' + e.id) >= 0;
        d.setAttribute('data-i', i);
        d.elemento = e;
        d.alOk = function () { abrir(lista, i); };
        if (comoCanal) {
            d.className = 'canal f' + (e.icono ? '' : ' sin-logo');
            d.innerHTML = (e.icono ? '<img class="logo" alt="">' : '') + '<b></b>' + (fav ? '<i class="estrella"></i>' : '');
        } else {
            d.className = 'cartel f' + (e.tipo === 'live' ? ' vivo' : '');
            d.innerHTML = '<div class="caja"><div class="sin-imagen"></div>' + (e.icono ? '<img class="imagen" alt="">' : '') +
                '</div><div class="marco"></div>' + (fav ? '<i class="estrella"></i>' : '') + '<p></p>';
            d.querySelector('.sin-imagen').textContent = e.nombre;
            d.querySelector('p').textContent = e.nombre;
        }
        if (comoCanal) d.querySelector('b').textContent = e.nombre;
        var img = d.querySelector('img');
        if (img) {
            img.onerror = function () { img.parentNode.removeChild(img); if (comoCanal) d.classList.add('sin-logo'); };
            img.src = e.icono;
        }
        return d;
    }

    function mostrarFilas(filas) {
        var caja = $('filas'), favs = Comun.leer('favoritos', []), alguna = false;
        caja.innerHTML = '';
        filas.forEach(function (f) {
            if (!f.lista.length) return;
            alguna = true;
            var fila = document.createElement('div'), carril = document.createElement('div');
            fila.className = 'fila';
            fila.innerHTML = '<h3></h3>';
            fila.firstChild.textContent = f.titulo;
            carril.className = 'carril';
            f.lista.forEach(function (e, i) { carril.appendChild(tarjeta(f.lista, i, favs, false)); });
            fila.appendChild(carril);
            caja.appendChild(fila);
        });
        caja.hidden = !alguna;
        $('estado').textContent = alguna ? '' : 'Todavía no hay películas en el servidor.';
        if (S.irAlContenido && alguna) Foco.primero(caja);
        S.irAlContenido = false;
    }

    function abrir(lista, i) {
        if (lista[i].tipo === 'series') abrirSerie(lista[i]);
        else reproducir(lista, i);
    }

    // ---------- Favoritos (OK sostenido) ----------
    function menuDeOpciones(el) {
        var e = el.elemento, k = e.tipo + ':' + e.id;
        var es = Comun.leer('favoritos', []).indexOf(k) >= 0;
        preguntar(e.nombre, 'Menú de opciones', [es ? 'Quitar de favoritos' : 'Agregar a favoritos', 'Cancelar'], function (b) {
            if (b === 0) alternarFavorito(e);
        });
    }

    function alternarFavorito(e) {
        // Lo de Adultos no se mezcla con los favoritos, que no piden PIN.
        if (S.adultos || e.adulto) return aviso('Lo de Adultos no se puede agregar a favoritos');
        var favs = Comun.leer('favoritos', []), k = e.tipo + ':' + e.id, i = favs.indexOf(k);
        if (i >= 0) { favs.splice(i, 1); aviso('Quitado de favoritos'); } else { favs.push(k); aviso('Agregado a favoritos'); }
        Comun.guardar('favoritos', favs);
        // La misma película puede estar en las dos filas de Inicio.
        var tarjetas = document.querySelectorAll('#contenido .f');
        for (var j = 0; j < tarjetas.length; j++) {
            var t = tarjetas[j], o = t.elemento;
            if (!o || o.tipo + ':' + o.id !== k) continue;
            var estrella = t.querySelector('.estrella');
            if (i >= 0 && estrella) estrella.parentNode.removeChild(estrella);
            if (i < 0 && !estrella) {
                estrella = document.createElement('i');
                estrella.className = 'estrella';
                t.insertBefore(estrella, t.querySelector('p'));
            }
        }
    }

    // ---------- Mi cuenta ----------
    function mostrarCuenta() {
        if (SECCIONES[S.seccion].nombre !== 'Mi cuenta') return;
        ocultarContenido('');
        $('ayuda').hidden = true;
        var a = S.api, estado = a.estado && !/^active$/i.test(a.estado) ? a.estado : 'Activa';
        var lineas = ['Usuario:   ' + S.sesion.usuario, 'Estado:   ' + estado, 'Vence:   ' + a.vence,
            'Conexiones en uso:   ' + a.conexiones, 'Versión de la app:   ' + VERSION];
        if (S.sesion.servidor !== CONFIG.servidor) lineas.push('Servidor:   ' + S.sesion.servidor);
        $('datos-cuenta').textContent = lineas.join('\n');
        $('cuenta').hidden = false;
    }

    // ---------- Adultos: se entra con un PIN que crea el propio usuario ----------
    function abrirAdultos() {
        if (!Comun.leer('pin', null)) return crearPin();
        pedirPin('Contenido para adultos', 'Escribe tu PIN para entrar.', ['Entrar', 'Cambiar PIN', 'Cancelar'], function (b, pin) {
            if (b === 1) return cambiarPin();
            if (b !== 0) return;
            if (Comun.huella(pin) === Comun.leer('pin', '')) entrarAAdultos();
            else aviso('PIN incorrecto');
        });
    }

    function entrarAAdultos() {
        S.seccion = 6;
        marcarSeccion();
        S.adultos = true;
        $('categorias').hidden = true;
        cargarCategorias('live');
    }

    function crearPin() {
        pedirPin('Crea tu PIN', 'La sección Adultos se abre con un PIN que solo tú conoces. Elige de 4 a 8 números.', ['Aceptar', 'Cancelar'], function (b, pin) {
            if (b !== 0) return;
            if (pin.length < 4 || pin.length > 8) return aviso('El PIN debe tener de 4 a 8 números');
            pedirPin('Repite el PIN', 'Escribe otra vez el mismo PIN.', ['Aceptar', 'Cancelar'], function (b2, otra) {
                if (b2 !== 0) return;
                if (otra !== pin) return aviso('Los dos PIN no coinciden');
                Comun.guardar('pin', Comun.huella(pin));
                aviso('PIN guardado');
                entrarAAdultos();
            });
        });
    }

    // Cambiar u olvidar el PIN: se comprueba con la contraseña de la cuenta de televisión.
    function cambiarPin() {
        pedirTexto('Cambiar PIN', 'Escribe la contraseña de tu cuenta de televisión (usuario ' + S.sesion.usuario + ').', '', true, function (b, clave) {
            if (b !== 0) return;
            if (clave !== S.sesion.clave) return aviso('Contraseña incorrecta');
            Comun.borrar('pin');
            crearPin();
        });
    }

    // =====================================================================================
    // Serie
    // =====================================================================================
    function abrirSerie(e) {
        S.vista = 'serie';
        S.serie = { e: e, temporadas: [] };
        $('principal').hidden = true;
        $('linea').hidden = true;
        $('serie').hidden = false;
        $('velo').hidden = false;
        $('serie-titulo').textContent = e.nombre;
        $('serie-sinopsis').textContent = '';
        ponerPortada(e.icono);
        $('temporadas').innerHTML = '';
        $('episodios').innerHTML = '';
        $('serie-estado').textContent = 'Cargando…';
        Foco.olvidar('temporadas');
        Foco.olvidar('episodios');
        var serie = S.serie;
        S.api.serie(e.id).then(function (d) {
            if (S.serie !== serie) return;
            serie.temporadas = d.temporadas;
            if (d.titulo) $('serie-titulo').textContent = d.titulo;
            $('serie-sinopsis').textContent = d.sinopsis;
            if (d.portada) ponerPortada(d.portada);
            if (!d.temporadas.length) { $('serie-estado').textContent = 'Esta serie todavía no tiene episodios.'; return; }
            $('serie-estado').textContent = '';
            d.temporadas.forEach(function (t, k) {
                var el = document.createElement('div');
                el.className = 'temporada f';
                el.textContent = t.nombre;
                el.alEnfocar = function () { mostrarEpisodios(k); };
                el.alOk = function () { Foco.zona('episodios'); };
                $('temporadas').appendChild(el);
            });
            mostrarEpisodios(0);
            Foco.primero($('episodios'));
        }, function (err) {
            if (err && err.cuenta) return cerrarSesion(err.message);
            $('serie-estado').textContent = (err && err.message) || 'No se pudo cargar la serie';
        });
    }

    function ponerPortada(url) {
        var img = $('portada');
        img.className = 'sin-imagen';
        img.onload = function () { img.className = ''; };
        img.onerror = function () { img.className = 'sin-imagen'; };
        if (url) img.src = url; else img.removeAttribute('src');
    }

    function mostrarEpisodios(k) {
        var t = S.serie.temporadas[k], caja = $('episodios');
        if (S.serie.temporada === k) return;
        S.serie.temporada = k;
        var ts = $('temporadas').children;
        for (var j = 0; j < ts.length; j++) ts[j].classList.toggle('activa', j === k);
        caja.innerHTML = '';
        caja.scrollTop = 0;
        Foco.olvidar('episodios');
        t.episodios.forEach(function (ep, i) {
            var el = document.createElement('div');
            el.className = 'episodio f';
            el.textContent = (i + 1) + '.  ' + ep.nombre;
            el.alOk = function () { reproducir(t.episodios, i); };
            caja.appendChild(el);
        });
    }

    function cerrarSerie(sinFoco) {
        S.serie = null;
        $('serie').hidden = true;
        $('velo').hidden = true;
        if (S.vista === 'serie') {
            S.vista = 'principal';
            $('principal').hidden = false;
            $('linea').hidden = false;
            if (!sinFoco) Foco.zona('contenido');
        }
    }

    // =====================================================================================
    // Reproductor
    // =====================================================================================
    function reproducir(lista, i) {
        S.vistaAntes = S.vista;
        $('fondo').hidden = true;
        $('seguro').hidden = true;
        $('linea').hidden = true;
        Reproductor.abrir(lista, i);
    }

    function alCerrarReproductor() {
        $('fondo').hidden = false;
        $('seguro').hidden = false;
        $('linea').hidden = S.vista !== 'principal';
        ponerHora();
        var f = Foco.actual();
        if (f && f.offsetParent !== null) Foco.poner(f); else restaurarFoco();
    }

    // =====================================================================================
    // Arranque
    // =====================================================================================
    function leerAjustes() {
        if (!CONFIG.ajustes) return;
        var x = new XMLHttpRequest();
        x.open('GET', CONFIG.ajustes + '?t=' + Date.now(), true);
        x.timeout = 15000;
        x.onload = function () {
            try { if (x.status === 200) Comun.guardar('ajustes', JSON.parse(x.responseText)); } catch (e) { /* se quedan los anteriores */ }
        };
        x.send();
    }

    function iniciar() {
        escalar();
        window.addEventListener('resize', escalar);
        registrarTeclas();
        document.addEventListener('keydown', alPresionar);
        document.addEventListener('keyup', alSoltar);
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) Reproductor.suspender(); else { Reproductor.reanudar(); ponerHora(); }
        });
        Reproductor.iniciar({ api: function () { return S.api; }, alCerrar: alCerrarReproductor });
        $('version-login').textContent = 'Versión ' + VERSION;
        prepararLogin();
        prepararSecciones();
        setInterval(function () { if (S.vista !== 'login') ponerHora(); }, 20000);
        leerAjustes();
        var sesion = Comun.leer('sesion', null);
        if (sesion && sesion.usuario) {
            S.usuario = sesion.usuario;
            S.clave = sesion.clave;
            S.servidor = sesion.servidor || CONFIG.servidor;
            mostrarLogin('Conectando…');
            entrar();
        } else {
            mostrarLogin('');
        }
    }

    /** Para el simulador de pruebas: escribe en el campo del diálogo como si fuera el teclado del televisor. */
    function escribir(texto) {
        $('dialogo-entrada').value = texto;
        terminarDeEscribir(true);
    }

    iniciar();
    return { tecla: tecla, escribir: escribir, version: VERSION };
})();
