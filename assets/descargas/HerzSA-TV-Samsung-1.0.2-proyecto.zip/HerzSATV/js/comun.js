// Utilidades comunes. Todo en JavaScript ES5 (sin flechas, clases ni async) para que funcione en los
// televisores Samsung de 2016 en adelante, que traen motores web viejos.
'use strict';

var Comun = (function () {
    var DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    var MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

    function texto(v) {
        return v === null || v === undefined ? '' : String(v).replace(/^\s+|\s+$/g, '');
    }

    function numero(v) {
        var n = parseFloat(v);
        return isFinite(n) ? n : 0;
    }

    /** Sin acentos y en minúsculas, para buscar. */
    function plano(s) {
        var de = 'áàäâãéèëêíìïîóòöôõúùüûñç', a = 'aaaaaeeeeiiiiooooouuuunc';
        s = texto(s).toLowerCase();
        var salida = '';
        for (var i = 0; i < s.length; i++) {
            var k = de.indexOf(s.charAt(i));
            salida += k >= 0 ? a.charAt(k) : s.charAt(i);
        }
        return salida;
    }

    function dos(n) {
        return n < 10 ? '0' + n : String(n);
    }

    function hora(d) {
        return dos(d.getHours()) + ':' + dos(d.getMinutes());
    }

    /** «Dom 22 Nov  01:57» (barra de arriba). */
    function fechaCorta(d) {
        var dia = DIAS[d.getDay()].charAt(0).toUpperCase() + DIAS[d.getDay()].substr(1, 2);
        var mes = MESES[d.getMonth()].charAt(0).toUpperCase() + MESES[d.getMonth()].substr(1, 2);
        return dia + ' ' + d.getDate() + ' ' + mes + '  ' + hora(d);
    }

    /** «domingo 22 de noviembre de 2026   01:57» (reproductor). */
    function fechaLarga(d) {
        return DIAS[d.getDay()] + ' ' + d.getDate() + ' de ' + MESES[d.getMonth()] + ' de ' + d.getFullYear() + '   ' + hora(d);
    }

    function fechaYHora(segundos) {
        var d = new Date(segundos * 1000);
        return dos(d.getDate()) + '/' + dos(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + hora(d);
    }

    /** Segundos → «1:02:03» o «2:03». */
    function duracion(s) {
        s = Math.max(0, Math.floor(s));
        var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
        return (h > 0 ? h + ':' + dos(m) : String(m)) + ':' + dos(x);
    }

    // ---------- Datos guardados en el televisor ----------
    function leer(clave, defecto) {
        try {
            var v = window.localStorage.getItem('herzsa.' + clave);
            return v === null ? defecto : JSON.parse(v);
        } catch (e) {
            return defecto;
        }
    }

    function guardar(clave, valor) {
        try {
            window.localStorage.setItem('herzsa.' + clave, JSON.stringify(valor));
        } catch (e) { /* sin espacio: no se guarda */ }
    }

    function borrar(clave) {
        try {
            window.localStorage.removeItem('herzsa.' + clave);
        } catch (e) { /* nada */ }
    }

    // ---------- Red ----------
    /** «Wi-Fi», «Red por cable» o «Sin conexión», según el televisor (webapis.network). */
    function red() {
        try {
            if (window.webapis && webapis.network) {
                var tipo = webapis.network.getActiveConnectionType();
                if (tipo === 1) return { wifi: true, texto: 'Wi-Fi' };
                if (tipo === 3) return { wifi: false, texto: 'Red por cable' };
                if (tipo === 0) return { wifi: false, texto: 'Sin conexión' };
            }
        } catch (e) { /* sin permiso o sin red */ }
        return { wifi: false, texto: navigator.onLine === false ? 'Sin conexión' : 'Conectado' };
    }

    // ---------- Huella del PIN de Adultos ----------
    // Igual que en Android, Windows y Roku: SHA-256 de «herzsa-tv:PIN» en hexadecimal.
    var K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];

    function sha256(cadena) {
        var bytes = unescape(encodeURIComponent(cadena));
        var largo = bytes.length, palabras = [], i;
        for (i = 0; i < largo; i++) palabras[i >> 2] |= (bytes.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
        palabras[largo >> 2] |= 0x80 << (24 - (largo % 4) * 8);
        var total = (((largo + 8) >> 6) + 1) * 16;
        for (i = (largo >> 2) + 1; i < total; i++) palabras[i] = palabras[i] || 0;
        palabras[total - 1] = largo * 8;
        var h = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
        var w = new Array(64);
        function rot(x, n) { return (x >>> n) | (x << (32 - n)); }
        for (var b = 0; b < total; b += 16) {
            var a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
            for (i = 0; i < 64; i++) {
                if (i < 16) w[i] = palabras[b + i] | 0;
                else {
                    var s0 = rot(w[i - 15], 7) ^ rot(w[i - 15], 18) ^ (w[i - 15] >>> 3);
                    var s1 = rot(w[i - 2], 17) ^ rot(w[i - 2], 19) ^ (w[i - 2] >>> 10);
                    w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
                }
                var t1 = (hh + (rot(e, 6) ^ rot(e, 11) ^ rot(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
                var t2 = ((rot(a, 2) ^ rot(a, 13) ^ rot(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
                hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
            }
            h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
            h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
        }
        var hex = '';
        for (i = 0; i < 8; i++) hex += ('00000000' + (h[i] >>> 0).toString(16)).slice(-8);
        return hex;
    }

    function huella(pin) {
        return sha256('herzsa-tv:' + pin);
    }

    return {
        texto: texto, numero: numero, plano: plano, dos: dos, hora: hora, fechaCorta: fechaCorta, fechaLarga: fechaLarga,
        fechaYHora: fechaYHora, duracion: duracion, leer: leer, guardar: guardar, borrar: borrar, red: red,
        sha256: sha256, huella: huella
    };
})();
