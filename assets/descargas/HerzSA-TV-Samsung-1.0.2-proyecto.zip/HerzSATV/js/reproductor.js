// Reproductor. Igual que PlayerView.brs de Roku:
//  - En vivo: arriba/abajo (o CH+/CH−) cambian de canal, OK muestra el programa actual y los siguientes,
//    izquierda/derecha cambian el formato (cada canal lo recuerda), Play vuelve a abrir el canal.
//  - Películas y episodios: cualquier tecla muestra los botones (Volver, Retroceder, Pausa, Adelantar,
//    Formato) con el avance; ◄ ► eligen y OK acepta. Se retoma donde se quedó y al terminar un
//    episodio sigue el siguiente.
// El video lo reproduce AVPlay (webapis.avplay), el reproductor del televisor, que decodifica lo que
// el Chromium del televisor no (MPEG-2, AC3, HEVC). Sin AVPlay (pruebas en una PC) usa <video>.
'use strict';

// ---------- Motores ----------
var MotorAvplay = {
    nombre: 'avplay',
    abrir: function (url, desdeMs, ev) {
        var av = webapis.avplay;
        this.detener();
        this.ancho = 0;
        this.alto = 0;
        av.open(url);
        av.setDisplayRect(0, 0, 1920, 1080);
        // Buffer: arranca con 4 s de video y, si se vacía, espera 8 s antes de seguir, para no parar y
        // arrancar a cada rato cuando el servidor entrega a tirones. (Solo se puede antes de prepare.)
        try {
            av.setBufferingParam('PLAYER_BUFFER_FOR_PLAY', 'PLAYER_BUFFER_SIZE_IN_SECOND', 4);
            av.setBufferingParam('PLAYER_BUFFER_FOR_RESUME', 'PLAYER_BUFFER_SIZE_IN_SECOND', 8);
        } catch (e) { /* modelos que no lo tienen: valores del televisor */ }
        av.setListener({
            onbufferingstart: function () { ev.cargando(true); },
            onbufferingcomplete: function () { ev.cargando(false); },
            onstreamcompleted: function () { ev.fin(); },
            onerror: function (e) { ev.error(String(e)); },
            onevent: function () { },
            oncurrentplaytime: function () { },
            ondrmevent: function () { },
            onsubtitlechange: function () { }
        });
        var yo = this;
        av.prepareAsync(function () {
            yo.leerTamano();
            var empezar = function () {
                try { av.play(); } catch (e) { return ev.error(String(e)); }
                ev.listo();
            };
            if (desdeMs > 0) av.seekTo(desdeMs, empezar, empezar);
            else empezar();
        }, function (e) { ev.error(String(e)); });
    },
    leerTamano: function () {
        try {
            var pistas = webapis.avplay.getCurrentStreamInfo();
            for (var i = 0; i < pistas.length; i++) {
                if (pistas[i].type !== 'VIDEO') continue;
                var info = JSON.parse(pistas[i].extra_info);
                this.ancho = Number(info.Width) || 0;
                this.alto = Number(info.Height) || 0;
            }
        } catch (e) { /* sin datos del video */ }
    },
    tamano: function () { return { ancho: this.ancho || 0, alto: this.alto || 0 }; },
    detener: function () {
        try { webapis.avplay.stop(); } catch (e) { /* nada */ }
        try { webapis.avplay.close(); } catch (e) { /* nada */ }
    },
    pausar: function () { try { webapis.avplay.pause(); } catch (e) { /* nada */ } },
    seguir: function () { try { webapis.avplay.play(); } catch (e) { /* nada */ } },
    pausado: function () { try { return webapis.avplay.getState() === 'PAUSED'; } catch (e) { return false; } },
    tiempo: function () { try { return webapis.avplay.getCurrentTime() / 1000; } catch (e) { return 0; } },
    duracion: function () { try { return webapis.avplay.getDuration() / 1000; } catch (e) { return 0; } },
    saltar: function (segundos) {
        try {
            if (segundos >= 0) webapis.avplay.jumpForward(segundos * 1000);
            else webapis.avplay.jumpBackward(-segundos * 1000);
        } catch (e) { /* fuera del video */ }
    },
    /** Formato: 'Completo' (todo el video, con franjas si hace falta), 'Llenar' (llena la pantalla
     *  recortando, sin deformar) o 'Zoom'. a = proporción del video (0 si no se sabe). Para recortar
     *  se usa setVideoRoi (región del video que se muestra) si el televisor lo tiene. */
    formato: function (f, a) {
        var av = webapis.avplay, pantalla = 16 / 9;
        try { av.setDisplayMethod('PLAYER_DISPLAY_MODE_LETTER_BOX'); } catch (e) { /* nada */ }
        if (typeof av.setVideoRoi !== 'function') return f === 'Completo';
        var x = 0, y = 0, w = 1, h = 1;
        if (f === 'Llenar') {
            if (!(a > 0)) a = 4 / 3;
            if (a < pantalla) { h = a / pantalla; y = (1 - h) / 2; } else { w = pantalla / a; x = (1 - w) / 2; }
        } else if (f === 'Zoom') {
            w = h = 0.75; x = y = 0.125;
        }
        try { av.setVideoRoi(x, y, w, h); return true; } catch (e) { return f === 'Completo'; }
    }
};

var MotorHtml = {
    nombre: 'html',
    abrir: function (url, desdeMs, ev) {
        var v = document.getElementById('video'), yo = this;
        this.detener();
        v.hidden = false;
        v.onloadedmetadata = function () { if (desdeMs > 0) v.currentTime = desdeMs / 1000; };
        v.onplaying = function () { ev.cargando(false); ev.listo(); };
        v.onwaiting = function () { ev.cargando(true); };
        v.onended = function () { ev.fin(); };
        v.onerror = function () { ev.error('video ' + (v.error && v.error.code)); };
        if (/\.m3u8$/.test(url) && window.Hls && Hls.isSupported()) {
            this.hls = new Hls();
            this.hls.on(Hls.Events.ERROR, function (x, d) { if (d.fatal) ev.error('hls ' + d.details); });
            this.hls.loadSource(url);
            this.hls.attachMedia(v);
        } else {
            v.src = url;
        }
        var p = v.play();
        if (p && p.catch) p.catch(function () { /* el error llega por onerror */ });
        yo.v = v;
    },
    tamano: function () { var v = document.getElementById('video'); return { ancho: v.videoWidth || 0, alto: v.videoHeight || 0 }; },
    detener: function () {
        var v = document.getElementById('video');
        if (this.hls) { this.hls.destroy(); this.hls = null; }
        v.onerror = null;
        v.pause();
        v.removeAttribute('src');
        try { v.load(); } catch (e) { /* nada */ }
        v.hidden = true;
    },
    pausar: function () { document.getElementById('video').pause(); },
    seguir: function () { document.getElementById('video').play(); },
    pausado: function () { return document.getElementById('video').paused; },
    tiempo: function () { return document.getElementById('video').currentTime || 0; },
    duracion: function () { var d = document.getElementById('video').duration; return isFinite(d) ? d : 0; },
    saltar: function (s) { var v = document.getElementById('video'); v.currentTime = Math.max(0, v.currentTime + s); },
    formato: function (f) {
        var v = document.getElementById('video');
        v.style.objectFit = f === 'Llenar' ? 'cover' : 'contain';
        v.style.transform = f === 'Zoom' ? 'scale(1.333)' : '';
        return true;
    }
};

// ---------- Pantalla del reproductor ----------
var Reproductor = (function () {
    var $ = function (id) { return document.getElementById(id); };
    var motor = window.webapis && webapis.avplay ? MotorAvplay : MotorHtml;
    var BOTONES = ['volver', 'atras', 'pausa', 'adelante', 'formato'];
    var R = null, app = null;
    var relojCapa, relojAviso, relojReintento, relojZapeo, relojControles, relojAvance;

    function iniciar(dependencias) { app = dependencias; }

    function ajustes() {
        var aj = Comun.leer('ajustes', {}) || {};
        var recortar = aj.recortar !== false;
        var opciones = recortar ? ['Automático', 'Completo', 'Llenar', 'Zoom'] : ['Completo'];
        var umbral = typeof aj.umbral === 'number' && aj.umbral >= 0 && aj.umbral <= 1 ? aj.umbral : 0.34;
        var base = opciones.indexOf(aj.formato) >= 0 ? aj.formato : opciones[0];
        return { opciones: opciones, umbral: umbral, base: base };
    }

    /** lista: elementos (canales, películas o episodios); i: el que se abre. */
    function abrir(lista, i) {
        var aj = ajustes();
        R = {
            lista: lista, opciones: aj.opciones, umbral: aj.umbral, base: aj.base,
            formatos: Comun.leer('formatos', {}) || {}, formatoVod: Comun.leer('formatoVod', ''),
            posiciones: Comun.leer('posiciones', {}) || {}, boton: 2, abierto: true
        };
        $('reproductor').hidden = false;
        document.documentElement.className = 'viendo';
        pantallaEncendida(true);
        clearInterval(relojAvance);
        relojAvance = setInterval(alAvanzar, 1000);
        ponerElemento(i);
    }

    function abierto() { return !!(R && R.abierto); }

    function cerrar() {
        if (!R) return;
        guardarPosicion();
        R.abierto = false;
        [relojCapa, relojAviso, relojReintento, relojZapeo, relojControles].forEach(clearTimeout);
        clearInterval(relojAvance);
        motor.detener();
        pantallaEncendida(false);
        $('reproductor').hidden = true;
        document.documentElement.className = '';
        R = null;
        app.alCerrar();
    }

    function pantallaEncendida(si) {
        try {
            var estado = webapis.appcommon.AppCommonScreenSaverState;
            webapis.appcommon.setScreenSaver(si ? estado.SCREEN_SAVER_OFF : estado.SCREEN_SAVER_ON);
        } catch (e) { /* no es un televisor Samsung */ }
    }

    function clave(e) { return e.tipo + ':' + e.id; }

    function ponerElemento(i) {
        guardarPosicion();
        var e = R.lista[i];
        if (!e) return cerrar();
        R.i = i;
        R.e = e;
        R.vivo = e.tipo === 'live';
        R.reintentos = 0;
        R.posicion = 0;
        R.aspecto = e.aspecto || 0;
        R.listo = false;
        if (!R.vivo) {
            var guardada = R.posiciones[clave(e)];
            if (guardada > 30) R.posicion = guardada;
            if (!R.aspecto && e.tipo === 'vod') {
                var pedido = e;
                app.api().aspectoDePelicula(e.id).then(function (a) {
                    if (R && R.e === pedido && a > 0) { R.aspecto = a; aplicarFormato(); }
                });
            }
        }
        R.formato = R.base;
        if (R.vivo && R.formatos[clave(e)]) R.formato = R.formatos[clave(e)];
        if (!R.vivo && R.formatoVod) R.formato = R.formatoVod;
        if (R.opciones.indexOf(R.formato) < 0) R.formato = R.base;
        $('capa').hidden = true;
        $('controles').hidden = true;
        $('arriba').hidden = true;
        if (R.vivo) mostrarCapa(); else { R.boton = 2; mostrarControles(); }
        arrancar();
        if (R.posicion > 0) avisar('Continuando donde te quedaste');
    }

    function arrancar() {
        clearTimeout(relojReintento);
        if (!R) return;
        if (R.reintentos === 0) $('estado-video').textContent = 'Cargando…';
        var e = R.e;
        motor.abrir(app.api().urlDeVideo(e), R.posicion * 1000, {
            listo: function () {
                if (!R || R.e !== e) return;
                R.listo = true;
                R.reintentos = 0;
                $('estado-video').textContent = '';
                aplicarFormato();
            },
            cargando: function (si) {
                if (R && R.e === e && R.listo) $('estado-video').textContent = si ? 'Cargando…' : '';
            },
            fin: function () {
                if (!R || R.e !== e) return;
                if (R.vivo) return falla();
                delete R.posiciones[clave(e)];
                Comun.guardar('posiciones', R.posiciones);
                R.posicion = 0;
                if (e.tipo === 'episode' && R.i + 1 < R.lista.length) ponerElemento(R.i + 1);
                else cerrar();
            },
            error: function () { if (R && R.e === e) falla(); }
        });
        aplicarFormato();
    }

    // Si se cae la señal se reintenta solo: en vivo sin límite cada 3 s, en películas tres veces.
    function falla() {
        if (!R) return;
        if (!R.vivo) R.posicion = Math.max(R.posicion, Math.floor(motor.tiempo()));
        R.reintentos++;
        motor.detener();
        if (!R.vivo && R.reintentos > 3) {
            $('estado-video').textContent = 'No se pudo reproducir «' + R.e.nombre + '». Pulsa Atrás para regresar.';
            return;
        }
        $('estado-video').textContent = R.vivo ? 'Se perdió la señal. Reintentando…' : 'Reintentando…';
        relojReintento = setTimeout(arrancar, 3000);
    }

    function guardarPosicion() {
        if (!R || !R.e || R.vivo || !R.listo) return;
        var t = Math.floor(motor.tiempo()), d = motor.duracion(), k = clave(R.e);
        if (t > 30 && (!(d > 0) || t < d - 60)) R.posiciones[k] = t; else delete R.posiciones[k];
        Comun.guardar('posiciones', R.posiciones);
    }

    function alAvanzar() {
        if (!R || !R.listo) return;
        R.segundos = (R.segundos || 0) + 1;
        if (!R.vivo && R.segundos % 10 === 0) guardarPosicion();
        if (!$('controles').hidden) actualizarAvance();
        if (R.formato === 'Automático' && !R.aspecto && R.segundos % 3 === 0) aplicarFormato();
    }

    // ---------- Formato (igual que Roku) ----------
    /** Proporción del video, o 0 si no se sabe. Las resoluciones de TV estándar (720x480, 720x576,
     *  1440x1080…) usan pixeles no cuadrados y su proporción real no se puede saber así. */
    function proporcion() {
        if (R.aspecto > 0) return R.aspecto;
        var t = motor.tamano(), w = t.ancho, h = t.alto;
        if (w <= 0 || h <= 0) return 0;
        if (h === 480 || h === 576 || w === 1440 || w === 960 || (w === 1280 && h === 1080)) return 0;
        return w / h;
    }

    function aplicarFormato() {
        if (!R) return;
        var a = proporcion(), f = R.formato, pantalla = 16 / 9;
        if (f === 'Automático') {
            f = 'Completo';
            if (a > 0) {
                var diferencia = Math.abs(a - pantalla) / pantalla;
                if (diferencia > 0.01 && diferencia <= R.umbral) f = 'Llenar';
            }
        }
        R.formatoReal = f;
        if (!motor.formato(f, a) && f !== 'Completo') {
            motor.formato('Completo', a);
            R.formatoReal = 'Completo';
            R.sinRecorte = true;
        }
    }

    function cambiarFormato() {
        var k = R.opciones.indexOf(R.formato);
        R.formato = R.opciones[(k + 1) % R.opciones.length];
        if (R.vivo) {
            if (R.formato === R.base) delete R.formatos[clave(R.e)]; else R.formatos[clave(R.e)] = R.formato;
            Comun.guardar('formatos', R.formatos);
        } else {
            R.formatoVod = R.formato === R.base ? '' : R.formato;
            Comun.guardar('formatoVod', R.formatoVod);
        }
        aplicarFormato();
        ponerTeclas();
        if (R.sinRecorte && R.formato !== 'Completo') avisar('Este televisor no permite recortar el video');
        else if (R.formato === 'Automático') avisar('Formato: Automático (' + R.formatoReal.toLowerCase() + ')');
        else avisar('Formato: ' + R.formato);
    }

    // ---------- En vivo ----------
    function actualizarArriba(titulo) {
        $('titulo-arriba').textContent = titulo;
        $('fecha-arriba').textContent = Comun.fechaLarga(new Date());
        $('red-arriba').textContent = Comun.red().texto;
    }

    function ponerTeclas() {
        $('teclas-vivo').textContent = 'Arriba y abajo: canal      Izquierda y derecha: formato (' + R.formato + ')      Play: volver a abrir el canal      Atrás: salir';
        $('teclas-video').textContent = 'Izquierda y derecha: elegir botón      OK: aceptar      Formato: ' + R.formato + '      Atrás: salir';
    }

    function mostrarCapa() {
        actualizarArriba('TV en vivo');
        $('arriba').hidden = false;
        $('nombre-canal').textContent = R.e.nombre;
        $('hora-canal').textContent = Comun.hora(new Date());
        $('guia').textContent = '';
        ponerTeclas();
        var e = R.e;
        app.api().guia(e.id).then(function (lineas) {
            if (!R || R.e !== e) return;
            $('guia').textContent = lineas.length ? 'Ahora:  ' + lineas[0] + (lineas[1] ? '\nDespués:  ' + lineas[1] : '') : 'Sin guía de programación';
        });
        $('capa').hidden = false;
        clearTimeout(relojCapa);
        relojCapa = setTimeout(ocultarCapa, 6000);
    }

    function ocultarCapa() {
        $('capa').hidden = true;
        $('arriba').hidden = true;
    }

    // Al zapear se muestra el nombre enseguida y el canal se abre cuando se deja de pulsar.
    function zapear(paso) {
        var n = R.lista.length, i = R.i;
        for (var k = 0; k < n; k++) {
            i = (i + paso + n) % n;
            if (R.lista[i].tipo === 'live') break;
        }
        R.zapeo = i;
        $('nombre-canal').textContent = R.lista[i].nombre;
        $('guia').textContent = '';
        $('capa').hidden = false;
        $('arriba').hidden = false;
        clearTimeout(relojZapeo);
        relojZapeo = setTimeout(function () { if (R) ponerElemento(R.zapeo); }, 600);
    }

    // ---------- Películas y episodios ----------
    function mostrarControles() {
        if ($('controles').hidden) R.boton = 2;
        actualizarArriba(R.e.nombre);
        ponerTeclas();
        actualizarPausa();
        pintarBotones();
        actualizarAvance();
        $('arriba').hidden = false;
        $('controles').hidden = false;
        esconderLuego();
    }

    function esconderLuego() {
        clearTimeout(relojControles);
        if (!motor.pausado()) relojControles = setTimeout(ocultarControles, 5000);
    }

    function ocultarControles() {
        $('controles').hidden = true;
        $('arriba').hidden = true;
    }

    function pintarBotones() {
        var b = document.querySelectorAll('#botones-video .redondo');
        for (var i = 0; i < b.length; i++) b[i].className = 'redondo' + (i === R.boton ? ' foco' : '');
    }

    function actualizarPausa() {
        var p = motor.pausado();
        $('icono-pausa').src = p ? 'img/boton_play.png' : 'img/boton_pausa.png';
        $('texto-pausa').textContent = p ? 'Reproducir' : 'Pausa';
    }

    function actualizarAvance() {
        var t = motor.tiempo(), d = motor.duracion();
        $('tiempo').textContent = Comun.duracion(t);
        $('duracion').textContent = d > 0 ? Comun.duracion(d) : '';
        $('barra').style.width = d > 0 ? Math.min(100, t / d * 100) + '%' : '0';
    }

    function alternarPausa() {
        if (motor.pausado()) motor.seguir(); else motor.pausar();
        setTimeout(function () { if (R) { actualizarPausa(); esconderLuego(); } }, 150);
    }

    function saltar(s) {
        motor.saltar(s);
        avisar(s > 0 ? '+' + s + ' s' : '−' + -s + ' s');
        setTimeout(function () { if (R) actualizarAvance(); }, 300);
    }

    function activarBoton() {
        var b = BOTONES[R.boton];
        if (b === 'volver') cerrar();
        else if (b === 'atras') saltar(-10);
        else if (b === 'pausa') alternarPausa();
        else if (b === 'adelante') saltar(30);
        else if (b === 'formato') cambiarFormato();
    }

    function avisar(texto) {
        $('aviso-video').textContent = texto;
        $('aviso-video').hidden = false;
        clearTimeout(relojAviso);
        relojAviso = setTimeout(function () { $('aviso-video').hidden = true; }, 2500);
    }

    // ---------- Teclas ----------
    function tecla(t) {
        if (!R) return false;
        if (t === 'atras' || t === 'stop') { cerrar(); return true; }
        if (R.vivo) {
            if (t === 'arriba' || t === 'ch+') zapear(1);
            else if (t === 'abajo' || t === 'ch-') zapear(-1);
            else if (t === 'izquierda' || t === 'derecha') { cambiarFormato(); mostrarCapa(); }
            else if (t === 'play' || t === 'playpausa') {
                R.reintentos = 0;
                arrancar();
                avisar('Abriendo el canal otra vez…');
            } else if (t === 'ok') { if ($('capa').hidden) mostrarCapa(); else ocultarCapa(); }
            return true;
        }
        var visibles = !$('controles').hidden;
        if (t === 'playpausa' || t === 'play' || t === 'pausa') {
            if (t === 'playpausa' || (t === 'play') === motor.pausado()) alternarPausa();
            mostrarControles();
        } else if (t === 'adelantar') { saltar(30); mostrarControles(); }
        else if (t === 'retroceder') { saltar(-10); mostrarControles(); }
        else if (!visibles) mostrarControles();
        else if (t === 'izquierda') { R.boton = Math.max(0, R.boton - 1); pintarBotones(); esconderLuego(); }
        else if (t === 'derecha') { R.boton = Math.min(BOTONES.length - 1, R.boton + 1); pintarBotones(); esconderLuego(); }
        else if (t === 'ok') { activarBoton(); if (R) { actualizarPausa(); esconderLuego(); } }
        else if (t === 'arriba') { saltar(60); }
        else if (t === 'abajo') { saltar(-60); }
        else mostrarControles();
        return true;
    }

    // Al salir de la app (botón Home) el televisor la suspende: se detiene el video y se reanuda al volver.
    function suspender() {
        if (!R) return;
        guardarPosicion();
        if (!R.vivo && R.listo) R.posicion = Math.floor(motor.tiempo());
        motor.detener();
        R.suspendido = true;
    }

    function reanudar() {
        if (!R || !R.suspendido) return;
        R.suspendido = false;
        R.reintentos = 0;
        arrancar();
    }

    return { iniciar: iniciar, abrir: abrir, abierto: abierto, cerrar: cerrar, tecla: tecla, suspender: suspender, reanudar: reanudar, motor: function () { return motor.nombre; } };
})();
