// Servidor del panel XUI (API Xtream Codes) y ajustes de pantalla que se cambian sin actualizar la app.
// build.sh lo cambia solo en la compilación de pruebas.
var CONFIG = {
    servidor: 'http://172.10.20.185',
    ajustes: 'https://control-isp.herdzsa.net/static/downloads/samsung/ajustes.json'
};
